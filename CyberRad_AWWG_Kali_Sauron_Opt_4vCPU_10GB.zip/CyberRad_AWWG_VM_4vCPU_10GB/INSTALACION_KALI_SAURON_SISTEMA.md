# CyberRad AWWG · Instalacion aislada del proyecto Sauron (Kali)

## Layout definitivo
- **Codigo**: `/opt/cyberrad-awwg/` (propiedad de root)
- **BD e informes**: `/var/lib/cyberrad-awwg/` (propiedad de `cyberrad`)
- **Secretos y ajustes**: `/etc/cyberrad-awwg/cyberrad.env` (root, 0600)
- **Usuario de servicio**: `cyberrad`, sin shell e independiente de los usuarios de Kali.
- **Web**: `127.0.0.1:3001`, para entrar desde otro equipo usar túnel SSH o un proxy corporativo **autenticado**.
- **Contenedor**: `cyberrad-awwg`, máx. 3 vCPU/5 GB RAM, compartidos con Sauron, no reservados.
- **Logs**: Docker, rotacion 10 MB x 3.

## Instalacion nueva
1. Instalar Docker en Kali: `sudo apt update && sudo apt install -y docker.io docker-compose unzip openssl`
2. Arrancar Docker: `sudo systemctl enable --now docker`
3. Descomprimir el ZIP en una **carpeta temporal** (por ejemplo `/tmp/cyberrad-installer`) con `unzip ARCHIVO.zip -d /tmp/cyberrad-installer`.
4. Ejecutar:
   `sudo bash /tmp/cyberrad-installer/CyberRad_AWWG_VM_4vCPU_10GB/instalar_kali_sistema.sh`
5. Construir y arrancar exclusivamente CyberRad:
   `sudo docker compose --project-directory /opt/cyberrad-awwg --env-file /etc/cyberrad-awwg/cyberrad.env -f /opt/cyberrad-awwg/docker-compose.kali.yml up -d --build`
6. Comprobar:
   `curl -fsS http://127.0.0.1:3001/healthz`
7. Ver logs:
   `sudo docker logs --tail=80 cyberrad-awwg`
8. Ver consumo:
   `sudo docker stats cyberrad-awwg`

**No usar `docker system prune`, no tocar Sauron ni añadir al usuario `cyberrad` al grupo docker.** El instalador aborta si `/opt/cyberrad-awwg` o el contenedor `cyberrad-awwg` ya existen, para protegerlos. La instalación **no inicia** el contenedor: el paso 5 es deliberado.

## Datos y copias de seguridad
- El ZIP trae una base de datos inicial (fuentes preconfiguradas); el instalador copia esa DB solo si la ruta final no existe.
- Para migrar datos reales de otra instalación, parar el servicio origen y hacer una copia consistente de SQLite (incluidos WAL/SHM cuando corresponda o usando el comando sqlite backup). No sobrescribir la BD en caliente.
- Nunca borrar `/var/lib/cyberrad-awwg` al actualizar el código.

## Requisitos antes de produccion
- Las rutas administrativas del backend original no estan protegidas por el token semanal. Mantener escuchando **solo en loopback** hasta poner SSO/proxy autenticado.
- Aun faltan pruebas reales de carga en la VM con Sauron activo. No ejecutar tareas de Sauron intensivas simultaneas con exportaciones grandes, salvo medicion controlada.
