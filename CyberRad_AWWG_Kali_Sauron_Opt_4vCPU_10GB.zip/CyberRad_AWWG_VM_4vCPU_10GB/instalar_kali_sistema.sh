#!/usr/bin/env bash
# Instala CyberRad AWWG en /opt + /var/lib + /etc; NO toca Sauron ni borra contenedores.
set -Eeuo pipefail
if (( EUID != 0 )); then
  echo 'Ejecuta con sudo: sudo bash instalar_kali_sistema.sh' >&2
  exit 1
fi
SRC_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR=/opt/cyberrad-awwg
DATA_DIR=/var/lib/cyberrad-awwg
ETC_DIR=/etc/cyberrad-awwg
ENV_FILE="$ETC_DIR/cyberrad.env"
if [[ -e "$APP_DIR" ]]; then
  echo "Ya existe $APP_DIR. Se cancela para NO sobrescribir la instalación existente." >&2
  exit 2
fi
if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  echo 'Primero instala Docker Engine y Docker Compose v2 (docker.io y docker-compose).' >&2
  exit 3
fi
if ! command -v openssl >/dev/null 2>&1; then
  echo 'Falta openssl: sudo apt install -y openssl' >&2
  exit 4
fi
if docker container inspect cyberrad-awwg >/dev/null 2>&1; then
  echo 'Ya existe un contenedor cyberrad-awwg. Se cancela para no interferir en él.' >&2
  exit 5
fi
if ! getent passwd cyberrad >/dev/null; then
  useradd --system --user-group --home-dir "$DATA_DIR" --shell /usr/sbin/nologin cyberrad
fi
USER_UID="$(id -u cyberrad)"
USER_GID="$(id -g cyberrad)"
# Código propiedad de root, datos propiedad del usuario de servicio.
install -d -o root -g root -m 755 "$APP_DIR"
cp -a "$SRC_DIR"/. "$APP_DIR"/
chown -R root:root "$APP_DIR"
install -d -o cyberrad -g "$(id -gn cyberrad)" -m 750 "$DATA_DIR"
if [[ ! -e "$DATA_DIR/cyberrad_v4.db" ]]; then
  cp "$SRC_DIR/data/cyberrad_v4.db" "$DATA_DIR/cyberrad_v4.db"
  chown cyberrad:"$(id -gn cyberrad)" "$DATA_DIR/cyberrad_v4.db"
  chmod 640 "$DATA_DIR/cyberrad_v4.db"
fi
install -d -o root -g root -m 700 "$ETC_DIR"
if [[ ! -e "$ENV_FILE" ]]; then
  umask 077
  TOKEN="$(openssl rand -hex 32)"
  cat > "$ENV_FILE" <<EOF
CYBERRAD_BIND_IP=127.0.0.1
CYBERRAD_HOST_PORT=3001
CYBERRAD_UID=$USER_UID
CYBERRAD_GID=$USER_GID
CYBERRAD_WEEKLY_TOKEN=$TOKEN
TZ=Europe/Madrid
EOF
  chmod 600 "$ENV_FILE"
else
  echo "Conservando configuracion existente: $ENV_FILE"
fi
docker compose --env-file "$ENV_FILE" -f "$APP_DIR/docker-compose.kali.yml" config -q
echo
echo 'Instalación preparada. Código: /opt/cyberrad-awwg'
echo 'Datos: /var/lib/cyberrad-awwg'
echo 'Configuración: /etc/cyberrad-awwg/cyberrad.env'
echo 'Usuario de servicio: cyberrad (sin shell)'
echo 'Arranque manual:'
echo '  sudo docker compose --project-directory /opt/cyberrad-awwg --env-file /etc/cyberrad-awwg/cyberrad.env -f /opt/cyberrad-awwg/docker-compose.kali.yml up -d --build'
echo 'Sauron no ha sido modificado.'
