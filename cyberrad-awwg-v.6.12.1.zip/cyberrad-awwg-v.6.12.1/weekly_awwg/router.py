"""Drop-in FastAPI router; isolated namespace, no legacy schema changes."""
from __future__ import annotations
from datetime import date
from threading import Lock
import os
from pathlib import Path
import re
from fastapi import APIRouter, HTTPException, Request, Depends
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, ConfigDict, Field
from . import engine, enrichment, hackmanac
from .pptx_report import make_pptx, make_pdf_from_pptx

router=APIRouter(tags=['AWWG Weekly Intelligence'])
_REPORT_LOCK = Lock()
_RESEARCH_LOCK = Lock()


def access(request:Request):
 """The standalone module defaults to loopback; use existing corporate auth upstream."""
 token=os.environ.get('CYBERRAD_WEEKLY_TOKEN','')
 if token:
  import hmac
  provided=request.headers.get('authorization','')
  if not hmac.compare_digest(provided,'Bearer '+token):
   raise HTTPException(401,'Required weekly module token')
 else:
  # No open-by-default corporate report endpoint.
  if request.headers.get('x-forwarded-for') or not request.client or request.client.host not in ('127.0.0.1','::1','testclient'):
   raise HTTPException(403,'Local access only. Configure corporate auth or CYBERRAD_WEEKLY_TOKEN.')


class ConfigPayload(BaseModel):
 model_config=ConfigDict(extra='forbid')
 changes:dict

class UpdatePayload(BaseModel):
 model_config=ConfigDict(extra='forbid')
 changes:dict

class TrendPayload(BaseModel):
 model_config=ConfigDict(extra='forbid')
 week_start:str
 data:dict

class WeekPayload(BaseModel):
 model_config=ConfigDict(extra='forbid')
 week_start:str|None=None
 mode:str|None=None


def parse_week(week_start:str|None):
 try:return engine.date_range(week_start)
 except ValueError as exc: raise HTTPException(422,str(exc)) from exc

def access_page(request:Request):
 # Safe to serve the static page when token auth is configured: data APIs remain protected.
 if os.environ.get('CYBERRAD_WEEKLY_TOKEN',''): return
 access(request)

@router.get('/weekly',response_class=HTMLResponse,dependencies=[Depends(access_page)])
def page():
 return HTMLResponse((Path(__file__).parent/'weekly.html').read_text(encoding='utf-8'),headers={'Cache-Control':'no-store'})

@router.get('/api/weekly/settings',dependencies=[Depends(access)])
def settings():return {'settings':engine.get_settings(),'categories':engine.CATEGORIES}

@router.put('/api/weekly/settings',dependencies=[Depends(access)])
def update_settings(data:ConfigPayload):
 try:return engine.save_settings(data.changes)
 except ValueError as exc: raise HTTPException(422,str(exc)) from exc

@router.get('/api/weekly/items',dependencies=[Depends(access)])
def items(week_start:str|None=None):
 start,end=parse_week(week_start)
 return {'week_start':start.isoformat(),'week_end':end.isoformat(),'items':engine.list_items(start,end)}

@router.post('/api/weekly/items/manual',dependencies=[Depends(access)])
def create_manual_item(data:dict):
 try:return engine.add_manual_item(data)
 except ValueError as exc:raise HTTPException(422,str(exc)) from exc

@router.patch('/api/weekly/items/{item_id}',dependencies=[Depends(access)])
def edit(item_id:str,data:UpdatePayload):
 try:return engine.update_item(item_id,data.changes)
 except KeyError as exc: raise HTTPException(404,'Item not found') from exc
 except ValueError as exc: raise HTTPException(422,str(exc)) from exc

@router.post('/api/weekly/research',dependencies=[Depends(access)])
def research(payload:WeekPayload):
 start,end=parse_week(payload.week_start)
 if not _RESEARCH_LOCK.acquire(blocking=False):
  raise HTTPException(409,'A weekly research job is already running')
 try:
  return engine.research(start,end)
 finally:
  _RESEARCH_LOCK.release()

@router.get('/api/weekly/selection',dependencies=[Depends(access)])
def selection(week_start:str|None=None,mode:str|None=None):
 start,end=parse_week(week_start)
 cfg=engine.get_settings()
 try:return engine.selection_preview(engine.list_items(start,end),cfg,mode=mode)
 except ValueError as exc:raise HTTPException(422,str(exc)) from exc


@router.post('/api/weekly/generate',dependencies=[Depends(access)])
def generate(payload:WeekPayload):
 """Render saved news by selected mode without launching a research job."""
 return _generate_locked(payload)


def _generate_locked(payload:WeekPayload):
 if not _REPORT_LOCK.acquire(blocking=False):
  raise HTTPException(409,'Another report is currently rendering')
 try:return _generate_unlocked(payload)
 finally:_REPORT_LOCK.release()


def _generate_unlocked(payload:WeekPayload):
 start,end=parse_week(payload.week_start)
 cfg=engine.get_settings()
 mode=payload.mode or cfg.get('report_mode','automatic')
 if mode not in ('automatic','manual','mixed'):
  raise HTTPException(422,'Invalid report mode')
 saved=engine.list_items(start,end)
 included,mode=engine.select_for_report(saved,cfg,mode=mode)
 if not included:
  details=engine.selection_preview(saved,cfg,mode=mode)
  raise HTTPException(422,details['message']+' No se ha generado un informe vacío.')
 included,enrichment_stats=enrichment.enrich_selected(included)
 comparison_stats={'compared':0,'unavailable':0}
 # Only a selected official Hack Tuesday story triggers week-over-week analysis.
 # Do not create a standalone sector report or persist public comparison data.
 for item in included:
  if hackmanac.is_weekly_item(item):
   item.update(hackmanac.compare_selected(item))
   state=item.get('hackmanac_comparison_method')
   if state=='unavailable': comparison_stats['unavailable']+=1
   elif state: comparison_stats['compared']+=1
 pptx=make_pptx(start,end,included)
 pdf_error=None
 try:pdf=make_pdf_from_pptx(pptx)
 except (RuntimeError,OSError):
  pdf=None
  pdf_error='No se pudo generar el PDF; el PPTX permanece disponible. Revisa los registros.'
 base='/api/weekly/reports/'
 downloads={'pptx':base+pptx.name,'pdf':(base+pdf.name if pdf else None)}
 return {'file':pdf.name if pdf else pptx.name,'url':downloads['pdf'] or downloads['pptx'],
   'downloads':downloads,'items':len(included),'week_start':start.isoformat(),
   'selection_mode':mode,'enrichment':enrichment_stats,
   'hackmanac_comparison':comparison_stats,
   'auto_unverified':sum(1 for r in included if r.get('_selection')=='auto_draft'),
   'manual_items':sum(1 for r in included if r.get('_selection')=='manual'),
   'automatic_items':sum(1 for r in included if r.get('_selection') in ('auto_draft','automatic_verified')),
   'pdf_error':pdf_error}


@router.post('/api/weekly/run',dependencies=[Depends(access)])
def run(payload:WeekPayload):
 cfg=engine.get_settings()
 mode=payload.mode or cfg.get('report_mode','automatic')
 if mode not in ('automatic','manual','mixed'):
  raise HTTPException(422,'Invalid report mode')
 start,end=parse_week(payload.week_start)
 fetched={'new_items':0,'candidate_items':0,'source_errors':[],
          'week_start':start.isoformat(),'week_end':end.isoformat()}
 if mode!='manual':
  if not _RESEARCH_LOCK.acquire(blocking=False):
   raise HTTPException(409,'A weekly research job is already running')
  try:fetched=engine.research(start,end)
  finally:_RESEARCH_LOCK.release()
 result=_generate_locked(payload)
 return {'research':fetched,'report':result}

@router.get('/api/weekly/trends',dependencies=[Depends(access)])
def trends(week_start:str|None=None):
 start,_=parse_week(week_start)
 return {'data':engine.trend_for(start)}

@router.put('/api/weekly/trends',dependencies=[Depends(access)])
def set_trends(payload:TrendPayload):
 start,_=parse_week(payload.week_start)
 try:return engine.set_trend(start,payload.data)
 except ValueError as exc: raise HTTPException(422,str(exc)) from exc

@router.get('/api/weekly/reports',dependencies=[Depends(access)])
def reports():
 engine.initialize()
 return [{'name':f.name,'size':f.stat().st_size} for f in sorted(engine.REPORTS.glob('AWWG_Weekly_Report_*'),reverse=True) if f.suffix.lower() in ('.pdf','.pptx')][:100]

@router.get('/api/weekly/reports/{name}',dependencies=[Depends(access)])
def report(name:str):
 if not re.fullmatch(r'AWWG_Weekly_Report_\d{4}-\d{2}-\d{2}\.(?:pdf|pptx)',name):raise HTTPException(404,'Invalid name')
 file=engine.REPORTS/name
 if not file.is_file():raise HTTPException(404,'No such report')
 med='application/pdf' if file.suffix=='.pdf' else 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
 return FileResponse(file,media_type=med,filename=name,headers={'Cache-Control':'no-store'})
