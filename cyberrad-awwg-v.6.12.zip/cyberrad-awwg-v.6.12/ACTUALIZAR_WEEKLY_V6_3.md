# CyberRad AWWG — Actualización Weekly Reports 6.3 (Kali + Sauron)

## Errores corregidos

- No se vuelve a seleccionar automáticamente la semana pasada: se utiliza una **ventana móvil de siete días** en horario Europe/Madrid; las noticias RSS/Atom que suministran hora se filtran con límite preciso de 168 horas. Los avisos de CISA KEV solo facilitan día de incorporación y deben tratarse con esa precisión.
- Se priorizan, dentro de cada nivel de gravedad, las noticias más recientes. La ventana puede cambiarse manualmente con el selector de fecha.
- Los títulos repetidos de CISA se abrevian y las acciones genéricas largas se sustituyen por tareas verificables para AWWG. Se corrige la clasificación de productos como Linux Kernel cuando la descripción cita también PHP.
- Se actualizan automáticamente los titulares y acciones generados antiguamente para CVEs de CISA **solo si no se habían editado manualmente**. Las revisiones humanas se respetan.
- Las tarjetas, tablas, fichas y portada evitan cortar palabras y crear páginas suplementarias casi vacías. El texto completo permanece en las **Notas de diapositiva** del PPTX editable.
- El informe continúa generándose en PPTX y PDF desde una única plantilla.
- Se eliminan los avisos `prompt()` de token. En su lugar aparece **un solo campo de acceso integrado en la página**, únicamente si la API responde 401; el token se conserva durante la pestaña abierta. **La autorización del servidor se mantiene**.
- Las descargas y la página se sirven con `Cache-Control: no-store` para evitar abrir versiones antiguas con el mismo nombre.

## Actualizar la instalación existente sin perder datos

Descarga el archivo **`CyberRad_AWWG_Weekly_6_3_HOTFIX.zip`** (se puede subir a GitHub), descomprímelo en Kali y ejecútalo desde la carpeta extraída:

```bash
unzip CyberRad_AWWG_Weekly_6_3_HOTFIX.zip -d /tmp/cyberrad-weekly-hotfix
sudo bash /tmp/cyberrad-weekly-hotfix/actualizar_weekly_kali.sh /opt/cyberrad-awwg
```

Si CyberRad está en otra carpeta, sustituye `/opt/cyberrad-awwg` por esa ubicación. Para identificar la carpeta usada por Docker Compose:

```bash
sudo docker inspect cyberrad-awwg --format '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}'
```

El actualizador comprueba la estructura del proyecto, guarda una copia de seguridad de los ficheros modificados en `/var/backups/cyberrad-awwg`, copia únicamente los archivos del módulo semanal y reconstruye exclusivamente `cyberrad-awwg` con Docker Compose. No modifica `/etc/cyberrad-awwg/cyberrad.env`, `/var/lib/cyberrad-awwg`, los demás contenedores ni el proyecto Sauron. Requiere permisos de administrador en Kali.

**Si la carpeta de trabajo no está confirmada, NO ejecutes el script contra una ruta elegida al azar.**

## Verificaciones

```bash
sudo docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'
sudo docker logs --tail=50 cyberrad-awwg
curl -fsS http://172.19.27.139:7374/healthz
```

La última dirección corresponde a la IP y al puerto de tu Kali **cuando se hicieron las capturas**. Si Hyper-V cambia la IP, consulta `ip -br -4 addr` y `sudo docker ps` antes de probar. Si finalmente publicas el contenedor solo en `127.0.0.1`, comprueba `http://127.0.0.1:7374/healthz` en su lugar.

Abre `/weekly`, actualiza la pestaña con `Ctrl+Shift+R` y pulsa **Generar informe semanal**. El calendario ya no debe apuntar automáticamente al lunes de la semana anterior. Si sigue habiendo token configurado, aparecerá un solo formulario **dentro** de Weekly Reports y no dos ventanas emergentes.

## Seguridad y alcance

No vacíes `CYBERRAD_WEEKLY_TOKEN` como atajo: el resto de CyberRad no dispone aún de autenticación empresarial. Evita publicar CyberRad fuera de Kali. En la configuración actual, el token de Weekly Reports sigue siendo necesario para proteger las rutas del módulo. El formulario de acceso no sustituye a una solución de autenticación centralizada.

El informe automático seguirá separando entradas CISA KEV (explotación confirmada públicamente) y noticias de prensa pendientes de revisar; **no se interpretará una CVE incluida en KEV como afectación probada de AWWG**. No se han añadido ni eliminado fuentes con este hotfix y no se han verificado noticias en directo.
