#!/usr/bin/env bash
# CyberRad AWWG Weekly v6.8: adaptive layout + conditional Hackmanac comparison.
# Does not modify DB, reports, secrets, settings, Sauron, or other Docker services.
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$HERE/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
DEST="$TARGET/weekly_awwg"
ENV_FILE='/etc/cyberrad-awwg/cyberrad.env'
COMPOSE_FILE="$TARGET/docker-compose.kali.yml"
FILES=(weekly.html router.py pptx_report.py hackmanac.py)
for path in "$TARGET/weekly_awwg/engine.py" "$TARGET/weekly_awwg/enrichment.py" "$COMPOSE_FILE" "$ENV_FILE"; do
 [[ -f "$path" ]] || { echo "Falta $path; sin cambios" >&2; exit 2; }
done
for f in "${FILES[@]}"; do
 [[ -f "$SOURCE/$f" ]] || { echo "Falta $f en el ZIP; sin cambios" >&2; exit 2; }
done
for f in router.py weekly.html pptx_report.py; do
 [[ -f "$DEST/$f" ]] || { echo "Falta instalación base $f; sin cambios" >&2; exit 2; }
done
if ! grep -q 'def enrich_selected' "$DEST/enrichment.py" || ! grep -q 'report_mode' "$DEST/engine.py"; then
 echo 'Requiere Weekly Reports v6.6. Instálala primero.' >&2; exit 3
fi
command -v docker >/dev/null && docker compose version >/dev/null || { echo 'Docker Compose v2 no disponible' >&2; exit 4; }
docker inspect cyberrad-awwg >/dev/null 2>&1 || { echo 'No se encontró cyberrad-awwg' >&2; exit 4; }
PYTHONDONTWRITEBYTECODE=1 python3 - "$SOURCE" <<'PYCODE'
from pathlib import Path
import sys
root=Path(sys.argv[1])
for filename in ('router.py','pptx_report.py','hackmanac.py'):
 p=root/filename;compile(p.read_text(encoding='utf-8'),str(p),'exec')
h=(root/'weekly.html').read_text(encoding='utf-8')
assert 'nav-sector' not in h and 'id="sector"' not in h and 'report-mode' in h
assert 'hackmanac.compare_selected' in (root/'router.py').read_text(encoding='utf-8')
assert 'def _detail_layout' in (root/'pptx_report.py').read_text(encoding='utf-8')
print('Verificación estática v6.8: OK')
PYCODE
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config -q
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.8-${STAMP}.tar.gz"
EXISTING=(weekly_awwg/weekly.html weekly_awwg/router.py weekly_awwg/pptx_report.py)
WAS_NEW=1
if [[ -f "$DEST/hackmanac.py" ]]; then
 EXISTING+=(weekly_awwg/hackmanac.py)
 WAS_NEW=0
fi
tar -C "$TARGET" -czf "$BACKUP" "${EXISTING[@]}"
rollback() {
 echo 'La actualización falló: restaurando los archivos previos…' >&2
 if (( WAS_NEW == 1 )); then rm -f -- "$DEST/hackmanac.py"; fi
 tar -C "$TARGET" -xzf "$BACKUP" || true
 docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad || true
 echo "Respaldo: $BACKUP" >&2
}
trap rollback ERR
for f in "${FILES[@]}"; do install -m 0644 -- "$SOURCE/$f" "$DEST/$f"; done
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad
[[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg)" == 'true' ]]
docker exec cyberrad-awwg python3 -c 'from weekly_awwg import hackmanac,pptx_report; assert hasattr(hackmanac,"compare_selected") and hasattr(pptx_report,"_detail_layout"); print("Weekly v6.8 activo")'
trap - ERR
printf 'CyberRad v6.8 instalado. Backup: %s\n' "$BACKUP"
echo 'Los datos, informes históricos, secretos, tokens y Sauron se han conservado.'
echo 'Abre Weekly Reports, fuerza recarga y genera un nuevo PDF/PPTX.'
