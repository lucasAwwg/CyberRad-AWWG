#!/usr/bin/env bash
# CyberRad AWWG v6.12 FULL: base 6.3 y hotfixes hasta 6.12 integrados en ESTE ZIP.
# No descarga ningún ZIP ni toca recursos de Sauron.
set -Eeuo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP=/opt/cyberrad-awwg
ENV=/etc/cyberrad-awwg/cyberrad.env
DATA=/var/lib/cyberrad-awwg
COMPOSE="$APP/docker-compose.kali.yml"
MODE="${1:-}"
usage() { echo 'Uso: sudo bash instalar_cyberrad_full.sh nuevo|actualizar|verificar'; }
[[ "$MODE" == 'nuevo' || "$MODE" == 'actualizar' || "$MODE" == 'verificar' ]] || { usage; exit 2; }
(( EUID == 0 )) || { echo 'Ejecuta con sudo.' >&2; exit 2; }

verify_source() {
  echo '[1/4] Verificando integridad del paquete completo...'
  ( cd "$HERE" && sha256sum --quiet -c SHA256SUMS ) || { echo 'El ZIP no coincide con los hashes. Deteniendo.' >&2; return 3; }
  python3 - "$HERE" <<'PYTEST'
from pathlib import Path
import sys
p=Path(sys.argv[1])
for f in sorted((p/'weekly_awwg').glob('*.py')):
 compile(f.read_text(encoding='utf-8'),str(f),'exec')
for f in sorted((p/'app').glob('*.py')):
 compile(f.read_text(encoding='utf-8'),str(f),'exec')
assert (p/'data/cyberrad_v4.db').is_file()
assert (p/'weekly_awwg/enrichment.py').is_file()
assert (p/'weekly_awwg/hackmanac.py').is_file()
assert all(marker in (p/'weekly_awwg/engine.py').read_text() for marker in ('report_mode','def assess_priority','def reassess_priorities','SUPPLY_CHAIN_RISK'))
assert 'bubble-severity' in (p/'weekly_awwg/weekly.html').read_text(encoding='utf-8')
print('Fuentes Python e integridad: OK')
PYTEST
}

ensure_docker() {
  command -v openssl >/dev/null 2>&1 || { echo 'Falta openssl.' >&2; return 4; }
  command -v docker >/dev/null 2>&1 || { echo 'Falta Docker Engine.' >&2; return 4; }
  docker compose version >/dev/null 2>&1 || { echo 'Falta Docker Compose v2.' >&2; return 4; }
  docker info >/dev/null 2>&1 || { echo 'Docker no responde. Comprueba sudo systemctl start docker.' >&2; return 4; }
}

start_only_cyberrad() {
  docker compose --project-directory "$APP" --env-file "$ENV" -f "$COMPOSE" config -q
  # No modificar ningún otro servicio, contenedor, volumen o imagen.
  docker compose --project-directory "$APP" --env-file "$ENV" -f "$COMPOSE" up -d --build --no-deps cyberrad
}

check_running() {
  [[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg 2>/dev/null)" == 'true' ]] || return 1
  docker exec cyberrad-awwg python3 -c "from weekly_awwg import engine,router,pptx_report,enrichment,hackmanac; assert all([hasattr(engine,'select_for_report'),hasattr(engine,'reassess_priorities'),hasattr(engine,'assess_priority'),hasattr(enrichment,'enrich_selected'),hasattr(hackmanac,'compare_selected'),hasattr(pptx_report,'_detail_layout')])"
  # /healthz interno: no exige publicar un puerto hacia Internet.
  local ok=0
  for n in $(seq 1 24); do
    if docker exec cyberrad-awwg python3 -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:3000/healthz',timeout=3).read()" >/dev/null 2>&1; then ok=1; break; fi
    sleep 2
  done
  [[ "$ok" == 1 ]] || return 1
}

if [[ "$MODE" == verificar ]]; then
  verify_source
  echo 'ZIP completo OK. Si hay CyberRad instalado, comprobando su salud...'
  if [[ -f "$COMPOSE" ]] && docker container inspect cyberrad-awwg >/dev/null 2>&1; then
    ensure_docker; check_running && echo 'CyberRad instalado y saludable.' || { echo 'Contenedor no saludable.' >&2; exit 1; }
  else
    echo 'Todavía no se ha detectado una instalación activa.'
  fi
  exit 0
fi

# Require Python+sha256sum, but never upgrade a Docker Engine running Sauron.
command -v python3 >/dev/null 2>&1 && command -v sha256sum >/dev/null 2>&1 || {
 echo 'Necesitas python3 y coreutils (normalmente preinstalados en Kali).' >&2; exit 2;
}
verify_source
ensure_docker

if [[ "$MODE" == nuevo ]]; then
  echo '[2/4] Comprobando que no existe una instalación previa...'
  [[ ! -e "$APP" ]] || { echo "$APP ya existe. Usa actualizar; no se sobreescribe." >&2; exit 3; }
  ! docker container inspect cyberrad-awwg >/dev/null 2>&1 || { echo 'Ya existe el contenedor cyberrad-awwg.' >&2; exit 3; }
  echo '[3/4] Instalando la aplicación COMPLETA, con todos los hotfixes integrados...'
  bash "$HERE/instalar_kali_sistema.sh"
  echo '[4/4] Construyendo e iniciando únicamente CyberRad...'
  if ! start_only_cyberrad; then
    echo 'El arranque falló. Se conservan código, configuración y datos para diagnóstico; no se borra nada.' >&2
    exit 5
  fi
  if ! check_running; then
    echo 'CyberRad arrancó pero no ha superado /healthz. Revisa: sudo docker logs --tail=100 cyberrad-awwg' >&2
    exit 6
  fi
  echo 'CyberRad AWWG FULL v6.12 instalado con éxito.'
  echo 'Interfaz local: http://127.0.0.1:3001/weekly (si se conserva el puerto por defecto).'
  echo 'Configuración protegida: /etc/cyberrad-awwg/cyberrad.env'
  printf 'IA opcional: sudo python3 %q\n' "$HERE/configurar_ia_weekly.py"
  echo 'Sauron no ha sido modificado.'
  exit 0
fi

# Actualización conservadora: solo reemplazar los módulos Weekly que cambiaron desde v6.3.
[[ -f "$COMPOSE" && -f "$ENV" ]] || { echo 'No se encuentra CyberRad previo en /opt y /etc.' >&2; exit 3; }
[[ -d "$APP/weekly_awwg" && -f "$APP/weekly_awwg/engine.py" ]] || { echo 'No se ha encontrado el módulo Weekly original.' >&2; exit 3; }
[ -d "$DATA" ] || { echo 'Falta el directorio de datos. Se cancela por seguridad.' >&2; exit 3; }

echo '[2/4] Preparando copia de seguridad del módulo Weekly y de su base SQLite...'
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-full-v6.12-$STAMP.tar.gz"
WEEKLY_DB="$DATA/weekly_awwg/weekly.sqlite3"
BACKUP_DB="/var/backups/cyberrad-awwg/weekly-full-v6.12-$STAMP.sqlite3"
# SQLite online backup is transactionally consistent with WAL mode, unlike cp/tar of a live database.
if [[ -f "$WEEKLY_DB" ]]; then
  python3 - "$WEEKLY_DB" "$BACKUP_DB" <<'PYDB'
import sqlite3,sys
src=sqlite3.connect('file:'+sys.argv[1]+'?mode=ro',uri=True,timeout=30)
dst=sqlite3.connect(sys.argv[2],timeout=30)
try:
 src.backup(dst)
 assert dst.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
finally:
 dst.close();src.close()
print('Copia de seguridad SQLite coherente: OK')
PYDB
  chmod 0600 "$BACKUP_DB"
else
  echo 'No hay base Weekly anterior para respaldar; se creará al arrancar.'
fi
FILES=(engine.py router.py pptx_report.py weekly.html enrichment.py hackmanac.py)
EXISTING=(); ADDED=()
for f in "${FILES[@]}"; do
  [[ -f "$HERE/weekly_awwg/$f" ]] || { echo "Fuente ausente: $f" >&2; exit 3; }
  if [[ -f "$APP/weekly_awwg/$f" ]]; then EXISTING+=("weekly_awwg/$f"); else ADDED+=("weekly_awwg/$f"); fi
done
(( ${#EXISTING[@]} > 0 )) || { echo 'No hay archivos Weekly que respaldar.' >&2; exit 3; }
tar -C "$APP" -czf "$BACKUP" "${EXISTING[@]}"
chmod 600 "$BACKUP"

CHANGED=0
rollback() {
  if (( CHANGED == 1 )); then
    echo 'Fallo de actualización: restaurando los archivos Weekly anteriores.' >&2
    for p in "${ADDED[@]}"; do rm -f -- "$APP/$p"; done
    tar -C "$APP" -xzf "$BACKUP" || true
    docker compose --project-directory "$APP" --env-file "$ENV" -f "$COMPOSE" up -d --build --no-deps cyberrad || true
  fi
  echo "Copia de seguridad del código: $BACKUP" >&2
  if [[ -f "$BACKUP_DB" ]]; then
    echo "Copia de SQLite anterior: $BACKUP_DB" >&2
    echo 'Si la migración hubiera terminado antes del fallo, examina la BD antes de restaurarla manualmente con el servicio detenido.' >&2
  fi
}
trap rollback ERR
CHANGED=1
for f in "${FILES[@]}"; do install -m 0644 -- "$HERE/weekly_awwg/$f" "$APP/weekly_awwg/$f"; done
chown root:root "$APP/weekly_awwg"/{engine.py,router.py,pptx_report.py,weekly.html,enrichment.py,hackmanac.py}
echo '[3/4] Reconstruyendo únicamente CyberRad...'
start_only_cyberrad
echo '[4/4] Comprobando /healthz y reclasificando prioridades existentes...'
check_running
# docker exec -i is mandatory here; without stdin forwarding the script would never run.
docker exec -i cyberrad-awwg python3 - <<'PYMIGRATION'
from weekly_awwg import engine
import json
assert engine.assess_priority({'title':'Windows CVSS 9.8','category':'Operating systems'},engine.DEFAULT)=='CRITICAL'
assert engine.assess_priority({'title':'WordPress supply chain risk CVSS 9.8','category':'CMS and e-commerce'},engine.DEFAULT)=='MID'
result=engine.reassess_priorities()
with engine.connect() as con:
 total=con.execute('SELECT COUNT(*) FROM news').fetchone()[0]
 tally={row[0]:row[1] for row in con.execute('SELECT priority,COUNT(*) FROM news GROUP BY priority')}
print('Noticias existentes reclasificadas:',json.dumps(result,ensure_ascii=False))
print('Severidades tras migración:',json.dumps({'total':total,**tally},ensure_ascii=False))
PYMIGRATION
CHANGED=0
trap - ERR
printf 'Actualización FULL v6.12 correcta. Copia de seguridad: %s\n' "$BACKUP"
echo 'Se han actualizado exclusivamente los módulos Weekly y, cuando procede, las prioridades automáticas de noticias.'
echo 'Informes, ediciones manuales, tokens, ajustes, datos restantes y Sauron se conservan.'
[[ ! -f "$BACKUP_DB" ]] || printf 'Copia de seguridad de SQLite: %s\n' "$BACKUP_DB"
