#!/usr/bin/env bash
# CyberRad AWWG Weekly v6.12 — Evidence-based severity + reliable DB migration.
# Isolated: does not alter Sauron, system firewall, historic reports, tokens or passwords.
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta este instalador con sudo.' >&2; exit 1; fi
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$HERE/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
DEST="$TARGET/weekly_awwg"
ENV_FILE=/etc/cyberrad-awwg/cyberrad.env
COMPOSE_FILE="$TARGET/docker-compose.kali.yml"
DATA_DIR=/var/lib/cyberrad-awwg/weekly_awwg
DB_FILE="$DATA_DIR/weekly.sqlite3"
BACKUP_DIR=/var/backups/cyberrad-awwg
FILES=(weekly.html engine.py)
for file in "$COMPOSE_FILE" "$ENV_FILE" "$DEST/router.py" "$DEST/enrichment.py"; do
  [[ -f "$file" ]] || { echo "Falta $file. No se han realizado cambios." >&2; exit 2; }
done
for file in "${FILES[@]}"; do
  [[ -f "$SOURCE/$file" && -f "$DEST/$file" ]] || { echo "Falta $file. No se han realizado cambios." >&2; exit 2; }
done
command -v docker >/dev/null && docker compose version >/dev/null || { echo 'Docker Compose v2 no disponible.' >&2; exit 4; }
docker inspect cyberrad-awwg >/dev/null 2>&1 || { echo 'Contenedor cyberrad-awwg no encontrado.' >&2; exit 4; }
PYTHONDONTWRITEBYTECODE=1 python3 - "$SOURCE" <<'PYCODE'
from pathlib import Path
import sys
src=Path(sys.argv[1])
compile((src/'engine.py').read_text(encoding='utf-8'),str(src/'engine.py'),'exec')
html=(src/'weekly.html').read_text(encoding='utf-8')
assert 'bubble-severity' in html and 'data-action=' in html
engine=(src/'engine.py').read_text(encoding='utf-8')
for marker in ('def reassess_priorities','def assess_priority','SUPPLY_CHAIN_RISK','CVSS_SCORE'):
 assert marker in engine,marker
print('Archivos del hotfix: verificados.')
PYCODE
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config -q
mkdir -p -- "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_CODE="$BACKUP_DIR/weekly-v6.12-before-$STAMP.tar.gz"
BACKUP_DB="$BACKUP_DIR/weekly-v6.12-before-$STAMP.sqlite3"
# Use SQLite online backup (consistent even if the database uses WAL).
if [[ -f "$DB_FILE" ]]; then
  python3 - "$DB_FILE" "$BACKUP_DB" <<'PYCODE'
import sqlite3,sys
src=sqlite3.connect('file:'+sys.argv[1]+'?mode=ro',uri=True,timeout=20)
dst=sqlite3.connect(sys.argv[2],timeout=20)
try:
 src.backup(dst)
 assert dst.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
finally:
 dst.close();src.close()
print('Copia consistente de SQLite: OK')
PYCODE
  chmod 0600 "$BACKUP_DB"
else
  echo 'Aviso: no existe una base de datos Weekly previa; no hay historial Weekly que copiar.'
fi
tar -C "$TARGET" -czf "$BACKUP_CODE" weekly_awwg/engine.py weekly_awwg/weekly.html
rollback() {
  echo 'Error durante la instalación. Restaurando archivos de código previos…' >&2
  tar -C "$TARGET" -xzf "$BACKUP_CODE" || true
  docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad || true
  echo "Copia de código: $BACKUP_CODE" >&2
  [[ -f "$BACKUP_DB" ]] && echo "Copia de SQLite (no se ha borrado la BD activa): $BACKUP_DB" >&2
}
trap rollback ERR
for file in "${FILES[@]}"; do install -m 0644 -- "$SOURCE/$file" "$DEST/$file"; done
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad
[[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg)" == 'true' ]]
# '-i' is ESSENTIAL: previous hotfix forgot stdin forwarding, so its migration never ran.
docker exec -i cyberrad-awwg python3 - <<'PYCODE'
from weekly_awwg import engine
import json
assert engine.assess_priority(dict(title='Windows CVSS 9.8',category='Operating systems'),engine.DEFAULT)=='CRITICAL'
assert engine.assess_priority(dict(title='WordPress supply chain risk CVSS 9.8',category='CMS and e-commerce'),engine.DEFAULT)=='MID'
result=engine.reassess_priorities()
with engine.connect() as con:
 total=con.execute('SELECT COUNT(*) FROM news').fetchone()[0]
 published={row[0]:row[1] for row in con.execute('SELECT priority,COUNT(*) FROM news GROUP BY priority')}
print('RECLASIFICACIÓN REAL:',json.dumps(result,ensure_ascii=False))
print('DISTRIBUCIÓN TOTAL:',json.dumps({'total':total,**published},ensure_ascii=False))
PYCODE
trap - ERR
printf '\nCyberRad Weekly v6.12 instalado correctamente.\nCódigo anterior: %s\n' "$BACKUP_CODE"
[[ -f "$BACKUP_DB" ]] && printf 'SQLite anterior: %s\n' "$BACKUP_DB"
echo 'No se han modificado Sauron, los secretos ni el histórico de informes.'
echo 'Ahora abre Weekly Reports > Revisión de noticias y pulsa Ctrl+Shift+R.'
