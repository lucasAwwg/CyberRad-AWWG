# CyberRad AWWG v6.12.1 FULL

Paquete **completo** con CyberRad base 6.3 y todas las mejoras hasta v6.12 fusionadas en el propio código. No hay que instalar hotfixes ni descargar ZIPs adicionales.

Lee `LEEME_INSTALACION_COMPLETA.md` para instalar en una Kali nueva o actualizar CyberRad conservando su histórico y los recursos de Sauron.

Comandos rápidos en el directorio extraído:

```bash
sudo bash instalar_cyberrad_full.sh nuevo      # En Kali sin CyberRad anterior
sudo bash instalar_cyberrad_full.sh actualizar # CyberRad ya instalado
sudo bash instalar_cyberrad_full.sh verificar  # Integridad y salud
```

**Nota:** los requisitos del sistema y las imágenes Docker no van incluidos. El servicio web se enlaza únicamente a localhost por defecto.

## v6.12.1 — Selección automática y generación

Corrige informes con cero noticias cuando existían aprobaciones automáticas. Las aprobaciones automáticas se incluyen antes de completar con noticias según configuración. Incluye vista previa con desglose Manual/Automático y evita exportar PDF/PPTX sin noticias.
