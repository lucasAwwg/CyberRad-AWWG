# CyberRad AWWG Weekly v6.10 — Bubble Navigator

Hotfix visual para la pestaña **Revisión de noticias**.

## Cambios
- Sustituye la exploración lineal inicial por **burbujas transparentes** con efecto cristal.
- Fila principal por **categoría / producto / familia tecnológica**.
- **Subburbujas** dentro de grupos amplios, por ejemplo Windows > BitLocker o Linux > Linux kernel.
- Fila alternativa por **severidad** (CRITICAL, HIGH, MID, LOW).
- Mantiene el filtrado por estado (pendiente, incluido, excluido) y la lista inferior con acciones editoriales.

## Instalación
```bash
sudo bash actualizar_weekly_kali.sh /opt/cyberrad-awwg
```

## Compatibilidad
Probado para instalaciones derivadas de v6.8 / v6.9.
