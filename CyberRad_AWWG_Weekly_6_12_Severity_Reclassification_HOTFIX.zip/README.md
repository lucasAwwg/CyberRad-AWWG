# CyberRad AWWG Weekly v6.12 — Severidad corregida

Parche sobre Weekly v6.11 / v6.9 FULL. Incluye la interfaz de burbujas v6.11 y actualiza las reglas del motor.

## Reglas

- **CRITICAL**: únicamente CVSS/severity score **>= 9.0 mencionado explícitamente** en el título o resumen, y una tecnología/producto reconocible presente en las **Palabras y tecnologías de interés** de AWWG y en una categoría de vigilancia habilitada. No basta con que el titular diga «critical».
- **HIGH**: CVSS 7.0–8.9, explotación conocida, RCE, ransomware, brechas u otras señales fuertes; si hay CVSS >=9 pero el producto no está vigilado, como máximo HIGH.
- **MID**: CVSS 4.0–6.9, CVE, fallos técnicos y parches con información relevante. **Riesgo de cadena de suministro: siempre MID**, con precedencia sobre los demás criterios.
- **LOW**: información sin indicadores suficientes de riesgo técnico mayor.

Son **prioridades preliminares de inteligencia**, no validación del impacto real en AWWG. No se inventan puntuaciones CVSS cuando la fuente no las especifica.

## Migración

El script:
1. Crea respaldo del código del módulo y copia SQLite consistente usando `sqlite3.backup`.
2. Instala `engine.py` y `weekly.html` solamente.
3. Recrea **solo** el servicio Docker de CyberRad.
4. Ejecuta la reclasificación dentro del contenedor usando `docker exec -i`, reparando el fallo del hotfix 6.11.
5. Muestra cuántas noticias cambiaron y la distribución real por severidad.

La migración **no cambia** las prioridades que un analista haya modificado manualmente (identificadas por el audit trail), ni cambia el estado editorial, las noticias, los informes históricos, los tokens o Sauron.

Las prioridades se recalculan automáticamente de nuevo cuando cambies las palabras de interés o categorías de vigilancia en Configuración.

## Instalación

```bash
sudo bash actualizar_weekly_kali.sh /opt/cyberrad-awwg
```

## Nota

Si una noticia queda LOW, puede deberse a que el RSS no contiene más datos que un titular genérico. La IA que amplía las **noticias seleccionadas** no reclasifica automáticamente las otras 180; no se deducen puntuaciones ausentes de los titulares. Para conocer una puntuación fiable hay que comprobar el boletín del fabricante o la fuente CVE.
