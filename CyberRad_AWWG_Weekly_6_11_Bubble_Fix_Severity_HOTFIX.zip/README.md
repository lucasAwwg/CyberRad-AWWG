# CyberRad AWWG Weekly v6.11 — Bubble Fix + Smarter Severity

## Corrige
- Burbujas deformadas por textos largos.
- Click en burbujas que no filtraba bien por grupo / subgrupo / severidad.
- Evaluación preliminar de severidad demasiado conservadora para noticias de prensa.

## Mejora
- Las noticias que mencionen explotación activa, RCE, zero-day, ransomware, takeover, auth bypass, privilege escalation o brecha pasan a HIGH de forma preliminar.
- Las noticias con CVE o impacto técnico moderado pasan a MID en vez de LOW.
- LOW queda para noticias informativas o sin suficiente gravedad técnica en el titular/resumen.

## Instalación
```bash
sudo bash actualizar_weekly_kali.sh /opt/cyberrad-awwg
```

## Nota
La prioridad sigue siendo editable manualmente desde la interfaz.
