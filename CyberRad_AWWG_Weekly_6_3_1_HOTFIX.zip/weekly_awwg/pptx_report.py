"""Native editable A4 PowerPoint output for AWWG Weekly Reports.

Source of layout: user-supplied 30 October AWWG PDF (visual master).
PDF is exported from *the same* PPTX, so there cannot be two diverging layouts.
Every narrative, table cell, chart, and label is a PowerPoint shape/textbox.
"""
from __future__ import annotations
from pathlib import Path
from datetime import date
from collections import Counter
from xml.etree import ElementTree as ET
import math
import os
import shutil
import subprocess
import tempfile
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Pt
from pptx.dml.color import RGBColor
from . import engine

# Coordinates measured from original 595.2 x 841.92-pt A4 pages.
W,H=595.2,841.92
TEAL='#00506F';HEADER='#005675';BG='#FBFAF8';LIGHT='#E6F3FA'
GRAY='#E9F0F4';TINT1='#D1D9E7';TINT2='#E8ECF5'
RISK={'CRITICAL':'#B73A32','HIGH':'#D25449','MID':'#D4823B','LOW':'#597282'}
COLORS={'dark':'#22292C','muted':'#626D73'}


def col(c):return RGBColor.from_string(c.lstrip('#').upper())


def no_effect(shape):
 for e in shape._element.xpath('./p:style/a:effectRef'):e.set('idx','0')


def rect(s,x,y,w,h,fill,round=False,border=None):
 sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if round else MSO_SHAPE.RECTANGLE,Pt(x),Pt(y),Pt(w),Pt(h))
 sh.fill.solid();sh.fill.fore_color.rgb=col(fill)
 if border:
  sh.line.color.rgb=col(border);sh.line.width=Pt(.6)
 else:sh.line.fill.background()
 no_effect(sh)
 if round:
  try:sh.adjustments[0]=.07
  except:pass
 return sh


def txt(s,text,x,y,w,h,size=8.6,color=COLORS['dark'],bold=False,align=None,wrap=True,spacing=1.06):
 sh=s.shapes.add_textbox(Pt(x),Pt(y),Pt(w),Pt(h));tf=sh.text_frame
 tf.clear();tf.word_wrap=wrap
 tf.margin_left=Pt(0);tf.margin_right=Pt(0);tf.margin_top=Pt(0);tf.margin_bottom=Pt(0)
 tf.vertical_anchor=MSO_ANCHOR.TOP
 for j,line in enumerate(str(text or '').split('\n')):
  p=tf.paragraphs[0] if j==0 else tf.add_paragraph()
  p.space_before=Pt(0);p.space_after=Pt(0)
  p.line_spacing=spacing
  if align is not None:p.alignment=align
  r=p.add_run();r.text=line;r.font.name='Arial';r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=col(color)
 return sh


def concise(value, limit=200):
 """Readable visual excerpt; keep the full original in the slide's editable speaker notes."""
 value=' '.join(str(value or '').split())
 if len(value)<=limit:return value
 cut=value[:limit-1]
 # Preserve complete words and avoid awkward partial titles/CVE identifiers.
 pivot=max(cut.rfind('. '),cut.rfind('; '),cut.rfind(': '))
 if pivot>limit*.64:return cut[:pivot+1].rstrip() + '…'
 pivot=cut.rfind(' ')
 return (cut[:pivot] if pivot>limit*.7 else cut).rstrip(' ,.;')+'…'


def add_source_notes(slide, item):
 """Non-visible complete source material, retained in the editable PPTX."""
 try:
  fields=['original_title','title','source_url','published','summary','cves',
          'affected','fixed','cvss','verified_exploitation','company_impact','action']
  notes='\n\n'.join(f'{key}: {item.get(key, "")}' for key in fields)
  slide.notes_slide.notes_text_frame.text=notes
 except Exception:
  pass

def new_slide(prs,page,label='Cyber News Weekly Report'):
 slide=prs.slides.add_slide(prs.slide_layouts[6])
 rect(slide,0,0,W,H,'#FFFFFF')
 rect(slide,45.36,805.08,504.6,.6,'#E6E5E3')
 txt(slide,f'{label} · {page:%d/%m/%Y}',45.36,811.1,400,14,6.5,'#69727A')
 txt(slide,str(len(prs.slides)),465,810.5,32,14,7.8,'#20252A',align=PP_ALIGN.CENTER)
 return slide


def badge(s,prio,x,y):
 rect(s,x,y,45.4,14.4,RISK.get(prio,RISK['LOW']),True)
 txt(s,prio,x,y+2.0,45.4,12,7.8,'#FFFFFF',True,PP_ALIGN.CENTER,False)


def table(s, rows, x,y,widths,header=True, heights=None, font=8.1):
 cur=y
 for i,row in enumerate(rows):
  if heights and i<len(heights):h=heights[i]
  else:h=(23 if header and i==0 else 27)
  xx=x
  for j,(content,w) in enumerate(zip(row,widths)):
   bgcolor=HEADER if header and i==0 else (TINT1 if i%2==(1 if header else 0) else TINT2)
   rect(s,xx,cur,w,h,bgcolor)
   # No content is treated as trusted PowerPoint markup.
   tcolor='#FFFFFF' if header and i==0 else '#263039'
   fs=8.0 if header and i==0 else font
   # A moderate visual-size ceiling avoids overlaps with longer stories.
   if len(str(content))>80:fs=max(6.6,fs-.5)
   maxlen = max(36, int((w-11)/(fs*.48)) * max(1, int((h-7)/(fs*1.15))))
   txt(s,concise(content, min(110,maxlen)),xx+5.4,cur+5.0,w-11,h-6,fs,tcolor,header and i==0 or (not header and j==0 and False))
   xx+=w
  cur+=h
 return cur


def cover(prs,start,items):
 s=new_slide(prs,start)
 rect(s,0,0,W,226.8,TEAL)
 logo=Path(__file__).parent/'assets'/'awwg_logo.png'
 if logo.exists():s.shapes.add_picture(str(logo),Pt(45.36),Pt(33.72),Pt(180.72),Pt(51.72))
 else:txt(s,'AWWG',48,35,185,55,36,'#FFFFFF')
 txt(s,'Cyber News\nWeekly Report',45.36,112.5,440,94,27,'#FFFFFF',True,spacing=1.12)
 txt(s,f'Week of {start:%d %B %Y} · {len(items)} items reviewed',45.36,190.7,460,20,9.8,'#D9EBF1')
 tally=Counter(it['priority'] for it in items)
 for i,(label,val) in enumerate([('News',len(items)),('Critical',tally['CRITICAL']),('High',tally['HIGH']),('Mid',tally['MID']),('Low',tally['LOW'])]):
  x=45.36+i*102.96
  rect(s,x,249.12,92.88,62.64,'#FFFFFF',True,'#E3E0DF')
  r=['#00506F',RISK['CRITICAL'],'#DF6558',RISK['MID'],'#7D98A6'][i]
  rect(s,x+3.6,249.12,85.68,2.88,r)
  txt(s,str(val),x+14,262.0,64,27,22.2,r,True)
  txt(s,label,x+14,295.0,70,15,8.6,'#202428')
 txt(s,'What we need to do this week',45.36,336.8,350,20,12.5,HEADER,True)
 body=items[:7]
 if not body:
  rect(s,45.36,360,504.48,62,BG,True)
  txt(s,'No verified items selected. The absence of an item does not establish that AWWG has no exposure.',56,373,480,40,9.2)
 else:
  # Reference cover holds seven rows. Additional stories appear in summary/details,
  # not crammed into illegibly thin rows.
  h=30.9
  for i,it in enumerate(body):
   y=358.8+h*i
   rect(s,45.36,y,224.2,h,'#EBF1F4')
   rect(s,269.56,y,70.4,h,'#FAE6E2' if it['priority'] in ('CRITICAL','HIGH') else '#F5ECDF' if it['priority']=='MID' else '#E8F0F3')
   rect(s,339.96,y,209.88,h,'#EBF1F4')
   fs=7.2 if h>25 else 6.7
   txt(s,concise(it['title'],76),49,y+5.2,215,h-5,fs)
   txt(s,it['priority'],276,y+5,60,h-4,fs,RISK[it['priority']],True)
   txt(s,concise(it['action'],104),345,y+4.5,201,h-4,fs)
  end=358.8+h*len(body)
  yy=min(728,end+21)
  rect(s,45.36,yy,504.48,56.16,BG,True)
  rect(s,45.36,yy,2.76,56.16,TEAL)
  txt(s,'Key point: Confirm deployment and exploitation evidence; prioritize applicable remediation and supplier exposure.',59.54,yy+20,470,29,8.4,TEAL)
 return s


def summary(prs,start,items):
 # Original uses 2 summary pages for seven stories. Dynamic paging keeps all items.
 groups=[items[i:i+4] for i in range(0,len(items),4)] or [[]]
 for index,g in enumerate(groups):
  s=new_slide(prs,start)
  txt(s,'The week in 2 minutes' + (' — continued' if index else ''),45.36,40.5,504,25,17.5,TEAL,True)
  txt(s,'One card per item: what happened, key facts, and what we do.',45.36,69.0,504,14,8.4,COLORS['muted'])
  card_ys=[94,212,330,448]
  for row,it in enumerate(g):
   y=card_ys[row]
   rect(s,45.36,y,504.48,104.7,BG,True)
   badge(s,it['priority'],59.52,y+8)
   txt(s,concise(it['title'],87),113,y+7,424,26,10.3,'#222629',True)
   txt(s,f"Source: {it['source']} · {it['published']}",60,y+25,450,18,8.3,'#0059B5')
   txt(s,concise(it['summary'],215),66.6,y+43,465,40,8.2)
   rect(s,59.8,y+85.3,478,.45,'#DDDFE0')
   txt(s,'Our action → '+concise(it['action'],115),66.6,y+87,464,18,7.6,TEAL)
  y=621 if len(g)>2 else 500
  txt(s,'Risk classification framework',45.36,y,450,20,12.2,TEAL,True)
  risk_items=[('CRITICAL','Extreme & immediate','Emergency action when confirmed.'),('HIGH','Targeted & proven','Review exposure and act this week.'),('MID','Tactical & indirect','Monitor and harden segments.'),('LOW','Strategic / informative','Routine follow-up and planning.')]
  for i,(p,t,desc) in enumerate(risk_items):
   x=45.36+i*126.4
   rect(s,x,y+33,119,69,'#FBE7E5' if i<2 else '#FAECDF' if i==2 else '#E6EDF1',True)
   badge(s,p,x+7,y+38)
   txt(s,t,x+7,y+56,108,16,8.5,'#17282A',True)
   txt(s,desc,x+7,y+70,108,30,7.5)
 return groups


def details(prs,start,items):
 for it in items:
  s=new_slide(prs,start)
  priority=it.get('priority','LOW')
  badge(s,priority,45.4,44.0)
  title=concise(it['title'],81)
  txt(s,title,96,42,452,33,13.3,HEADER,True)
  rect(s,45.36,76.56,147.36,351,BG,True,'#E0DEDC')
  # Each label/value is native text and can be changed in PowerPoint.
  side=[('PRODUCT / CATEGORY',it.get('category','Unassessed')),
        ('CVE(S)',', '.join(it.get('cves') or []) or 'No CVE reported'),
        ('CVSS',it.get('cvss','Not verified')),
        ('PATCH STATUS',it.get('fixed','Not verified')),
        ('EXPLOITATION',it.get('verified_exploitation','Not verified')),
        ('AWWG STATUS','Not assessed' if 'not verified' in str(it.get('company_impact','')).lower() else it.get('company_impact','Unassessed')),
        ('SOURCE',it.get('source',''))]
  for index,(label,value) in enumerate(side):
   yy=87+index*47
   txt(s,label,56.9,yy,126,11,7.0,'#667078')
   txt(s,concise(value,63),56.9,yy+13,126,32,8.0,'#252C32',True)
  # Original sidebar/content alignment: x 206.69.
  txt(s,concise(it['summary'],330),206.69,70,342.7,75,9.0)
  rows=[['Field / issue','Current evidence / required response'],
   ['CVE(s)',', '.join(it.get('cves') or []) or 'No assigned CVE'],
   ['Affected versions',it.get('affected','Not verified')],
   ['Patch / fixed version',it.get('fixed','Not verified')],
   ['CVSS / vendor severity',str(it.get('cvss','Not verified'))+' / '+str(it.get('vendor_severity','Not verified'))],
   ['Exploitation',it.get('verified_exploitation','Not verified')]]
  table(s,rows,206.65,162,[126,216.7],header=True,heights=[22,32,35,35,34,34],font=7.9)
  txt(s,'AWWG impact: '+concise(it.get('company_impact','No confirmed direct impact.'),187),206.69,374,342,55,9.2,TEAL,True)
  rect(s,206.64,442,342.72,100,LIGHT,True)
  txt(s,'Recommended action: '+concise(it['action'],270),215.33,454,325,77,8.8)
  txt(s,'Sources',206.69,561,342,16,11.1,HEADER,True)
  txt(s,concise(it.get('source','')+' · '+it.get('source_url',''),200),206.69,581,342,50,7.8,'#0059B5')
  # Never add nearly-empty overflow pages or split a sentence mid-word.
  # Complete original fields are retained in editable PowerPoint speaker notes.
  add_source_notes(s,it)


def trend_page(prs,start,sector):
 if not sector or not sector.get('source'):return
 s=new_slide(prs,start)
 badge(s,'LOW',45.42,44)
 txt(s,'Hack Tuesday — Wholesale/Retail trends',96,42,454,25,14,TEAL,True)
 rect(s,45.36,76.56,147.36,330,BG,True,'#D8DBDE')
 for j,(label,key) in enumerate([('INDUSTRY','industry'),('CURRENT WEEK','attacks'),('PREVIOUS WEEK','previous_attacks'),('CURRENT RANK','rank'),('GLOBAL DATA, TB','data_tb'),('SOURCE','source')]):
  y=89+j*48
  txt(s,label,56.9,y,120,11,6.9,'#647179')
  txt(s,('Wholesale / Retail' if key=='industry' else str(sector.get(key,'Not reported')))[:83],56.9,y+13,126,31,8.5,'#252C32',True)
 txt(s,'Wholesale/Retail incident trends are derived only from the cited source. Unavailable metrics are not estimated.',206.69,70,342.7,49,9.3)
 try:
  a=float(sector['attacks']);b=float(sector['previous_attacks']);numbers=[b,a]
  labels=['Previous week','Current week'];maxx=max(numbers+[1])
  for n,v in enumerate(numbers):
   x=262+n*140;h=93*v/maxx
   rect(s,x,160+93-h,86,h,'#3193A0',True)
   txt(s,str(int(v) if v.is_integer() else v),x,146+93-h,86,15,8.5,TEAL,True,PP_ALIGN.CENTER)
   txt(s,labels[n],x-9,268,104,18,8.4,COLORS['muted'],align=PP_ALIGN.CENTER)
 except (ValueError,TypeError,KeyError):
  txt(s,'No comparable quantitative observations were provided. Chart omitted.',206.69,185,342,48,9.5,COLORS['muted'])
 txt(s,'AWWG impact: Informative sector context. Aggregated industry statistics do not establish an incident affecting AWWG.',206.69,358,342,54,9.0,TEAL,True)
 rect(s,206.64,418,342.72,83,LIGHT,True)
 txt(s,'Recommended action: Monitor retail and wholesale attacks, customer-data exposure, ransomware and supply-chain compromises.',215.33,431,325,61,9)
 rows=[['Metric','Current / previous'],['Retail attacks',f"{sector.get('previous_attacks','–')} → {sector.get('attacks','–')}"],['Sector ranking',f"{sector.get('previous_rank','–')} → {sector.get('rank','–')}"],['Claimed data (TB)',f"{sector.get('previous_data_tb','–')} → {sector.get('data_tb','–')}"]]
 table(s,rows,206.65,532,[126,216.7],True,heights=[25,25,25,25])


def make_pptx(start:date,end:date,items:list[dict],sector:dict|None=None)->Path:
 engine.initialize()
 out=engine.REPORTS/f'AWWG_Weekly_Report_{start.isoformat()}.pptx'
 prs=Presentation();prs.slide_width=Pt(W);prs.slide_height=Pt(H)
 prs.core_properties.title='AWWG Cyber News Weekly Report'
 cover(prs,start,items)
 summary(prs,start,items)
 details(prs,start,items)
 if sector:trend_page(prs,start,sector)
 tmp=out.with_suffix('.pptx.part')
 prs.save(tmp);os.replace(tmp,out)
 return out


def make_pdf_from_pptx(pptx_file:Path)->Path:
 """Same visual report as PPTX: LO exports the exact PPTX in a sandboxed temp path."""
 target=pptx_file.with_suffix('.pdf')
 lo=shutil.which('libreoffice') or shutil.which('soffice')
 if not lo:raise RuntimeError('PDF export requires LibreOffice on the CyberRad server; PPTX remains available.')
 with tempfile.TemporaryDirectory(prefix='cyberrad_pdf_') as tmp:
  work=Path(tmp);profile=(work/'profile').as_uri()
  try:
   done=subprocess.run([lo,f'-env:UserInstallation={profile}','--headless','--convert-to','pdf','--outdir',str(work),str(pptx_file)],capture_output=True,text=True,timeout=55,check=True)
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as exc:
   raise RuntimeError('PPTX-to-PDF conversion failed; inspect LibreOffice installation.') from exc
  result=work/(pptx_file.stem+'.pdf')
  if not result.exists() or result.stat().st_size<1000:raise RuntimeError('PDF converter did not produce a valid file')
  # /tmp can be a different filesystem from the persistent Docker bind mount.
  # Stage inside target.parent, then atomically rename on the SAME filesystem.
  # This fixes EXDEV / Invalid cross-device link without altering report contents.
  target.parent.mkdir(parents=True, exist_ok=True)
  fd,staged_name=tempfile.mkstemp(prefix='.'+target.stem+'-',suffix='.pdf.part',dir=str(target.parent))
  staged=Path(staged_name)
  try:
   with os.fdopen(fd,'wb') as dst, result.open('rb') as src:
    shutil.copyfileobj(src,dst,length=1024*1024)
    dst.flush()
    os.fsync(dst.fileno())
   os.replace(staged,target)
  finally:
   staged.unlink(missing_ok=True)
 return target
