"""Native editable A4 PowerPoint output for AWWG Weekly Reports.

Source of layout: user-supplied 30 October AWWG PDF (visual master).
PDF is exported from *the same* PPTX, so there cannot be two diverging layouts.
Every narrative, table cell, chart, and label is a PowerPoint shape/textbox.
"""
from __future__ import annotations
from pathlib import Path
from datetime import date
from collections import Counter
from xml.etree import ElementTree as ET
import math
import re
import textwrap
from urllib.parse import urlparse
import os
import shutil
import subprocess
import tempfile
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Pt
from pptx.dml.color import RGBColor
from . import engine

# Coordinates measured from original 595.2 x 841.92-pt A4 pages.
W,H=595.2,841.92
TEAL='#00506F';HEADER='#005675';BG='#FBFAF8';LIGHT='#E6F3FA'
GRAY='#E9F0F4';TINT1='#D1D9E7';TINT2='#E8ECF5'
RISK={'CRITICAL':'#B73A32','HIGH':'#D25449','MID':'#D4823B','LOW':'#597282'}
COLORS={'dark':'#22292C','muted':'#626D73'}


def col(c):return RGBColor.from_string(c.lstrip('#').upper())


def no_effect(shape):
 for e in shape._element.xpath('./p:style/a:effectRef'):e.set('idx','0')


def rect(s,x,y,w,h,fill,round=False,border=None):
 sh=s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if round else MSO_SHAPE.RECTANGLE,Pt(x),Pt(y),Pt(w),Pt(h))
 sh.fill.solid();sh.fill.fore_color.rgb=col(fill)
 if border:
  sh.line.color.rgb=col(border);sh.line.width=Pt(.6)
 else:sh.line.fill.background()
 no_effect(sh)
 if round:
  try:sh.adjustments[0]=.07
  except:pass
 return sh


def txt(s,text,x,y,w,h,size=8.6,color=COLORS['dark'],bold=False,align=None,wrap=True,spacing=1.06):
 sh=s.shapes.add_textbox(Pt(x),Pt(y),Pt(w),Pt(h));tf=sh.text_frame
 tf.clear();tf.word_wrap=wrap
 tf.margin_left=Pt(0);tf.margin_right=Pt(0);tf.margin_top=Pt(0);tf.margin_bottom=Pt(0)
 tf.vertical_anchor=MSO_ANCHOR.TOP
 for j,line in enumerate(str(text or '').split('\n')):
  p=tf.paragraphs[0] if j==0 else tf.add_paragraph()
  p.space_before=Pt(0);p.space_after=Pt(0)
  p.line_spacing=spacing
  if align is not None:p.alignment=align
  r=p.add_run();r.text=line;r.font.name='Arial';r.font.size=Pt(size);r.font.bold=bold;r.font.color.rgb=col(color)
 return sh


def concise(value, limit=200):
 """Readable visual excerpt; keep the full original in the slide's editable speaker notes."""
 value=' '.join(str(value or '').split())
 if len(value)<=limit:return value
 cut=value[:limit-1]
 # Preserve complete words and avoid awkward partial titles/CVE identifiers.
 pivot=max(cut.rfind('. '),cut.rfind('; '),cut.rfind(': '))
 if pivot>limit*.64:return cut[:pivot+1].rstrip() + '…'
 pivot=cut.rfind(' ')
 return (cut[:pivot] if pivot>limit*.7 else cut).rstrip(' ,.;')+'…'


def show_text(value):
 return engine.clean_content(str(value or ''),strip_markup=True)


def wrapped(value,width,fontsize,max_lines=2):
 """Words fitted into a known text rectangle; never render inside the next cell."""
 text=show_text(value)
 if not text:return ''
 # Conservative Arial width estimate; prevents PowerPoint and PDF font substitution overlaps.
 line_chars=max(9,int(width/(fontsize*0.59)))
 lines=textwrap.wrap(text,width=line_chars,break_long_words=False,break_on_hyphens=False)
 if len(lines)<=max_lines:return '\n'.join(lines)
 clipped=lines[:max_lines]
 last=clipped[-1].rstrip(' .;,:')
 if last.endswith('…'):return '\n'.join(clipped)
 clipped[-1]=last+'…'
 return '\n'.join(clipped)


def source_link(s, label, url, x,y,w,h, size=8.0, maxlines=2, prefix=''):
 """One readable clickable publisher label instead of a long duplicate URL."""
 if urlparse(str(url or '')).scheme not in ('https','http'):
  return txt(s,wrapped(prefix+show_text(label),w,size,maxlines),x,y,w,h,size,'#0059B5')
 sh=txt(s,wrapped(prefix+show_text(label),w,size,maxlines),x,y,w,h,size,'#0059B5')
 for para in sh.text_frame.paragraphs:
  for run in para.runs:
   run.hyperlink.address=str(url)
 return sh


def tidy_for_report(row):
 item=dict(row)
 title=show_text(item.get('title',''))
 src=show_text(item.get('source',''))
 summary=show_text(item.get('summary',''))
 if src=='Google News discovery' or 'via Google News' in src:
  suffix=re.search(r'\s[-–—]\s([\w.-]+\.(?:com|net|org|io|hu|co\.uk|es|de|fr))$',title,re.I)
  if suffix:
   if src=='Google News discovery': src=suffix.group(1)+' (via Google News)'
   title=title[:suffix.start()].rstrip()
  if summary.casefold().startswith(title.casefold()):
   summary=summary[len(title):].strip(' –—-.,')
  summary=re.sub(r'^(?:'+re.escape(src.replace(' (via Google News)',''))+r')\b[.,; ]*','',summary,flags=re.I)
  if len(summary)<75:
   summary='Headline-only discovery. Original article and vendor bulletin require verification before external distribution.'
 item['title']=title;item['summary']=summary;item['source']=src
 item['action']=show_text(item.get('action',''))
 item['company_impact']=show_text(item.get('company_impact',''))
 return item


def add_source_notes(slide, item):
 """Non-visible complete source material, retained in the editable PPTX."""
 try:
  fields=['original_title','title','source_url','published','summary','cves',
          'affected','fixed','cvss','verified_exploitation','company_impact','action']
  notes='\n\n'.join(f'{key}: {item.get(key, "")}' for key in fields)
  slide.notes_slide.notes_text_frame.text=notes
 except Exception:
  pass

def new_slide(prs,page,label='Cyber News Weekly Report'):
 slide=prs.slides.add_slide(prs.slide_layouts[6])
 rect(slide,0,0,W,H,'#FFFFFF')
 rect(slide,45.36,805.08,504.6,.6,'#E6E5E3')
 txt(slide,f'{label} · {page:%d/%m/%Y}',45.36,811.1,400,14,6.5,'#69727A')
 txt(slide,str(len(prs.slides)),465,810.5,32,14,7.8,'#20252A',align=PP_ALIGN.CENTER)
 return slide


def badge(s,prio,x,y):
 rect(s,x,y,45.4,14.4,RISK.get(prio,RISK['LOW']),True)
 txt(s,prio,x,y+2.0,45.4,12,7.8,'#FFFFFF',True,PP_ALIGN.CENTER,False)


def table(s, rows, x,y,widths,header=True, heights=None, font=8.1):
 cur=y
 for i,row in enumerate(rows):
  h=heights[i] if heights and i<len(heights) else (23 if header and i==0 else 27)
  xx=x
  for j,(content,w) in enumerate(zip(row,widths)):
   bgcolor=HEADER if header and i==0 else (TINT1 if i%2==(1 if header else 0) else TINT2)
   rect(s,xx,cur,w,h,bgcolor)
   tcolor='#FFFFFF' if header and i==0 else '#263039'
   fs=8.0 if header and i==0 else font
   maxlines=max(1,min(3,int((h-8)/(fs*1.22))))
   display=wrapped(content,w-11,fs,maxlines)
   txt(s,display,xx+5.4,cur+4.5,w-11,h-8,fs,tcolor,header and i==0)
   xx+=w
  cur+=h
 return cur


def cover(prs,start,items):
 s=new_slide(prs,start)
 rect(s,0,0,W,226.8,TEAL)
 logo=Path(__file__).parent/'assets'/'awwg_logo.png'
 if logo.exists():s.shapes.add_picture(str(logo),Pt(45.36),Pt(33.72),Pt(180.72),Pt(51.72))
 else:txt(s,'AWWG',48,35,185,55,36,'#FFFFFF')
 txt(s,'Cyber News\nWeekly Report',45.36,112.5,440,94,27,'#FFFFFF',True,spacing=1.12)
 txt(s,f'Week of {start:%d %B %Y} · {len(items)} items reviewed',45.36,190.7,460,20,9.8,'#D9EBF1')
 tally=Counter(it['priority'] for it in items)
 for i,(label,val) in enumerate([('News',len(items)),('Critical',tally['CRITICAL']),('High',tally['HIGH']),('Mid',tally['MID']),('Low',tally['LOW'])]):
  x=45.36+i*102.96
  rect(s,x,249.12,92.88,62.64,'#FFFFFF',True,'#E3E0DF')
  r=['#00506F',RISK['CRITICAL'],'#DF6558',RISK['MID'],'#7D98A6'][i]
  rect(s,x+3.6,249.12,85.68,2.88,r)
  txt(s,str(val),x+14,262.0,64,27,22.2,r,True)
  txt(s,label,x+14,295.0,70,15,8.6,'#202428')
 txt(s,'What we need to do this week',45.36,336.8,350,20,12.5,HEADER,True)
 body=items[:7]
 if not body:
  rect(s,45.36,360,504.48,62,BG,True)
  txt(s,'No verified items selected. The absence of an item does not establish that AWWG has no exposure.',56,373,480,40,9.2)
 else:
  # Reference cover holds seven rows. Additional stories appear in summary/details,
  # not crammed into illegibly thin rows.
  h=30.9
  for i,it in enumerate(body):
   y=358.8+h*i
   rect(s,45.36,y,224.2,h,'#EBF1F4')
   rect(s,269.56,y,70.4,h,'#FAE6E2' if it['priority'] in ('CRITICAL','HIGH') else '#F5ECDF' if it['priority']=='MID' else '#E8F0F3')
   rect(s,339.96,y,209.88,h,'#EBF1F4')
   fs=7.2 if h>25 else 6.7
   txt(s,wrapped(it['title'],215,fs,2),49,y+5.2,215,h-6,fs)
   txt(s,it['priority'],276,y+5,60,h-4,fs,RISK[it['priority']],True)
   txt(s,wrapped(it['action'],201,fs,2),345,y+4.5,201,h-6,fs)
  end=358.8+h*len(body)
  yy=min(728,end+21)
  rect(s,45.36,yy,504.48,56.16,BG,True)
  rect(s,45.36,yy,2.76,56.16,TEAL)
  txt(s,'Key point: Confirm deployment and exploitation evidence; prioritize applicable remediation and supplier exposure.',59.54,yy+20,470,29,8.4,TEAL)
 return s


def summary(prs,start,items):
 # Matches reference summary card geometry; text bands never overlap.
 groups=[items[i:i+4] for i in range(0,len(items),4)] or [[]]
 for index,g in enumerate(groups):
  s=new_slide(prs,start)
  txt(s,'The week in 2 minutes' + (' — continued' if index else ''),45.36,40.5,504,25,17.5,TEAL,True)
  txt(s,'One card per item: what happened, key facts, and what we do.',45.36,69,504,14,8.4,COLORS['muted'])
  card_ys=[94,212,330,448]
  for row,it in enumerate(g):
   y=card_ys[row]
   rect(s,45.36,y,504.48,104.7,BG,True)
   badge(s,it['priority'],59.52,y+8)
   txt(s,wrapped(it['title'],424,10.0,2),113,y+7,424,26,10.0,'#222629',True,spacing=1.02)
   source_link(s,it.get('source','Source'),it.get('source_url',''),65,y+36,462,13,7.7,1,prefix='Source: ')
   txt(s,wrapped(it.get('summary'),462,8.0,3),65,y+52,462,30,8.0,spacing=1.03)
   rect(s,59.8,y+82.3,478,.45,'#DDDFE0')
   txt(s,wrapped('Our action → '+it.get('action',''),462,7.4,2),65,y+86,462,18,7.4,TEAL,spacing=1.02)
   add_source_notes(s,it)
  y=621 if len(g)>2 else 500
  txt(s,'Risk classification framework',45.36,y,450,20,12.2,TEAL,True)
  risk_items=[('CRITICAL','Extreme & immediate','Emergency action when confirmed.'),('HIGH','Targeted & proven','Review exposure and act this week.'),('MID','Tactical & indirect','Monitor and harden segments.'),('LOW','Strategic / informative','Routine follow-up and planning.')]
  for i,(p,t,desc) in enumerate(risk_items):
   x=45.36+i*126.4
   rect(s,x,y+33,119,69,'#FBE7E5' if i<2 else '#FAECDF' if i==2 else '#E6EDF1',True)
   badge(s,p,x+7,y+38)
   txt(s,t,x+7,y+56,108,16,8.5,'#17282A',True)
   txt(s,wrapped(desc,108,7.5,3),x+7,y+70,108,30,7.5)
 return groups


def details(prs,start,items):
 for it in items:
  s=new_slide(prs,start)
  priority=it.get('priority','LOW')
  badge(s,priority,45.4,44)
  txt(s,wrapped(it['title'],452,12.5,2),96,42,452,33,12.5,HEADER,True,spacing=1.03)
  rect(s,45.36,76.56,147.36,351,BG,True,'#E0DEDC')
  side=[('PRODUCT / CATEGORY',it.get('category','Unassessed')),
        ('CVE(S)',', '.join(it.get('cves') or []) or 'No CVE reported'),
        ('CVSS',it.get('cvss','Not verified')),
        ('PATCH STATUS',it.get('fixed','Not verified')),
        ('EXPLOITATION',it.get('verified_exploitation','Not verified')),
        ('AWWG STATUS','Not assessed' if 'not verified' in str(it.get('company_impact','')).lower() else it.get('company_impact','Unassessed')),
        ('SOURCE',it.get('source',''))]
  for index,(label,value) in enumerate(side):
   yy=87+index*47
   txt(s,label,56.9,yy,126,11,7.0,'#667078')
   if label=='SOURCE':
    source_link(s,value,it.get('source_url',''),56.9,yy+13,125,30,7.8,2)
   else:
    txt(s,wrapped(value,126,7.8,2),56.9,yy+13,126,32,7.8,'#252C32',True)
  txt(s,wrapped(it.get('summary',''),342,8.85,6),206.69,80,342.7,69,8.85,spacing=1.04)
  rows=[['Field / issue','Current evidence / required response'],
   ['CVE(s)',', '.join(it.get('cves') or []) or 'No assigned CVE'],
   ['Affected versions',it.get('affected','Not verified')],
   ['Patch / fixed version',it.get('fixed','Not verified')],
   ['CVSS / vendor severity',str(it.get('cvss','Not verified'))+' / '+str(it.get('vendor_severity','Not verified'))],
   ['Exploitation',it.get('verified_exploitation','Not verified')]]
  table(s,rows,206.65,162,[126,216.7],header=True,heights=[22,32,35,35,34,34],font=7.9)
  impact=it.get('company_impact','No confirmed direct impact.')
  if it.get('_selection')=='auto_draft':
   impact='AUTO-DRAFT / NOT VALIDATED — '+impact
  txt(s,wrapped('AWWG impact: '+impact,342,9.0,4),206.69,374,342,55,9.0,TEAL,True)
  rect(s,206.64,442,342.72,100,LIGHT,True)
  txt(s,wrapped('Recommended action: '+it.get('action',''),325,8.8,7),215.33,454,325,78,8.8)
  # One source only: clickable publisher in LEFT sidebar; full URL in notes.
  # Removing the former duplicate Sources/URL block also prevents ugly long URLs.
  add_source_notes(s,it)


def trend_page(prs,start,sector):
 if not sector or not sector.get('source'):return
 s=new_slide(prs,start)
 badge(s,'LOW',45.42,44)
 txt(s,'Hack Tuesday — Wholesale/Retail trends',96,42,454,25,14,TEAL,True)
 rect(s,45.36,76.56,147.36,330,BG,True,'#D8DBDE')
 for j,(label,key) in enumerate([('INDUSTRY','industry'),('CURRENT WEEK','attacks'),('PREVIOUS WEEK','previous_attacks'),('CURRENT RANK','rank'),('GLOBAL DATA, TB','data_tb'),('SOURCE','source')]):
  y=89+j*48
  txt(s,label,56.9,y,120,11,6.9,'#647179')
  if key=='source':
   name=urlparse(str(sector.get('source',''))).netloc or 'Sector data source'
   source_link(s,name,sector.get('source',''),56.9,y+13,126,31,8.3,2)
  else:
   txt(s,wrapped(('Wholesale / Retail' if key=='industry' else str(sector.get(key,'Not reported'))),126,8.5,2),56.9,y+13,126,31,8.5,'#252C32',True)
 txt(s,'Wholesale/Retail incident trends are derived only from the cited source. Unavailable metrics are not estimated.',206.69,70,342.7,49,9.3)
 try:
  a=float(sector['attacks']);b=float(sector['previous_attacks']);numbers=[b,a]
  labels=['Previous week','Current week'];maxx=max(numbers+[1])
  for n,v in enumerate(numbers):
   x=262+n*140;h=93*v/maxx
   rect(s,x,160+93-h,86,h,'#3193A0',True)
   txt(s,str(int(v) if v.is_integer() else v),x,146+93-h,86,15,8.5,TEAL,True,PP_ALIGN.CENTER)
   txt(s,labels[n],x-9,268,104,18,8.4,COLORS['muted'],align=PP_ALIGN.CENTER)
 except (ValueError,TypeError,KeyError):
  txt(s,'No comparable quantitative observations were provided. Chart omitted.',206.69,185,342,48,9.5,COLORS['muted'])
 txt(s,'AWWG impact: Informative sector context. Aggregated industry statistics do not establish an incident affecting AWWG.',206.69,358,342,54,9.0,TEAL,True)
 rect(s,206.64,418,342.72,83,LIGHT,True)
 txt(s,'Recommended action: Monitor retail and wholesale attacks, customer-data exposure, ransomware and supply-chain compromises.',215.33,431,325,61,9)
 rows=[['Metric','Current / previous'],['Retail attacks',f"{sector.get('previous_attacks','–')} → {sector.get('attacks','–')}"],['Sector ranking',f"{sector.get('previous_rank','–')} → {sector.get('rank','–')}"],['Claimed data (TB)',f"{sector.get('previous_data_tb','–')} → {sector.get('data_tb','–')}"]]
 table(s,rows,206.65,532,[126,216.7],True,heights=[25,25,25,25])


def make_pptx(start:date,end:date,items:list[dict],sector:dict|None=None)->Path:
 engine.initialize()
 items=[tidy_for_report(x) for x in items]
 out=engine.REPORTS/f'AWWG_Weekly_Report_{start.isoformat()}.pptx'
 prs=Presentation();prs.slide_width=Pt(W);prs.slide_height=Pt(H)
 prs.core_properties.title='AWWG Cyber News Weekly Report'
 cover(prs,start,items)
 summary(prs,start,items)
 details(prs,start,items)
 if sector:trend_page(prs,start,sector)
 tmp=out.with_suffix('.pptx.part')
 prs.save(tmp);os.replace(tmp,out)
 return out


def make_pdf_from_pptx(pptx_file:Path)->Path:
 """Same visual report as PPTX: LO exports the exact PPTX in a sandboxed temp path."""
 target=pptx_file.with_suffix('.pdf')
 lo=shutil.which('libreoffice') or shutil.which('soffice')
 if not lo:raise RuntimeError('PDF export requires LibreOffice on the CyberRad server; PPTX remains available.')
 with tempfile.TemporaryDirectory(prefix='cyberrad_pdf_') as tmp:
  work=Path(tmp);profile=(work/'profile').as_uri()
  try:
   done=subprocess.run([lo,f'-env:UserInstallation={profile}','--headless','--convert-to','pdf','--outdir',str(work),str(pptx_file)],capture_output=True,text=True,timeout=55,check=True)
  except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as exc:
   raise RuntimeError('PPTX-to-PDF conversion failed; inspect LibreOffice installation.') from exc
  result=work/(pptx_file.stem+'.pdf')
  if not result.exists() or result.stat().st_size<1000:raise RuntimeError('PDF converter did not produce a valid file')
  # /tmp can be a different filesystem from the persistent Docker bind mount.
  # Stage inside target.parent, then atomically rename on the SAME filesystem.
  # This fixes EXDEV / Invalid cross-device link without altering report contents.
  target.parent.mkdir(parents=True, exist_ok=True)
  fd,staged_name=tempfile.mkstemp(prefix='.'+target.stem+'-',suffix='.pdf.part',dir=str(target.parent))
  staged=Path(staged_name)
  try:
   with os.fdopen(fd,'wb') as dst, result.open('rb') as src:
    shutil.copyfileobj(src,dst,length=1024*1024)
    dst.flush()
    os.fsync(dst.fileno())
   os.replace(staged,target)
  finally:
   staged.unlink(missing_ok=True)
 return target
