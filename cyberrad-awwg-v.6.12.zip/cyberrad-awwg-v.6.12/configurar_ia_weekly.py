#!/usr/bin/env python3
"""Optional secret-safe AI connection setup for the running CyberRad Docker container."""
import getpass
import json
import subprocess
import sys
from urllib.parse import urlparse

print('CyberRad AWWG · configuración opcional de IA para Weekly Reports')
print('Solo se enviará al proveedor el texto público del artículo, nunca datos internos AWWG.')
print('1) API OpenAI compatible (HTTPS, requiere clave)')
print('2) Ollama (servidor local al que tenga acceso el contenedor)')
mode=input('Elige 1 o 2: ').strip()
if mode not in ('1','2'):raise SystemExit('Opción inválida.')
provider='openai' if mode=='1' else 'ollama'
model=input('Nombre EXACTO del modelo disponible: ').strip()
if not model or len(model)>120:raise SystemExit('Modelo obligatorio (máx 120 caracteres).')
if mode=='1':
 default='https://api.openai.com/v1/chat/completions'
 url=input(f'URL Chat Completions HTTPS [{default}]: ').strip() or default
 key=getpass.getpass('API key (no se mostrará): ').strip()
 if not key:raise SystemExit('Se necesita una clave API.')
 if urlparse(url).scheme!='https':raise SystemExit('Debe ser HTTPS.')
else:
 default='http://host.docker.internal:11434/api/generate'
 url=input(f'URL Ollama accesible desde Docker [{default}]: ').strip() or default
 key=''
 if urlparse(url).scheme not in ('http','https'):raise SystemExit('URL inválida.')
config={'provider':provider,'model':model,'url':url,'api_key':key}
# Container's own runtime identity writes into the same persistent directory as weekly.sqlite3.
code='''from pathlib import Path
import json,os,sys,tempfile
from weekly_awwg import engine
base=engine.BASE
base.mkdir(parents=True,exist_ok=True)
path=base/'weekly_ai_config.json'
fd,staged=tempfile.mkstemp(prefix='.weekly-ai-',dir=str(base))
try:
 os.fchmod(fd,0o600)
 with os.fdopen(fd,'w',encoding='utf-8') as out: json.dump(json.load(sys.stdin),out)
 os.replace(staged,path)
except BaseException:
 Path(staged).unlink(missing_ok=True)
 raise
print('Configuración privada guardada dentro del volumen de datos de CyberRad.')
'''
try:
 result=subprocess.run(['docker','exec','-i','cyberrad-awwg','python3','-c',code],
     input=json.dumps(config),text=True,capture_output=True,timeout=20)
except (OSError,subprocess.TimeoutExpired) as exc:raise SystemExit('No se pudo acceder al contenedor: '+str(exc))
if result.returncode!=0:
 print('ERROR: '+result.stderr[-1000:],file=sys.stderr)
 raise SystemExit(1)
print(result.stdout.strip())
print('La IA está configurada. Ejecuta un nuevo informe y comprueba el contador «Noticias ampliadas con IA».')
print('Si tu firewall bloquea el proveedor o el modelo no responde, se utilizarán extractos reales sin IA.')
