#!/usr/bin/env bash
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
ENV_FILE=/etc/cyberrad-awwg/cyberrad.env
for file in engine.py router.py pptx_report.py weekly.html; do
 if [[ ! -f "$SOURCE/$file" || ! -f "$TARGET/weekly_awwg/$file" ]]; then
   echo "Falta el archivo $file en origen o destino; sin cambios." >&2; exit 2
 fi
done
for path in "$TARGET/docker-compose.kali.yml" "$ENV_FILE"; do
 if [[ ! -f "$path" ]]; then echo "Archivo ausente: $path; sin cambios." >&2; exit 2; fi
done
if ! docker inspect cyberrad-awwg >/dev/null 2>&1; then echo 'Contenedor CyberRad no encontrado; sin cambios.' >&2; exit 3; fi
if ! docker compose version >/dev/null 2>&1; then echo 'Se necesita docker compose v2.' >&2; exit 4; fi
# Validate before touching production files.
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PYCODE' "$SOURCE"
import sys, pathlib
base=pathlib.Path(sys.argv[1])
for f in ('engine.py','router.py','pptx_report.py'):
 compile((base/f).read_text(encoding='utf-8'),str(base/f),'exec')
print('Compilacion Python correcta.')
PYCODE
if ! grep -q 'manual_include' "$SOURCE/engine.py"; then echo 'Paquete no valido.' >&2; exit 5; fi
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.4-${STAMP}.tar.gz"
tar -C "$TARGET" -czf "$BACKUP"   weekly_awwg/engine.py weekly_awwg/router.py weekly_awwg/pptx_report.py weekly_awwg/weekly.html
for file in engine.py router.py pptx_report.py weekly.html; do
 install -m 644 -- "$SOURCE/$file" "$TARGET/weekly_awwg/$file"
done
echo "Backup creado: $BACKUP"
# Do not delete or recreate data volumes. Do not touch Sauron containers.
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE"  -f "$TARGET/docker-compose.kali.yml" config -q
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE"  -f "$TARGET/docker-compose.kali.yml" up -d --build --no-deps cyberrad
printf 'CyberRad Weekly v6.4 aplicado. Copia de seguridad: %s\n' "$BACKUP"
echo 'Base de datos, tokens, puertos e instalacion de Sauron conservados.'
