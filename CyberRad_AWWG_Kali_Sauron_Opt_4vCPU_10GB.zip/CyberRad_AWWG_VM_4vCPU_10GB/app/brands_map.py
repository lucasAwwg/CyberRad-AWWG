from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from functools import lru_cache
from math import sqrt
from pathlib import Path
from typing import Any
import re

import pycountry
from countryinfo import CountryInfo

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit

from .rss import normalize_spaces, parse_datetime_to_dt

COUNTRY_POINTS: dict[str, dict[str, float | str]] = {
    'Spain': {'lon': -3.7, 'lat': 40.4, 'continent': 'Europe'},
    'Portugal': {'lon': -8.2, 'lat': 39.4, 'continent': 'Europe'},
    'France': {'lon': 2.2, 'lat': 46.2, 'continent': 'Europe'},
    'United Kingdom': {'lon': -1.8, 'lat': 52.5, 'continent': 'Europe'},
    'Ireland': {'lon': -8.0, 'lat': 53.4, 'continent': 'Europe'},
    'Germany': {'lon': 10.4, 'lat': 51.2, 'continent': 'Europe'},
    'Netherlands': {'lon': 5.3, 'lat': 52.1, 'continent': 'Europe'},
    'Belgium': {'lon': 4.5, 'lat': 50.8, 'continent': 'Europe'},
    'Italy': {'lon': 12.6, 'lat': 42.8, 'continent': 'Europe'},
    'Switzerland': {'lon': 8.2, 'lat': 46.8, 'continent': 'Europe'},
    'Austria': {'lon': 14.2, 'lat': 47.5, 'continent': 'Europe'},
    'Sweden': {'lon': 18.1, 'lat': 59.3, 'continent': 'Europe'},
    'Denmark': {'lon': 10.0, 'lat': 56.2, 'continent': 'Europe'},
    'Norway': {'lon': 10.7, 'lat': 59.9, 'continent': 'Europe'},
    'Poland': {'lon': 19.0, 'lat': 52.2, 'continent': 'Europe'},
    'Lithuania': {'lon': 25.3, 'lat': 54.7, 'continent': 'Europe'},
    'Turkey': {'lon': 32.8, 'lat': 39.9, 'continent': 'Europe'},
    'United States': {'lon': -98.6, 'lat': 39.8, 'continent': 'North America'},
    'Canada': {'lon': -79.4, 'lat': 43.7, 'continent': 'North America'},
    'Mexico': {'lon': -99.1, 'lat': 19.4, 'continent': 'North America'},
    'Brazil': {'lon': -47.9, 'lat': -15.8, 'continent': 'South America'},
    'Argentina': {'lon': -58.4, 'lat': -34.6, 'continent': 'South America'},
    'Chile': {'lon': -70.7, 'lat': -33.4, 'continent': 'South America'},
    'Colombia': {'lon': -74.1, 'lat': 4.7, 'continent': 'South America'},
    'Japan': {'lon': 139.7, 'lat': 35.7, 'continent': 'Asia'},
    'South Korea': {'lon': 127.0, 'lat': 37.5, 'continent': 'Asia'},
    'China': {'lon': 116.4, 'lat': 39.9, 'continent': 'Asia'},
    'Hong Kong': {'lon': 114.1, 'lat': 22.3, 'continent': 'Asia'},
    'India': {'lon': 77.2, 'lat': 28.6, 'continent': 'Asia'},
    'Singapore': {'lon': 103.8, 'lat': 1.35, 'continent': 'Asia'},
    'United Arab Emirates': {'lon': 55.3, 'lat': 25.2, 'continent': 'Asia'},
    'Australia': {'lon': 151.2, 'lat': -33.9, 'continent': 'Oceania'},
    'New Zealand': {'lon': 174.8, 'lat': -41.3, 'continent': 'Oceania'},
    'South Africa': {'lon': 28.0, 'lat': -26.2, 'continent': 'Africa'},
    'Egypt': {'lon': 31.2, 'lat': 30.0, 'continent': 'Africa'},
    'Saudi Arabia': {'lon': 46.7, 'lat': 24.7, 'continent': 'Asia'},
}

COUNTRY_ALIASES: dict[str, tuple[str, ...]] = {
    'Spain': ('spain', 'spanish', 'españa', 'espana', 'madrid', 'barcelona'),
    'Portugal': ('portugal', 'portuguese', 'lisbon'),
    'France': ('france', 'french', 'paris'),
    'United Kingdom': ('united kingdom', 'uk', 'britain', 'british', 'england', 'london'),
    'Ireland': ('ireland', 'irish', 'dublin'),
    'Germany': ('germany', 'german', 'deutschland', 'berlin'),
    'Netherlands': ('netherlands', 'dutch', 'holland', 'amsterdam'),
    'Belgium': ('belgium', 'belgian'),
    'Italy': ('italy', 'italian', 'milan'),
    'Switzerland': ('switzerland', 'swiss'),
    'Austria': ('austria', 'austrian'),
    'Sweden': ('sweden', 'swedish', 'stockholm'),
    'Denmark': ('denmark', 'danish'),
    'Norway': ('norway', 'norwegian'),
    'Poland': ('poland', 'polish'),
    'Lithuania': ('lithuania', 'lithuanian', 'vilnius'),
    'Turkey': ('turkey', 'turkish'),
    'United States': ('united states', 'us', 'usa', 'american', 'new york', 'california'),
    'Canada': ('canada', 'canadian', 'vancouver', 'montreal', 'toronto'),
    'Mexico': ('mexico', 'mexican'),
    'Brazil': ('brazil', 'brazilian'),
    'Argentina': ('argentina', 'argentinian'),
    'Chile': ('chile', 'chilean'),
    'Colombia': ('colombia', 'colombian'),
    'Japan': ('japan', 'japanese', 'tokyo'),
    'South Korea': ('south korea', 'korea', 'korean', 'seoul'),
    'China': ('china', 'chinese', 'beijing', 'shanghai'),
    'Hong Kong': ('hong kong',),
    'India': ('india', 'indian'),
    'Singapore': ('singapore',),
    'United Arab Emirates': ('uae', 'united arab emirates', 'dubai', 'abu dhabi'),
    'Australia': ('australia', 'australian', 'sydney', 'melbourne'),
    'New Zealand': ('new zealand',),
    'South Africa': ('south africa',),
    'Egypt': ('egypt', 'egyptian'),
    'Saudi Arabia': ('saudi arabia', 'saudi'),
}

BRAND_TO_COUNTRY: dict[str, str] = {
    'mango': 'Spain', 'inditex': 'Spain', 'zara': 'Spain', 'bershka': 'Spain', 'stradivarius': 'Spain', 'pull&bear': 'Spain', 'pull and bear': 'Spain', 'massimo dutti': 'Spain', 'oysho': 'Spain',
    'h&m': 'Sweden', 'hm': 'Sweden', 'hm group': 'Sweden', 'arket': 'Sweden', 'cos': 'United Kingdom', 'weekday': 'Sweden', 'monki': 'Sweden',
    'nike': 'United States', 'adidas': 'Germany', 'puma': 'Germany', 'under armour': 'United States', 'lululemon': 'Canada', 'apple': 'United States', 'samsung': 'South Korea', 'amazon': 'United States', 'walmart': 'United States', 'target': 'United States', 'best buy': 'United States', 'costco': 'United States', 'carrefour': 'France', 'ikea': 'Sweden', 'mediamarkt': 'Germany', 'fnac': 'France', 'gap': 'United States', 'old navy': 'United States',
    'uniqlo': 'Japan', 'fast retailing': 'Japan', 'shein': 'Singapore', 'primark': 'Ireland', 'zalando': 'Germany', 'asos': 'United Kingdom', 'boohoo': 'United Kingdom', 'prettylittlething': 'United Kingdom', 'pretty little thing': 'United Kingdom', 'about you': 'Germany',
    'burberry': 'United Kingdom', 'gucci': 'Italy', 'prada': 'Italy', 'armani': 'Italy', 'moncler': 'Italy', 'louis vuitton': 'France', 'dior': 'France', 'hermes': 'France', 'chanel': 'France', 'lvmh': 'France', 'kering': 'France', 'balenciaga': 'France', 'saint laurent': 'France',
    'sephora': 'France', 'farfetch': 'United Kingdom', 'yoox': 'Italy', 'net-a-porter': 'United Kingdom', 'mytheresa': 'Germany', 'ssense': 'Canada', 'revolve': 'United States', 'shopbop': 'United States', 'the outnet': 'United Kingdom',
    'saks': 'United States', "macy's": 'United States', 'macys': 'United States', 'nordstrom': 'United States', "victoria's secret": 'United States', 'ralph lauren': 'United States', 'tommy hilfiger': 'United States', 'calvin klein': 'United States', 'pvh': 'United States',
    'coach': 'United States', 'kate spade': 'United States', 'michael kors': 'United States', 'tapestry': 'United States', 'decathlon': 'France', 'superdry': 'United Kingdom', 'guess': 'United States', 'levi strauss': 'United States', 'levis': 'United States',
    'fashion nova': 'United States', 'vinted': 'Lithuania', 'stockx': 'United States', 'goat': 'United States', 'urban outfitters': 'United States', 'namshi': 'United Arab Emirates', 'cider': 'Hong Kong', 'hugo boss': 'Germany', 'pepe jeans': 'United Kingdom', 'desigual': 'Spain', 'lefties': 'Spain', 'abercrombie': 'United States', 'hollister': 'United States', 'river island': 'United Kingdom', 'next': 'United Kingdom', 'marks & spencer': 'United Kingdom', 'm&s': 'United Kingdom',
    'banana republic': 'United States', 'old navy': 'United States', 'banana republic': 'United States', 'oysho': 'Spain', 'stradivarius': 'Spain', 'bershka': 'Spain', 'pull and bear': 'Spain', 'pull&bear': 'Spain',
    'massimo dutti': 'Spain', 'calzedonia': 'Italy', 'intimissimi': 'Italy', 'tezenis': 'Italy', 'ovs': 'Italy', 'celio': 'France', 'kiabi': 'France', 'etam': 'France', 'celine': 'France',
    'tom tailor': 'Germany', 's.oliver': 'Germany', 'esprit': 'Hong Kong', 'new look': 'United Kingdom', 'boohoo man': 'United Kingdom', 'missguided': 'United Kingdom', 'allsaints': 'United Kingdom',
    'dr martens': 'United Kingdom', 'new balance': 'United States', 'skechers': 'United States', 'foot locker': 'United States', 'jd sports': 'United Kingdom', 'uniqlo': 'Japan', 'fast retailing': 'Japan'
}

AMBIGUOUS_BRANDS: set[str] = {
    'next', 'guess', 'coach', 'gap', 'goat', 'cider', 'cos', 'arket', 'weekday', 'monki', 'revolve', 'hm', 'm&s', 'stockx'
}

AMBIGUOUS_BRAND_CONTEXT_TERMS: tuple[str, ...] = (
    'fashion', 'apparel', 'clothing', 'textile', 'retail', 'retailer', 'brand', 'brands', 'store', 'shop', 'ecommerce', 'e-commerce',
    'marketplace', 'luxury', 'footwear', 'sneaker', 'handbag', 'group', 'plc', 'inc', 'company', 'online store', 'ropa', 'moda', 'textil', 'calzado', 'lujo'
)

ATTACK_KEYWORDS = {
    'Ransomware': ('ransomware', 'extortion', 'encryptor'),
    'Brecha de datos': ('data breach', 'breach', 'leaked data', 'filtración', 'filtracion', 'customer data'),
    'Pagos comprometidos': ('payment breach', 'payment skimmer', 'magecart', 'carding', 'checkout compromise', 'compromiso de pagos', 'e-skimming'),
    'Robo de credenciales': ('credential theft', 'stolen credentials', 'account takeover', 'robo de credenciales'),
    'Phishing': ('phishing', 'smishing', 'vishing'),
    'Malware': ('malware', 'trojan', 'botnet', 'web skimmer'),
    'Incidente / hackeo': ('cyberattack', 'cyber attack', 'hack', 'hacked', 'ciberataque', 'ciberincidente', 'security incident', 'compromise', 'compromised'),
}

MAP_IMAGE_WIDTH = 1140.0
MAP_IMAGE_HEIGHT = 744.0

# Calibrated against the current /static/world-outline.png.
# The white world outline occupies roughly x=18..1122 and y=100..638.
# We project every country using a consistent equirectangular transform so
# all countries share the same math instead of a few hand-tuned points.
MAP_PROJECTION = {
    # Proyección lineal ajustada al mapamundi usado en CyberRad.
    # Se usa como respaldo cuando no hay ancla manual X/Y.
    "x_per_lon": 2.94,
    "x_zero_lon": 498.6,
    "y_per_lat": -3.48,
    "y_zero_lat": 468.3,
    "padding": 18.0,
}

# Calibración manual recuperada del mapa que mejor funcionaba visualmente.
# Se guarda en porcentaje del lienzo completo para que Reino Unido no se mueva
# hacia Irlanda y otros países queden centrados en su masa visual.
MANUAL_COUNTRY_ANCHORS_PCT: dict[str, tuple[float, float]] = {
    # Calibrado contra /static/world-outline.png completo.
    "Argentina": (27.98, 78.36),
    "Australia": (82.63, 71.77),
    "Bangladesh": (65.53, 53.09),
    "Belgium": (45.44, 39.52),
    "Bahrain": (56.05, 53.09),
    "Brazil": (30.35, 66.53),
    "Canada": (18.42, 30.91),
    "Switzerland": (46.49, 41.53),
    "China": (69.47, 46.24),
    "Costa Rica": (21.84, 56.32),
    "Cuba": (23.86, 53.36),
    "Germany": (47.19, 39.52),
    "Denmark": (47.02, 35.89),
    "Spain": (42.89, 45.43),
    "France": (44.56, 41.80),
    "United Kingdom": (42.62, 36.12),
    "Ireland": (40.44, 36.42),
    "Israel": (52.98, 48.92),
    "India": (62.46, 54.17),
    "Italy": (49.08, 44.84),
    "Japan": (79.04, 44.89),
    "Kuwait": (55.09, 51.75),
    "Lithuania": (50.26, 36.83),
    "Mexico": (17.11, 52.69),
    "Netherlands": (45.61, 38.58),
    "Norway": (46.75, 30.24),
    "Panama": (24.39, 58.47),
    "Pakistan": (59.91, 49.73),
    "Poland": (49.12, 38.58),
    "Portugal": (40.70, 45.70),
    "Paraguay": (29.21, 72.85),
    "Saudi Arabia": (54.74, 54.57),
    "Sweden": (48.51, 30.91),
    "Singapore": (69.56, 61.69),
    "Syrian Arab Republic": (52.54, 47.04),
    "Turkey": (53.25, 46.10),
    "United States": (16.67, 45.03),
    "United Arab Emirates": (57.10, 55.32),
}

# Solo dejamos microajustes en territorios/países muy pequeños. En Europa occidental
# ya no movemos Reino Unido, Irlanda o Portugal para que queden centrados como en la 5.0.4.
COUNTRY_PIXEL_OFFSETS: dict[str, tuple[float, float]] = {
    "Hong Kong": (6.0, 10.0),
    "Singapore": (4.0, 8.0),
    "Japan": (10.0, 0.0),
    "South Korea": (8.0, -3.0),
}

MIN_BRANDS_MAP_YEAR = 2024

COUNTRY_NAME_ALIASES: dict[str, str] = {
    'usa': 'United States',
    'us': 'United States',
    'u.s.': 'United States',
    'u.s.a.': 'United States',
    'united states of america': 'United States',
    'uk': 'United Kingdom',
    'u.k.': 'United Kingdom',
    'britain': 'United Kingdom',
    'great britain': 'United Kingdom',
    'england': 'United Kingdom',
    'scotland': 'United Kingdom',
    'wales': 'United Kingdom',
    'uae': 'United Arab Emirates',
    'u.a.e.': 'United Arab Emirates',
    'south korea': 'Korea, Republic of',
    'north korea': "Korea, Democratic People's Republic of",
    'russia': 'Russian Federation',
    'vietnam': 'Viet Nam',
    'czech republic': 'Czechia',
    'ivory coast': "Côte d'Ivoire",
    'laos': "Lao People's Democratic Republic",
    'moldova': 'Moldova, Republic of',
    'bolivia': 'Bolivia, Plurinational State of',
    'tanzania': 'Tanzania, United Republic of',
    'venezuela': 'Venezuela, Bolivarian Republic of',
    'syria': 'Syrian Arab Republic',
    'iran': 'Iran, Islamic Republic of',
    'taiwan': 'Taiwan',
    'hong kong': 'Hong Kong',
    'macau': 'Macao',
}


GLOBAL_COUNTRY_TERMS: list[tuple[str, str]] = []
_seen_terms: set[str] = set()
for _country in list(pycountry.countries):
    _names = {getattr(_country, 'name', '')}
    for _attr in ('official_name', 'common_name'):
        if hasattr(_country, _attr):
            _names.add(getattr(_country, _attr))
    for _name in _names:
        _clean = normalize_spaces(_name).strip().lower()
        if len(_clean) < 4 or _clean in _seen_terms:
            continue
        _seen_terms.add(_clean)
        GLOBAL_COUNTRY_TERMS.append((_clean, _country.name))
GLOBAL_COUNTRY_TERMS.sort(key=lambda item: len(item[0]), reverse=True)


WORLD_SVG = """
<svg viewBox="0 0 1140 744" class="world-svg" xmlns="http://www.w3.org/2000/svg" aria-label="Mapa mundi cibernético">
  <defs>
    <filter id="glow" x="-60%" y="-60%" width="220%" height="220%">
      <feGaussianBlur stdDeviation="5" result="blur"/>
      <feMerge>
        <feMergeNode in="blur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>
  <g id="map-dots"></g>
</svg>
""".strip()

SECTOR_ALIASES = {'marcas_retail', 'marcas', 'marca', 'brand', 'brands', 'retail_brands'}
MAP_IMAGE_PATH = '/static/world-outline.svg'


@lru_cache(maxsize=256)
def normalize_country_name(value: str | None) -> str | None:
    raw = normalize_spaces(value or '').strip()
    if not raw:
        return None
    lowered = raw.lower()
    if lowered in COUNTRY_NAME_ALIASES:
        return COUNTRY_NAME_ALIASES[lowered]
    for canonical, aliases in COUNTRY_ALIASES.items():
        if lowered == canonical.lower() or lowered in aliases:
            return canonical
    try:
        return pycountry.countries.lookup(raw).name
    except Exception:
        pass
    for country in pycountry.countries:
        names = {country.name.lower()}
        for attr in ('official_name', 'common_name'):
            if hasattr(country, attr):
                names.add(getattr(country, attr).lower())
        if lowered in names:
            return country.name
    return raw.title()


@lru_cache(maxsize=256)
def country_lat_lon(country_name: str | None) -> tuple[float | None, float | None, str | None]:
    canonical = normalize_country_name(country_name)
    if not canonical:
        return None, None, None
    if canonical in COUNTRY_POINTS:
        item = COUNTRY_POINTS[canonical]
        return float(item['lat']), float(item['lon']), str(item.get('continent', ''))
    try:
        info = CountryInfo(canonical).info()
        latlng = info.get('latlng') or []
        if isinstance(latlng, (list, tuple)) and len(latlng) >= 2:
            lat = float(latlng[0])
            lon = float(latlng[1])
            region = str(info.get('region') or info.get('subregion') or '')
            return lat, lon, region
    except Exception:
        pass
    return None, None, None


def project_country_to_map(country_name: str | None) -> tuple[float | None, float | None]:
    canonical = normalize_country_name(country_name)
    if canonical in MANUAL_COUNTRY_ANCHORS_PCT:
        x_pct, y_pct = MANUAL_COUNTRY_ANCHORS_PCT[canonical]
        x = (x_pct / 100.0) * MAP_IMAGE_WIDTH
        y = (y_pct / 100.0) * MAP_IMAGE_HEIGHT
        return round(x, 1), round(y, 1)

    lat, lon, _continent = country_lat_lon(canonical)
    if lat is None or lon is None:
        return None, None

    proj = MAP_PROJECTION
    x = proj['x_zero_lon'] + (lon * proj['x_per_lon'])
    y = proj['y_zero_lat'] + (lat * proj['y_per_lat'])

    dx, dy = COUNTRY_PIXEL_OFFSETS.get(canonical or '', (0.0, 0.0))
    x += dx
    y += dy

    pad = proj['padding']
    x = max(pad, min(MAP_IMAGE_WIDTH - pad, x))
    y = max(pad, min(MAP_IMAGE_HEIGHT - pad, y))
    return round(x, 1), round(y, 1)


def _norm(text: str | None) -> str:
    return normalize_spaces(text or '')


def has_marcas_sector(article: dict[str, Any]) -> bool:
    sectors = article.get('sector_categories') or []
    norm = {str(item).strip().lower() for item in sectors}
    return bool(norm & SECTOR_ALIASES)


def infer_country_and_brand(article: dict[str, Any]) -> tuple[str | None, str | None, str]:
    primary_text = ' '.join([
        article.get('title') or '',
        article.get('summary') or '',
        article.get('content') or '',
        article.get('rationale') or '',
    ])
    secondary_text = ' '.join([
        article.get('feed_name') or '',
        article.get('feed_url') or '',
        article.get('article_url') or '',
    ])
    primary_norm = _norm(primary_text)
    secondary_norm = _norm(secondary_text)

    for brand, country in BRAND_TO_COUNTRY.items():
        if re.search(rf'(?<!\w){re.escape(brand)}(?!\w)', primary_norm):
            return country, brand.title(), 'brand'

    entities = article.get('entities') or {}
    vendors = [normalize_spaces(v).lower() for v in entities.get('vendors', [])]
    for vendor in vendors:
        if vendor in BRAND_TO_COUNTRY:
            return BRAND_TO_COUNTRY[vendor], vendor.title(), 'entity'

    for field in ('locations', 'countries'):
        for value in entities.get(field, []) or []:
            canonical = normalize_country_name(value)
            if canonical:
                return canonical, None, 'entity-country'

    country_blob = f"{primary_norm} {secondary_norm}".strip()
    for country, aliases in COUNTRY_ALIASES.items():
        for alias in aliases:
            if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', country_blob):
                return normalize_country_name(country), None, 'country'

    for alias, canonical in GLOBAL_COUNTRY_TERMS:
        if re.search(rf'(?<!\w){re.escape(alias)}(?!\w)', country_blob):
            return normalize_country_name(canonical), None, 'country-global'

    return None, None, 'unknown'


def infer_attack_label(article: dict[str, Any]) -> str:
    text = _norm(' '.join([article.get('title') or '', article.get('summary') or '', article.get('content') or '', article.get('rationale') or '']))
    for label, keywords in ATTACK_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text:
                return label
    return 'General ciber / digital'


def year_for_article(article: dict[str, Any]) -> int:
    raw = article.get('published_at') or article.get('created_at') or ''
    return parse_datetime_to_dt(raw).year


def country_key(value: str | None) -> str:
    canonical = normalize_country_name(value) or 'No inferido'
    cleaned = re.sub(r'[^\w\s-]', '', canonical.lower()).strip()
    return cleaned.replace(' ', '_')


def world_xy(country: str, width: float = MAP_IMAGE_WIDTH, height: float = MAP_IMAGE_HEIGHT) -> tuple[float, float]:
    x, y = project_country_to_map(country)
    if x is None or y is None:
        x, y = MAP_IMAGE_WIDTH / 2, MAP_IMAGE_HEIGHT / 2
    if width != MAP_IMAGE_WIDTH or height != MAP_IMAGE_HEIGHT:
        x = (x / MAP_IMAGE_WIDTH) * width
        y = (y / MAP_IMAGE_HEIGHT) * height
    return x, y


def _point_payload(country: str, grouped_items: list[dict[str, Any]], count: int) -> dict[str, Any]:
    x, y = world_xy(country)
    brands = sorted({item['brand'] for item in grouped_items if item.get('brand') and item['brand'] != 'Marca no inferida'})
    attacks = sorted({item['attack_type'] for item in grouped_items if item.get('attack_type')})
    latest = grouped_items[0] if grouped_items else {}
    return {
        'country': country,
        'country_key': country_key(country),
        'count': count,
        'x': round(x, 2),
        'y': round(y, 2),
        'brands': brands,
        'attack_types': attacks,
        'article_ids': [item['id'] for item in grouped_items if item.get('id')],
        'latest_date': latest.get('published_at'),
        'latest_brand': latest.get('brand') or 'Marca no inferida',
        'latest_attack_type': latest.get('attack_type') or 'Incidente ciber',
        'latest_source': latest.get('feed_name') or latest.get('source') or 'Fuente no inferida',
        'continent': country_lat_lon(country)[2] or '',
    }


def build_brands_map_data(articles: list[dict[str, Any]], selected_year: int | str | None = None) -> dict[str, Any]:
    all_brand_rows = [article for article in articles if has_marcas_sector(article) and year_for_article(article) >= MIN_BRANDS_MAP_YEAR]
    current_year = datetime.now().year
    year_counts: dict[int, int] = defaultdict(int)
    for article in all_brand_rows:
        year = year_for_article(article)
        if year >= MIN_BRANDS_MAP_YEAR:
            year_counts[year] += 1
    available_years = [current_year]
    latest_populated_year = current_year
    selected_mode = 'current'
    active_year = current_year
    marcas_rows = [article for article in all_brand_rows if year_for_article(article) == current_year]

    status_counts = {
        'included': sum(1 for article in marcas_rows if article.get('status') == 'included'),
        'pending': sum(1 for article in marcas_rows if article.get('status') == 'pending'),
        'excluded': sum(1 for article in marcas_rows if article.get('status') == 'excluded'),
    }

    country_counts: dict[str, int] = defaultdict(int)
    grouped_by_country: dict[str, list[dict[str, Any]]] = defaultdict(list)
    attack_counts: dict[str, int] = defaultdict(int)
    incidents: list[dict[str, Any]] = []
    unresolved = 0

    for article in marcas_rows:
        country, brand, source = infer_country_and_brand(article)
        country = normalize_country_name(country) if country else None
        attack = infer_attack_label(article)
        incident = {
            'id': article.get('id'),
            'title': article.get('title') or 'Sin título',
            'country': country or 'No inferido',
            'country_key': country_key(country or 'No inferido'),
            'brand': brand or 'Marca no inferida',
            'attack_type': attack,
            'published_at': article.get('published_at') or article.get('created_at'),
            'article_url': article.get('article_url') or '',
            'feed_name': article.get('feed_name') or '',
            'source': source,
            'score': round(float(article.get('relevance_score') or 0), 3),
            'highlight_key': f"{country or 'unknown'}::{article.get('id')}",
            'status': article.get('status') or 'pending',
        }
        incidents.append(incident)
        attack_counts[attack] += 1
        px, py = project_country_to_map(country)
        if country and px is not None and py is not None:
            country_counts[country] += 1
            grouped_by_country[country].append(incident)
        else:
            unresolved += 1

    incidents.sort(key=lambda item: item.get('published_at') or '', reverse=True)
    points = []
    for country, count in sorted(country_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        grouped = sorted(grouped_by_country[country], key=lambda item: item.get('published_at') or '', reverse=True)
        points.append(_point_payload(country, grouped, count))

    top_countries = [
        {'country': point['country'], 'count': point['count'], 'brands': point['brands'][:5]}
        for point in points[:10]
    ]
    top_attacks = [
        {'label': label, 'count': count}
        for label, count in sorted(attack_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:8]
    ]

    years_payload: list[str] = [str(current_year)]
    year_counts_payload = {str(current_year): len(marcas_rows)}
    totals = {
        'all_articles': len(marcas_rows),
        'visible_articles': len(incidents),
        'mapped_articles': len([item for item in incidents if item['country'] != 'No inferido']),
        'incidents': len(marcas_rows),
        'countries': len(country_counts),
        'brands': len({incident['brand'] for incident in incidents if incident['brand'] != 'Marca no inferida'}),
        'unresolved': unresolved,
        'included': status_counts['included'],
        'pending': status_counts['pending'],
        'excluded': status_counts['excluded'],
    }
    print(f"[CyberRad][MarcasMapCurrentYear] all={totals['all_articles']} visible={totals['visible_articles']} mapped={totals['mapped_articles']} countries={totals['countries']} years={available_years} active_year={active_year} selected_mode={selected_mode} latest_populated={latest_populated_year} statuses={status_counts} min_year={MIN_BRANDS_MAP_YEAR}")

    return {
        'year': str(active_year),
        'selected_mode': selected_mode,
        'available_years': years_payload,
        'totals': totals,
        'points': points,
        'top_countries': top_countries,
        'top_attacks': top_attacks,
        'incidents': incidents[:24],
        'map_svg': WORLD_SVG,
        'map_base_image': MAP_IMAGE_PATH,
        'latest_populated_year': str(latest_populated_year),
        'year_counts': year_counts_payload,
        'debug': {
            'total_brand_articles': len(all_brand_rows),
            'selected_year': str(active_year),
            'selected_mode': selected_mode,
            'countries_detected': len(country_counts),
            'available_years': available_years,
            'latest_populated_year': latest_populated_year,
            'year_counts': year_counts_payload,
        },
        'methodology': 'País inferido principalmente por marca, retailer o marketplace afectado; si no aparece, se intenta por país explícito en el texto. El total de noticias Marcas incluye incluidas, pendientes y excluidas; el mapa dibuja todas las clasificadas para evitar que el contador baje solo por cambios de estado. La proyección usa una calibración equirectangular consistente para todos los países. Solo se muestra el mapa del año actual; cuando cambie el año, el mapa se actualizará automáticamente.',
    }


def _draw_map_background(pdf: canvas.Canvas, x: float, y: float, w: float, h: float) -> None:
    pdf.setFillColor(colors.HexColor('#06111b'))
    pdf.roundRect(x, y, w, h, 16, fill=1, stroke=0)
    pdf.setStrokeColor(colors.HexColor('#1f5d3a'))
    pdf.setLineWidth(0.8)
    for frac in (0.2, 0.4, 0.6, 0.8):
        pdf.line(x + 18, y + h * frac, x + w - 18, y + h * frac)
    for frac in (0.14, 0.28, 0.42, 0.56, 0.70, 0.84):
        pdf.line(x + w * frac, y + 18, x + w * frac, y + h - 18)
    image_file = Path(__file__).resolve().parent / 'static' / 'world-outline.png'
    if image_file.exists():
        pdf.drawImage(str(image_file), x + 10, y + 12, width=w - 20, height=h - 24, preserveAspectRatio=True, mask='auto')


def export_brands_map_pdf(path: str, map_data: dict[str, Any]) -> str:
    page_w, page_h = landscape(A4)
    pdf = canvas.Canvas(path, pagesize=(page_w, page_h))
    pdf.setTitle(f"CyberRad Marcas Map {map_data['year']}")

    pdf.setFillColor(colors.HexColor('#020617'))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 20)
    year_label = 'Todos los años' if str(map_data['year']) == 'all' else str(map_data['year'])
    pdf.drawString(36, page_h - 34, f"CyberRad · Mapa anual de ciberincidentes en Marcas · {year_label}")
    pdf.setFont('Helvetica', 10)
    pdf.setFillColor(colors.HexColor('#9ad9b0'))
    pdf.drawString(36, page_h - 50, 'Solo noticias del sector textil / moda / lujo / retail de moda con incidente ciber asociado.')

    stat_y = page_h - 84
    card_w = 112
    stats = [
        ('Noticias Marcas', str(map_data['totals']['all_articles'])),
        ('Países', str(map_data['totals']['countries'])),
        ('En mapa', str(map_data['totals']['mapped_articles'])),
        ('Sin país', str(map_data['totals']['unresolved'])),
    ]
    for index, (label, value) in enumerate(stats):
        x = 36 + index * (card_w + 12)
        pdf.setFillColor(colors.HexColor('#0b1622'))
        pdf.roundRect(x, stat_y - 42, card_w, 38, 10, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#8ab99c'))
        pdf.setFont('Helvetica', 8)
        pdf.drawString(x + 10, stat_y - 14, label)
        pdf.setFillColor(colors.HexColor('#d7ffe3'))
        pdf.setFont('Helvetica-Bold', 16)
        pdf.drawString(x + 10, stat_y - 32, value)

    map_x, map_y, map_w, map_h = 36, 126, 540, 340
    _draw_map_background(pdf, map_x, map_y, map_w, map_h)
    pdf.setFillColor(colors.HexColor('#4ade80'))
    pdf.setFont('Helvetica-Bold', 11)
    pdf.drawString(map_x + 16, map_y + map_h - 22, 'Mapa mundi cibernético · Marcas')

    max_count = max((point['count'] for point in map_data['points']), default=1)
    for point in map_data['points']:
        px = map_x + (point['x'] / MAP_IMAGE_WIDTH) * map_w
        py = map_y + map_h - ((point['y'] / MAP_IMAGE_HEIGHT) * map_h)
        radius = 5.0 + (10.0 * (sqrt(point['count']) / sqrt(max_count or 1)))
        pdf.setFillColor(colors.Color(0.13, 0.77, 0.37, alpha=0.28))
        pdf.circle(px, py, radius * 1.65, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#22c55e'))
        pdf.circle(px, py, radius, fill=1, stroke=0)
        pdf.setFillColor(colors.HexColor('#d9ffe8'))
        pdf.setFont('Helvetica-Bold', 8)
        pdf.drawString(px + radius + 2, py + radius + 1, f"{point['country']} ({point['count']})")

    panel_x = 596
    pdf.setFillColor(colors.HexColor('#0b1622'))
    pdf.roundRect(panel_x, 126, 228, 340, 16, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(panel_x + 16, 440, 'Top países')
    pdf.setFont('Helvetica', 9)
    y = 422
    for idx, item in enumerate(map_data['top_countries'][:6], start=1):
        brands = ', '.join(item.get('brands') or []) or 'Sin marcas inferidas'
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.drawString(panel_x + 16, y, f"{idx}. {item['country']} · {item['count']} casos")
        pdf.setFillColor(colors.HexColor('#7fa790'))
        for line in simpleSplit(brands[:82], 'Helvetica', 8, 190):
            y -= 10
            pdf.drawString(panel_x + 28, y, line)
        y -= 16

    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 12)
    pdf.drawString(panel_x + 16, max(176, y), 'Tipos de incidente')
    y2 = max(158, y - 16)
    pdf.setFont('Helvetica', 9)
    for item in map_data['top_attacks'][:5]:
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.drawString(panel_x + 16, y2, f"• {item['label']}: {item['count']}")
        y2 -= 14

    pdf.setFillColor(colors.HexColor('#94d8ad'))
    pdf.setFont('Helvetica', 8)
    methodology_lines = simpleSplit(map_data.get('methodology', ''), 'Helvetica', 8, page_w - 72)
    for index, line in enumerate(methodology_lines):
        pdf.drawString(36, 100 - (index * 10), line)

    pdf.showPage()
    pdf.setFillColor(colors.HexColor('#020617'))
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setFillColor(colors.HexColor('#d7ffe3'))
    pdf.setFont('Helvetica-Bold', 18)
    pdf.drawString(36, page_h - 36, f"Detalle de incidentes · Marcas · {year_label}")
    pdf.setFont('Helvetica', 9)
    y = page_h - 64
    for item in map_data['incidents'][:24]:
        if y < 58:
            pdf.showPage()
            pdf.setFillColor(colors.HexColor('#020617'))
            pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
            pdf.setFillColor(colors.HexColor('#d7ffe3'))
            pdf.setFont('Helvetica-Bold', 16)
            pdf.drawString(36, page_h - 36, f"Detalle de incidentes · Continuación · {year_label}")
            pdf.setFont('Helvetica', 9)
            y = page_h - 64
        pdf.setFillColor(colors.HexColor('#d7ffe3'))
        pdf.setFont('Helvetica-Bold', 10)
        title_lines = simpleSplit(item['title'], 'Helvetica-Bold', 10, page_w - 72)
        for line in title_lines[:2]:
            pdf.drawString(36, y, line)
            y -= 12
        pdf.setFillColor(colors.HexColor('#94d8ad'))
        pdf.setFont('Helvetica', 8.5)
        meta = f"{item['country']} · {item['brand']} · {item['attack_type']} · score {item['score']:.2f}"
        for line in simpleSplit(meta, 'Helvetica', 8.5, page_w - 72):
            pdf.drawString(36, y, line)
            y -= 10
        if item.get('article_url'):
            pdf.setFillColor(colors.HexColor('#7dd3fc'))
            link_line = simpleSplit(item['article_url'], 'Helvetica', 7.5, page_w - 72)[0]
            pdf.drawString(36, y, link_line)
            y -= 10
        y -= 10
    pdf.save()
    return path


# HOTFIX18_PROJECTION_OVERRIDE
# Proyección geográfica recalibrada para world-outline.svg real (1140x744).
# Se apoya en el bounding box real del contorno mundial extraído del SVG,
# evitando anclas manuales heredadas que desplazaban países al mar.
MAP_GEO_BOUNDS = {
    'min_x': 18.0,
    'max_x': 1122.0,
    'min_y': 118.99,
    'max_y': 535.22,
    'min_lon': -180.0,
    'max_lon': 180.0,
    'max_lat': 84.0,
    'min_lat': -58.0,
}

COUNTRY_PIXEL_OFFSETS_HOTFIX18: dict[str, tuple[float, float]] = {
    'Ireland': (-10.0, -2.0),
    'United Kingdom': (-4.0, -8.0),
    'Portugal': (-8.0, 4.0),
    'Spain': (-2.0, 5.0),
    'Belgium': (6.0, -1.0),
    'Netherlands': (8.0, -5.0),
    'Switzerland': (8.0, 6.0),
    'Italy': (10.0, 7.0),
    'Denmark': (6.0, -8.0),
    'Lithuania': (8.0, -5.0),
    'Singapore': (5.0, 8.0),
    'Hong Kong': (7.0, 8.0),
    'Japan': (9.0, 0.0),
    'South Korea': (8.0, -2.0),
}

def _clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def project_country_to_map(country_name: str | None) -> tuple[float | None, float | None]:
    canonical = normalize_country_name(country_name)
    lat, lon, _continent = country_lat_lon(canonical)
    if lat is None or lon is None:
        return None, None

    bounds = MAP_GEO_BOUNDS
    width = bounds['max_x'] - bounds['min_x']
    height = bounds['max_y'] - bounds['min_y']

    lon = _clamp(float(lon), bounds['min_lon'], bounds['max_lon'])
    lat = _clamp(float(lat), bounds['min_lat'], bounds['max_lat'])

    x = bounds['min_x'] + ((lon - bounds['min_lon']) / (bounds['max_lon'] - bounds['min_lon'])) * width
    y = bounds['min_y'] + ((bounds['max_lat'] - lat) / (bounds['max_lat'] - bounds['min_lat'])) * height

    dx, dy = COUNTRY_PIXEL_OFFSETS_HOTFIX18.get(canonical or '', COUNTRY_PIXEL_OFFSETS.get(canonical or '', (0.0, 0.0)))
    x += dx
    y += dy

    x = _clamp(x, 10.0, MAP_IMAGE_WIDTH - 10.0)
    y = _clamp(y, 10.0, MAP_IMAGE_HEIGHT - 10.0)
    return round(x, 1), round(y, 1)


def world_xy(country: str, width: float = MAP_IMAGE_WIDTH, height: float = MAP_IMAGE_HEIGHT) -> tuple[float, float]:
    x, y = project_country_to_map(country)
    if x is None or y is None:
        x, y = MAP_IMAGE_WIDTH / 2, MAP_IMAGE_HEIGHT / 2
    if width != MAP_IMAGE_WIDTH or height != MAP_IMAGE_HEIGHT:
        x = (x / MAP_IMAGE_WIDTH) * width
        y = (y / MAP_IMAGE_HEIGHT) * height
    return x, y
