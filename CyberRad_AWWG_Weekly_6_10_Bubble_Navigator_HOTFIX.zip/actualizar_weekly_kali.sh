#!/usr/bin/env bash
# CyberRad AWWG Weekly v6.10: bubble navigation for review mode.
# Does not modify DB, reports, secrets, settings, Sauron, or other Docker services.
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$HERE/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
DEST="$TARGET/weekly_awwg"
ENV_FILE='/etc/cyberrad-awwg/cyberrad.env'
COMPOSE_FILE="$TARGET/docker-compose.kali.yml"
FILE='weekly.html'
[[ -f "$TARGET/weekly_awwg/engine.py" ]] || { echo 'No parece una instalación válida de CyberRad AWWG' >&2; exit 2; }
[[ -f "$SOURCE/$FILE" ]] || { echo 'Falta weekly.html en el ZIP; sin cambios' >&2; exit 2; }
[[ -f "$DEST/$FILE" ]] || { echo 'Falta weekly.html en la instalación base; sin cambios' >&2; exit 2; }
command -v docker >/dev/null && docker compose version >/dev/null || { echo 'Docker Compose v2 no disponible' >&2; exit 4; }
docker inspect cyberrad-awwg >/dev/null 2>&1 || { echo 'No se encontró cyberrad-awwg' >&2; exit 4; }
PYTHONDONTWRITEBYTECODE=1 python3 - "$SOURCE" <<'PYCODE'
from pathlib import Path
import sys
root=Path(sys.argv[1])
h=(root/'weekly.html').read_text(encoding='utf-8')
assert 'bubble-groups' in h and 'bubble-severity' in h and 'setReviewView' in h and 'selectSubgroup' in h
print('Verificación estática v6.10: OK')
PYCODE
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config -q
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.10-${STAMP}.tar.gz"
tar -C "$TARGET" -czf "$BACKUP" weekly_awwg/weekly.html
rollback() {
 echo 'La actualización falló: restaurando weekly.html…' >&2
 tar -C "$TARGET" -xzf "$BACKUP" || true
 docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad || true
 echo "Respaldo: $BACKUP" >&2
}
trap rollback ERR
install -m 0644 -- "$SOURCE/$FILE" "$DEST/$FILE"
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad
[[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg)" == 'true' ]]
docker exec cyberrad-awwg python3 - <<'PYCODE'
from pathlib import Path
p=Path('/opt/cyberrad-awwg/weekly_awwg/weekly.html')
text=p.read_text(encoding='utf-8')
assert 'bubble-groups' in text and 'bubble-severity' in text
print('Weekly v6.10 activo')
PYCODE
trap - ERR
printf 'CyberRad v6.10 instalado. Backup: %s\n' "$BACKUP"
echo 'Abre Weekly Reports y fuerza una recarga completa (Ctrl+Shift+R).'
