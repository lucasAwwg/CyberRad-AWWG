#!/usr/bin/env bash
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
ENV_FILE=/etc/cyberrad-awwg/cyberrad.env
for file in engine.py router.py pptx_report.py weekly.html; do
 if [[ ! -f "$SOURCE/$file" || ! -f "$TARGET/weekly_awwg/$file" ]]; then
   echo "Falta $file en origen o destino. Sin cambios." >&2; exit 2
 fi
done
for path in "$TARGET/docker-compose.kali.yml" "$ENV_FILE"; do
 if [[ ! -f "$path" ]]; then echo "Archivo ausente: $path. Sin cambios." >&2; exit 2; fi
done
if ! docker inspect cyberrad-awwg >/dev/null 2>&1; then echo 'Contenedor CyberRad no encontrado.' >&2; exit 3; fi
if ! docker compose version >/dev/null 2>&1; then echo 'Se necesita docker compose v2.' >&2; exit 4; fi
PYTHONDONTWRITEBYTECODE=1 python3 - "$SOURCE" <<'PYCODE'
import pathlib,sys
base=pathlib.Path(sys.argv[1])
for fn in ('engine.py','router.py','pptx_report.py'):
 compile((base/fn).read_text(encoding='utf-8'),str(base/fn),'exec')
assert 'report_mode' in (base/'engine.py').read_text()
assert 'report-mode' in (base/'weekly.html').read_text()
print('Validación previa correcta.')
PYCODE
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" config -q
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.5-${STAMP}.tar.gz"
tar -C "$TARGET" -czf "$BACKUP" weekly_awwg/engine.py weekly_awwg/router.py weekly_awwg/pptx_report.py weekly_awwg/weekly.html
rollback() {
 echo 'ERROR: restaurando archivos semanales desde el backup...' >&2
 tar -C "$TARGET" -xzf "$BACKUP" || true
 docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" up -d --build --no-deps cyberrad || true
 echo "Backup conservado: $BACKUP" >&2
}
trap rollback ERR
for file in engine.py router.py pptx_report.py weekly.html; do
 install -m 644 -- "$SOURCE/$file" "$TARGET/weekly_awwg/$file"
done
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" up -d --build --no-deps cyberrad
if [[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg)" != true ]]; then
 echo 'El contenedor no está en ejecución.' >&2; false
fi
trap - ERR
printf 'CyberRad Weekly 6.5 instalado. Backup: %s\n' "$BACKUP"
echo 'No se han modificado la base de datos, los tokens ni Sauron.'
