# CyberRad AWWG · Weekly Reports v6.6 — AI News Enrichment

Parche incremental sobre la **v6.5**: incluye `engine.py`, `router.py`, `weekly.html`, `pptx_report.py` y el nuevo `enrichment.py`. NO reinstala CyberRad, no cambia el esquema de noticias ni reemplaza `/var/lib/cyberrad-awwg` o Sauron.

## Qué cambia

1. Al generar con los modos **Automático / Manual / Mixto**, se seleccionan las noticias como en v6.5 y **solo entonces** se intenta consultar el artículo completo de cada noticia elegida. La recopilación de noticias sigue sin requerir selección manual.
2. Comprueba enlaces HTTPS públicos, DNS y redirecciones (bloquea destinos internos, loopback, enlaces especiales y ficheros grandes). No sigue enlaces sospechosos, no trata contenido HTML como instrucciones y no intenta eludir muros de pago.
3. Convierte HTML a texto utilizable, priorizando `<article>` o `<main>`. Para enlaces Google News se intenta localizar el artículo del editor; el método de Google News no está documentado oficialmente y puede dejar de funcionar.
4. Si hay un modelo de IA configurado, se le facilita **solo el artículo público**, nunca nombres internos, inventarios, credenciales ni conclusiones internas sobre AWWG. Se le exige redactar texto en inglés, fiel a la evidencia, en cuatro secciones: **What happened**, **Technical details**, **Potential exposure / risk** y **Recommended action**. Se comprueban identificadores CVE y cantidades numéricas contra la fuente.
5. Si la IA no está configurada, falla o la fuente no es accesible, se ofrece un resumen **extractivo** con frases textuales del artículo disponible, o la información escasa del RSS/CISA claramente identificada. **No se inventan CVEs, versiones, CVSS, explotación ni impactos de AWWG.**
6. Se ha rediseñado la ficha A4 para aprovechar mejor la página con explicaciones más largas; se conservan las tablas técnicas, acciones, enlaces y notas completas en el PPTX editable. PDF y PPTX proceden del mismo contenido.
7. Caché de enriquecimiento en el volumen de datos de CyberRad (24 h para artículo, 2 h para RSS escaso), con textos de fuentes públicas; evita reabrir continuamente las mismas webs. El archivo de configuración de IA se guarda privado, separado del informe.
8. La interfaz informa del número de fichas con IA, artículos leídos y noticias basadas únicamente en RSS. **El software informa «IA no configurada»** si falta conectar el modelo; no anuncia falsamente que está usando IA.

## Instalar en Kali desde tu GitHub (main)

Sube primero `CyberRad_AWWG_Weekly_6_6_AI_Enrichment_HOTFIX.zip` a `https://github.com/lucasAwwg/CyberRad-AWWG` (rama `main`). **No estará disponible en GitHub hasta que lo subas.**

```bash
cd /tmp
curl -fL --retry 3 'https://raw.githubusercontent.com/lucasAwwg/CyberRad-AWWG/main/CyberRad_AWWG_Weekly_6_6_AI_Enrichment_HOTFIX.zip' -o CyberRad_AWWG_Weekly_6_6_AI_Enrichment_HOTFIX.zip
unzip -t CyberRad_AWWG_Weekly_6_6_AI_Enrichment_HOTFIX.zip
mkdir -p /tmp/cyberrad-weekly-6.6
unzip -qo CyberRad_AWWG_Weekly_6_6_AI_Enrichment_HOTFIX.zip -d /tmp/cyberrad-weekly-6.6
sudo bash /tmp/cyberrad-weekly-6.6/actualizar_weekly_kali.sh /opt/cyberrad-awwg
sudo docker logs --tail=80 cyberrad-awwg
```

Después abre `/weekly`, recarga con **Ctrl+Shift+R** y genera un informe. En «Informe semanal» aparecerá el recuento de `Noticias ampliadas con IA`, `Artículos analizados` y `Solo titular/RSS`.

### Conectar una IA de verdad (opcional pero necesario para redacción generativa)

La v6.5 no contiene integración IA en Weekly Reports; v6.6 añade soporte para **OpenAI Chat Completions HTTPS** y para **Ollama**. No viene con una clave, modelo ni conexión a la IA preconfigurados. La ampliación extractiva sin IA funciona automáticamente si puede accederse a las webs.

Desde `/tmp/cyberrad-weekly-6.6` ejecuta:

```bash
sudo python3 configurar_ia_weekly.py
```

- Elige `1` para un endpoint compatible con OpenAI. Se solicitará nombre exacto del modelo y una API key oculta con `getpass`. Utiliza HTTPS. Consulta los requisitos de salida a Internet de la empresa.
- Elige `2` para **Ollama**, indicando un modelo disponible y una URL accesible **desde el contenedor**, no solo desde Kali. `host.docker.internal` puede necesitar configuración específica en Docker Linux. Comprueba también que el modelo cabe en tu hardware; la VM de 4 vCPU / 10 GB no es adecuada para modelos grandes.
- La herramienta guarda los ajustes con permisos privados dentro del volumen persistente de CyberRad (`weekly_ai_config.json`), no en los archivos que se suben a GitHub, ni en `cyberrad.env`, ni en el historial de la terminal. Puedes modificarlo volviendo a ejecutar el configurador. También admite las variables `CYBERRAD_WEEKLY_AI_PROVIDER`, `CYBERRAD_WEEKLY_AI_MODEL`, `CYBERRAD_WEEKLY_AI_URL`, `CYBERRAD_WEEKLY_AI_API_KEY` **si ya están realmente presentes dentro del contenedor**.
- Un proveedor remoto solo recibe el texto publicado por la fuente; confirma que su uso está autorizado por AWWG. Los costes y límites de la API dependen de tu proveedor. Ningún texto generado por IA debe publicarse como verificación definitiva sin revisión.

## Verificación y reversión

Antes de darlo por terminado, verifica que `/healthz` responda como antes, el informe se descargue en PPTX y PDF, y comprueba el texto de al menos dos noticias reales contra las fuentes. Si una fuente bloquea acceso, aparecerá la limitación de evidencia en vez de inventar detalles.

El instalador valida sintaxis, comprueba Compose, crea `/var/backups/cyberrad-awwg/weekly-6.6-*.tar.gz`, despliega el módulo y comprueba que el contenedor importe `weekly_awwg.enrichment`. Si falla, intenta recuperar los archivos anteriores y reconstruir **solo CyberRad**. No elimina bases de datos, informes, configuraciones, claves, backups ni Sauron.

Para revertir manualmente, sustituye `FECHA_REAL` por la que devuelve el instalador:

```bash
sudo tar -C /opt/cyberrad-awwg -xzf /var/backups/cyberrad-awwg/weekly-6.6-FECHA_REAL.tar.gz
# Retira enrichment.py SOLO si no estaba incluido en el backup:
if ! sudo tar -tzf /var/backups/cyberrad-awwg/weekly-6.6-FECHA_REAL.tar.gz | grep -q 'weekly_awwg/enrichment.py'; then
  sudo rm -f /opt/cyberrad-awwg/weekly_awwg/enrichment.py
fi
sudo docker compose --project-directory /opt/cyberrad-awwg --env-file /etc/cyberrad-awwg/cyberrad.env -f /opt/cyberrad-awwg/docker-compose.kali.yml up -d --build --no-deps cyberrad
```

**Nota:** el comando condicional anterior conserva cualquier `enrichment.py` anterior incluido en la copia de seguridad.

Cuando confirmes funcionamiento, elimina solo los archivos temporales del hotfix:

```bash
rm -rf -- /tmp/cyberrad-weekly-6.6
rm -f -- /tmp/CyberRad_AWWG_Weekly_6_6_AI_Enrichment_HOTFIX.zip
```

## Alcance de pruebas

Se verifican tests sintéticos sin red, importación de módulos, sintaxis Python y JavaScript, y exportación PPTX→PDF con LibreOffice local, incluyendo comprobación visual de una ficha A4. **No se ha probado en la VM Kali real ni contra el modelo IA o Google News desde la red corporativa.** La salida real dependerá de conectividad, disponibilidad de artículos y permisos del proveedor.
