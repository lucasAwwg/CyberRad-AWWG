# CyberRad AWWG — Weekly Reports v6.8

Hotfix incremental sobre Weekly v6.6, **incluye el diseño adaptable de v6.7**. Solo sustituye los archivos `weekly_awwg/{weekly.html,router.py,pptx_report.py}` y añade `weekly_awwg/hackmanac.py`. No sustituye el motor de noticias, la integración de IA o la base de datos.

## Cambios

- Elimina la **pestaña Wholesale / Retail** y su formulario de cifras manuales del menú Weekly Reports. Se mantienen las categorías de vigilancia `Retail and wholesale`, otras funciones de CyberRad y los históricos de tendencias en SQLite, pero **ya no se genera una página de sector separada** con esos valores históricos.
- Si una noticia seleccionada es un **Hack Tuesday oficial de Hackmanac**, consulta esa edición y el enlace oficial a la edición **exactamente siete días anterior**. Crea una comparación directamente en la ficha de la noticia, bajo `HACKMANAC — WEEK-OVER-WEEK`.
- Datos comparables, si las dos ediciones los publican: ataques globales, países, ESIX medio (no es CVSS), ataques críticos estimados y datos reclamados en TB. Se muestra la dirección y variación porcentual de los ataques, con las fechas de las ediciones.
- **Enfoque AWWG:** se aclara que la evolución global no permite afirmar una tendencia particular de retail/wholesale ni la exposición de AWWG cuando no se dispone de cifras sectoriales verificadas. Se guardan las URL de ambas ediciones y los datos completos de la ficha en notas editables del PPTX.
- **IA opcional:** si ya se ha configurado OpenAI compatible u Ollama en v6.6, el modelo puede aportar una frase de interpretación basada en datos estructurados y públicos, sin enviar información interna ni inventar datos sectoriales. Sin IA, la comparación determinista sigue funcionando.
- En caso de fuente inaccesible o semanas no consecutivas, se indica que la comparación no está disponible: nada de estadísticas inventadas.
- Conserva el rediseño adaptable de v6.7: separación moderada entre apartados, sin huecos gigantes ni superposiciones.
- Automático / Manual / Mixto y la ampliación por IA de noticias funcionan igual que en v6.6.

**Importante:** el comparativo solo se activa con una noticia Hack Tuesday seleccionada (URL oficial `https://hackmanac.com/news/hack-tuesday-week-.../`). No se añaden informes Hackmanac por defecto si sus noticias no forman parte del resultado. Hackmanac puede cambiar su HTML; el parser no asume acceso a HackRisk, contenido de pago o imágenes de las gráficas.

## Instalación (Kali y Sauron)

Primero sube `CyberRad_AWWG_Weekly_6_8_Hackmanac_Comparison_HOTFIX.zip` a `https://github.com/lucasAwwg/CyberRad-AWWG`, rama `main`. No se sube automáticamente con el hotfix.

```bash
cd /tmp
curl -fL --retry 3 'https://raw.githubusercontent.com/lucasAwwg/CyberRad-AWWG/main/CyberRad_AWWG_Weekly_6_8_Hackmanac_Comparison_HOTFIX.zip' -o CyberRad_AWWG_Weekly_6_8_Hackmanac_Comparison_HOTFIX.zip
unzip -t CyberRad_AWWG_Weekly_6_8_Hackmanac_Comparison_HOTFIX.zip
mkdir -p /tmp/cyberrad-weekly-6.8
unzip -qo CyberRad_AWWG_Weekly_6_8_Hackmanac_Comparison_HOTFIX.zip -d /tmp/cyberrad-weekly-6.8
sudo bash /tmp/cyberrad-weekly-6.8/actualizar_weekly_kali.sh /opt/cyberrad-awwg
sudo docker logs --tail=80 cyberrad-awwg
```

Tras instalar, abre Weekly Reports, fuerza la recarga con `Ctrl+Shift+R` y selecciona una noticia Hack Tuesday en modo Manual o Mixto si quieres comprobar la ficha comparativa. Genera de nuevo el PDF/PPTX. Los informes previamente exportados no se modifican.

## Pruebas y límites

- Comprobación de sintaxis Python / JavaScript / Bash.
- Prueba de dos ediciones sintéticas reproducidas de las fuentes oficiales del 28 oct–03 nov y 21–27 oct 2026: 389 vs 494 ataques, 52 vs 67 países, ESIX 4.74 vs 4.80; bloquea URLs de otros dominios y semanas separadas por otra cantidad de días.
- Generación PPTX editable y PDF con datos de prueba, inspección visual A4 de la ficha.
- **Sin ensayo de conectividad real desde la VM Kali corporativa** (esta sesión no llega a Hackmanac por red). Debe verificarse la obtención de las dos ediciones en tu entorno; si el firewall impide el acceso, se registra la ausencia de datos y no se realizan afirmaciones sin evidencia.

## Restauración

El instalador guarda antes de instalar un respaldo en `/var/backups/cyberrad-awwg/weekly-6.8-FECHA.tar.gz`; conserva ese archivo. Si falla la instalación, intenta restaurarlo automáticamente. Para revertir manualmente, usa la ruta real que mostrará:

```bash
sudo tar -C /opt/cyberrad-awwg -xzf '/var/backups/cyberrad-awwg/weekly-6.8-FECHA_REAL.tar.gz'
sudo rm -f /opt/cyberrad-awwg/weekly_awwg/hackmanac.py  # solo si no existía antes de v6.8
sudo docker compose --project-directory /opt/cyberrad-awwg --env-file /etc/cyberrad-awwg/cyberrad.env -f /opt/cyberrad-awwg/docker-compose.kali.yml up -d --build --no-deps cyberrad
```

**Limpieza opcional, solo tras validar:**

```bash
rm -rf -- /tmp/cyberrad-weekly-6.8
rm -f -- /tmp/CyberRad_AWWG_Weekly_6_8_Hackmanac_Comparison_HOTFIX.zip
```

No borrar `/opt/cyberrad-awwg`, `/var/lib/cyberrad-awwg`, `/etc/cyberrad-awwg`, respaldos útiles ni archivos de Sauron. No usar `docker prune`.
