#!/usr/bin/env bash
# CyberRad AWWG Weekly v6.11: bubble filter fix + improved preliminary severity.
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$HERE/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
DEST="$TARGET/weekly_awwg"
ENV_FILE='/etc/cyberrad-awwg/cyberrad.env'
COMPOSE_FILE="$TARGET/docker-compose.kali.yml"
FILES=(weekly.html engine.py)
for path in "$COMPOSE_FILE" "$ENV_FILE" "$DEST/router.py" "$DEST/enrichment.py"; do
 [[ -f "$path" ]] || { echo "Falta $path; sin cambios" >&2; exit 2; }
done
for f in "${FILES[@]}"; do
 [[ -f "$SOURCE/$f" ]] || { echo "Falta $f en el ZIP; sin cambios" >&2; exit 2; }
 [[ -f "$DEST/$f" ]] || { echo "Falta $f en la instalación base; sin cambios" >&2; exit 2; }
done
command -v docker >/dev/null && docker compose version >/dev/null || { echo 'Docker Compose v2 no disponible' >&2; exit 4; }
docker inspect cyberrad-awwg >/dev/null 2>&1 || { echo 'No se encontró cyberrad-awwg' >&2; exit 4; }
PYTHONDONTWRITEBYTECODE=1 python3 - "$SOURCE" <<'PYCODE'
from pathlib import Path
import sys
root=Path(sys.argv[1])
compile((root/'engine.py').read_text(encoding='utf-8'), str(root/'engine.py'), 'exec')
h=(root/'weekly.html').read_text(encoding='utf-8')
assert 'data-action=' in h and 'bubble-severity' in h and 'selectSubgroup' in h
assert 'infer_press_priority' in (root/'engine.py').read_text(encoding='utf-8')
print('Verificación estática v6.11: OK')
PYCODE
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config -q
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.11-${STAMP}.tar.gz"
tar -C "$TARGET" -czf "$BACKUP" weekly_awwg/weekly.html weekly_awwg/engine.py
rollback() {
 echo 'La actualización falló: restaurando archivos previos…' >&2
 tar -C "$TARGET" -xzf "$BACKUP" || true
 docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad || true
 echo "Respaldo: $BACKUP" >&2
}
trap rollback ERR
for f in "${FILES[@]}"; do install -m 0644 -- "$SOURCE/$f" "$DEST/$f"; done
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d --build --no-deps cyberrad
[[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg)" == 'true' ]]
docker exec cyberrad-awwg python3 - <<'PYCODE'
from weekly_awwg.engine import infer_press_priority, connect, LOCK
import json
assert infer_press_priority('Actively exploited RCE','Vendor confirms remote code execution exploited in the wild', ['CVE-2026-0001'])=='HIGH'
updated=0
with LOCK, connect() as con:
 rows=con.execute("SELECT id,title,summary,source,cves,priority FROM news WHERE provenance='press_unverified'").fetchall()
 for row in rows:
  try:cves=json.loads(row['cves'] or '[]')
  except Exception:cves=[]
  new_priority=infer_press_priority(row['title'], row['summary'], cves, row['source'])
  if new_priority != row['priority']:
   con.execute('UPDATE news SET priority=? WHERE id=?', (new_priority, row['id']))
   updated += 1
 con.commit()
print(f'Weekly v6.11 activo · prioridades recalculadas: {updated}')
PYCODE
trap - ERR
printf 'CyberRad v6.11 instalado. Backup: %s\n' "$BACKUP"
echo 'Incluye filtro de burbujas corregido y mejor priorización preliminar.'
