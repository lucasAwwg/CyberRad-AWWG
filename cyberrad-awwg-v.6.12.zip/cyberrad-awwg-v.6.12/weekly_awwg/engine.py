"""AWWG weekly research pipeline. Does not alter CyberRad's existing tables."""
from __future__ import annotations
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from email.utils import parsedate_to_datetime
import hashlib
import html
import unicodedata
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import sqlite3
from threading import RLock
from functools import lru_cache
from collections import OrderedDict
import time
from typing import Any
from urllib.parse import quote, urlparse
import requests
from defusedxml import ElementTree as ET

BASE = Path(os.environ.get('CYBERRAD_AWWG_DATA', str(Path.home() / '.cyberrad_awwg'))).expanduser()
DB = BASE / 'weekly.sqlite3'
SETTINGS = BASE / 'settings.json'
REPORTS = BASE / 'reports'
LOCK = RLock()
INITIALIZE_LOCK = RLock()
_INITIALIZED_DB = None
_FETCH_CACHE = OrderedDict()
_FETCH_CACHE_LOCK = RLock()
_FETCH_TTL_SECONDS = 600
_FETCH_CACHE_MAX = 24
CISA_JSON = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json'
NEWS_FEEDS = (
    ('BleepingComputer', 'https://www.bleepingcomputer.com/feed/'),
    ('The Hacker News', 'https://thehackernews.com/feeds/posts/default'),
)
WATCH_DEFAULT = [
    'WordPress', 'WooCommerce', 'Magento', 'Adobe Commerce', 'PrestaShop',
    'Apache', 'nginx', 'PHP', 'Python', 'Node.js', 'Linux', 'Ubuntu',
    'Synology', 'QNAP', 'TeamViewer', 'AnyDesk', 'Fortinet', 'Citrix',
    'NetScaler', 'Docker', 'Kubernetes', 'Microsoft', 'Windows Server',
    'Dell', 'Broadcom', 'VPN', 'e-commerce', 'retail', 'wholesale',
    'fashion', 'apparel', 'supplier', 'data breach', 'ransomware',
    # Endpoint protection, disk encryption, corporate MFA, RMM and observability.
    'CrowdStrike', 'CrowdStrike Falcon', 'Falcon Sensor',
    'BitLocker', 'Windows', 'Microsoft Windows',
    'Cisco Duo', 'Duo Security', 'Duo MFA',
    'NinjaOne', 'NinjaRMM', 'Grafana', 'Grafana Loki',
]
CATEGORIES = {
 'Web servers': ['Apache', 'nginx', 'IIS'],
 'CMS and e-commerce': ['WordPress', 'WooCommerce', 'Magento', 'Adobe Commerce', 'PrestaShop'],
 'Languages and runtimes': ['PHP', 'Python', 'Node.js'],
 'Operating systems': ['Linux kernel', 'Ubuntu', 'Windows Server', 'Windows', 'BitLocker'],
 'NAS and remote access': ['Synology', 'QNAP', 'TeamViewer', 'AnyDesk'],
 'Network and identity': ['Fortinet', 'Citrix', 'NetScaler', 'VPN', 'SAML', 'Cisco Duo', 'Duo Security', 'Duo MFA'],
 'Endpoint security and RMM': ['CrowdStrike', 'CrowdStrike Falcon', 'Falcon Sensor', 'NinjaOne', 'NinjaRMM'],
 'Monitoring and observability': ['Grafana', 'Grafana Loki'],
 'Cloud and supply chain': ['Docker', 'Kubernetes', 'MSP', 'supplier', 'data breach'],
 'Retail and wholesale': ['retail', 'wholesale', 'e-commerce', 'ransomware'],
}
NEW_WATCH_V62 = (
 'CrowdStrike', 'CrowdStrike Falcon', 'Falcon Sensor',
 'BitLocker', 'Windows', 'Microsoft Windows',
 'Cisco Duo', 'Duo Security', 'Duo MFA',
 'NinjaOne', 'NinjaRMM', 'Grafana', 'Grafana Loki',
)
NEW_CATEGORIES_V62 = ('Endpoint security and RMM', 'Monitoring and observability')
TERMS = re.compile(r'\b(cve-\d{4}-\d{4,}|vulnerabilit(?:y|ies)|exploit(?:ed|ation|s)?|zero.day|breach|ransomware|cyberattacks?|security (?:update|flaw|bug|patch|advisory)|remote code execution|unauthori[sz]ed access|credential theft|malware|patch(?:ed|ing)?)\b',re.I)
CVES = re.compile(r'CVE-\d{4}-\d{4,}', re.I)
NEGATIVE = re.compile(r'\b(movie|fitness routine|video game review|fashion week|sports results)\b', re.I)

DEFAULT = {
 'watch_schema_version': 2,
 'company': 'AWWG',
 'report_title': 'Cyber News Weekly Report',
 'language': 'en',
 'sector': 'Wholesale / Retail / Fashion / E-commerce',
 'watch_terms': WATCH_DEFAULT,
 'enabled_categories': list(CATEGORIES),
 'max_news': 12,
 'report_mode': 'automatic',
 'min_business_priority': 'LOW',
 'auto_include_cisa_kev': True,
 'always_show_sector_trends': True,
 'include_only_verified': True,
 'notes': 'Internal AWWG weekly cybersecurity review. No confirmed exposure without internal evidence.',
}
PRIORITY = ('CRITICAL', 'HIGH', 'MID', 'LOW')


def initialize() -> None:
 global _INITIALIZED_DB
 if _INITIALIZED_DB == str(DB) and DB.exists() and SETTINGS.exists(): return
 with INITIALIZE_LOCK:
  if _INITIALIZED_DB == str(DB) and DB.exists() and SETTINGS.exists(): return
  _initialize_once()
  _INITIALIZED_DB = str(DB)

def _initialize_once() -> None:
 BASE.mkdir(parents=True, exist_ok=True)
 REPORTS.mkdir(parents=True, exist_ok=True)
 if not SETTINGS.exists():
  SETTINGS.write_text(json.dumps(DEFAULT, ensure_ascii=False, indent=2), encoding='utf-8')
 with connect() as con:
  con.execute('PRAGMA journal_mode=WAL')
  con.execute('''CREATE TABLE IF NOT EXISTS news (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, summary TEXT NOT NULL,
    source TEXT NOT NULL, source_url TEXT NOT NULL, published TEXT NOT NULL,
    discovered TEXT NOT NULL, category TEXT NOT NULL,
    cves TEXT NOT NULL, vendor_severity TEXT NOT NULL,
    priority TEXT NOT NULL, status TEXT NOT NULL, provenance TEXT NOT NULL,
    company_impact TEXT NOT NULL, action TEXT NOT NULL,
    affected TEXT NOT NULL, fixed TEXT NOT NULL, cvss TEXT NOT NULL,
    verified_exploitation TEXT NOT NULL, original_title TEXT NOT NULL,
    published_at TEXT NOT NULL DEFAULT ''
  )''')
  if 'published_at' not in {row[1] for row in con.execute('PRAGMA table_info(news)')}:
   con.execute("ALTER TABLE news ADD COLUMN published_at TEXT NOT NULL DEFAULT ''")
  con.execute('''CREATE TABLE IF NOT EXISTS audit (
    at TEXT NOT NULL, item_id TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL
  )''')
  # Distinguish an analyst's explicit inclusion from default CISA inclusion.
  if 'manual_include' not in {row[1] for row in con.execute('PRAGMA table_info(news)')}:
   con.execute('ALTER TABLE news ADD COLUMN manual_include INTEGER NOT NULL DEFAULT 0')
   # Recover earlier analyst decisions from the existing audit trail.
   for ev in con.execute("SELECT item_id, detail FROM audit WHERE event='edit' ORDER BY rowid").fetchall():
    try:status=json.loads(ev['detail']).get('status')
    except (TypeError,ValueError,AttributeError):continue
    if status in ('included','excluded','pending'):
     con.execute('UPDATE news SET manual_include=? WHERE id=?',
       (int(status=='included'),ev['item_id']))
  con.execute('CREATE INDEX IF NOT EXISTS audit_item_event_idx ON audit(item_id,event)')
  con.execute('CREATE INDEX IF NOT EXISTS news_date_idx ON news(published)')
  con.execute('CREATE INDEX IF NOT EXISTS news_week_status_idx ON news(published,status,priority)')


@contextmanager
def connect():
 DB.parent.mkdir(parents=True, exist_ok=True)
 con=sqlite3.connect(DB, timeout=15)
 try:
  con.row_factory=sqlite3.Row
  con.execute('PRAGMA busy_timeout=10000')
  yield con
  con.commit()
 except Exception:
  con.rollback()
  raise
 finally:
  con.close()


def get_settings() -> dict:
 initialize()
 try:
  saved = json.loads(SETTINGS.read_text(encoding='utf-8'))
  # Add new corporate scope to pre-existing v6.1 installations, without dropping
  # analyst-defined terms, historical news, or prior category selections.
  if saved.get('watch_schema_version', 1) < 2:
   before_terms = saved.get('watch_terms', WATCH_DEFAULT)
   if not isinstance(before_terms, list): before_terms = WATCH_DEFAULT
   new_terms = [x for x in WATCH_DEFAULT if x in NEW_WATCH_V62]
   saved['watch_terms'] = list(dict.fromkeys([*before_terms, *new_terms]))
   before_cats = saved.get('enabled_categories', list(CATEGORIES))
   if not isinstance(before_cats, list): before_cats = list(CATEGORIES)
   saved['enabled_categories'] = list(dict.fromkeys([*before_cats, *NEW_CATEGORIES_V62]))
   saved['watch_schema_version'] = 2
   with LOCK:
    # Preserve the exact existing custom settings; only extend the new watch scope.
    tmp = SETTINGS.with_suffix('.migrate.tmp')
    tmp.write_text(json.dumps(saved,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(SETTINGS)
  return {**DEFAULT, **saved}
 except (OSError, ValueError):
  return DEFAULT.copy()


def save_settings(changes: dict) -> dict:
 allowed = {'watch_terms','enabled_categories','max_news','min_business_priority','auto_include_cisa_kev','always_show_sector_trends','include_only_verified','notes','report_mode'}
 if any(k not in allowed for k in changes):
  raise ValueError('Settings can only change AWWG intelligence parameters, not the company identity or report branding.')
 cfg = get_settings()
 for k,v in changes.items():
  if k in ('watch_terms','enabled_categories'):
   if not isinstance(v,list) or len(v)>100 or any(not isinstance(s,str) or len(s)>90 for s in v): raise ValueError('Invalid list')
   if k == 'enabled_categories' and any(s not in CATEGORIES for s in v): raise ValueError('Unknown category')
   v = list(dict.fromkeys(s.strip() for s in v if s.strip()))
  if k == 'report_mode' and v not in ('automatic','manual','mixed'): raise ValueError('Invalid report mode')
  if k == 'max_news':
   if type(v) is not int or not (1<=v<=30): raise ValueError('max_news must be from 1 to 30')
  if k == 'min_business_priority' and v not in PRIORITY: raise ValueError('Invalid priority')
  if k in ('auto_include_cisa_kev','always_show_sector_trends','include_only_verified') and type(v) is not bool: raise ValueError('Invalid toggle')
  if k=='notes' and (not isinstance(v,str) or len(v)>1000): raise ValueError('Invalid notes')
  cfg[k]=v
 with LOCK:
  temp=SETTINGS.with_suffix('.tmp')
  temp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
  temp.replace(SETTINGS)
 if 'watch_terms' in changes or 'enabled_categories' in changes:
  reassess_priorities(cfg)
 return cfg


def date_range(week_start: str | None = None) -> tuple[date,date]:
 """Moving seven-day period (calendar date bounds) in Europe/Madrid.

 Includes the boundary dates touched by the last 168 hours. For RSS/Atom,
 an exact 168-hour filter is applied when timestamps are available.
 Date-only advisories (such as CISA KEV) are necessarily day-granular.
 """
 today = datetime.now(ZoneInfo('Europe/Madrid')).date()
 if week_start:
  start = date.fromisoformat(week_start)
  if start > today:
   raise ValueError('The report period cannot start in the future')
 else:
  start = today - timedelta(days=7)
 return start, start + timedelta(days=7)


@lru_cache(maxsize=24)
def _compiled_watch(terms:tuple[str,...]):
 if not terms:return re.compile(r'(?!)')
 return re.compile(r'(?<!\w)(?:' + '|'.join(re.escape(t) for t in terms) + r')(?!\w)',re.I)

def matches_watch(text: str, settings: dict)->bool:
 return bool(_compiled_watch(tuple(settings['watch_terms'])).search(text))


def classify(text: str)->str:
 for k,terms in CATEGORIES.items():
  if any(re.search(re.escape(t),text,re.I) for t in terms): return k
 return 'Other cybersecurity'


def news_id(title: str, cves: list[str]) -> str:
 # A CVE remains one story across multiple syndicated articles; otherwise use a normalized title.
 key=','.join(sorted(cves)) if cves else re.sub(r'[^a-z0-9]+',' ', title.lower()).strip()
 return hashlib.sha256(key.encode()).hexdigest()[:24]


def fetch(url: str)->requests.Response:
 # Cache identical feed requests for 10 minutes; no reduction in fetched items.
 now=time.monotonic()
 with _FETCH_CACHE_LOCK:
  stored=_FETCH_CACHE.get(url)
  if stored and now-stored[0]<_FETCH_TTL_SECONDS:
   _FETCH_CACHE.move_to_end(url)
   return stored[1]
 response=requests.get(url,timeout=(5,12),headers={'User-Agent':'CyberRad-AWWG-Weekly/0.2 security intelligence'})
 response.raise_for_status()
 if len(response.content)>8_000_000:raise ValueError('Source too large')
 with _FETCH_CACHE_LOCK:
  _FETCH_CACHE[url]=(time.monotonic(),response)
  _FETCH_CACHE.move_to_end(url)
  while len(_FETCH_CACHE)>_FETCH_CACHE_MAX:_FETCH_CACHE.popitem(last=False)
 return response


def ingest_kev(start:date,end:date,cfg:dict)->list[dict]:
 data=fetch(CISA_JSON).json()
 rows=[]
 for v in data.get('vulnerabilities',[]):
  when=v.get('dateAdded','')
  if not (start.isoformat()<=when<=end.isoformat()): continue
  vendor = re.sub(r'\s+', ' ', str(v.get('vendorProject') or '')).strip()
  product = re.sub(r'\s+', ' ', str(v.get('product') or '')).strip()
  issue = re.sub(r'\s+', ' ', str(v.get('vulnerabilityName') or '')).strip()
  original_title = f"{vendor} {product} — {issue}".strip()
  # 'PHP Group PHP — PHP ... Vulnerability' -> 'PHP — ...'; original kept below.
  short_issue = re.sub(r'\s+Vulnerability$', '', issue, flags=re.I).strip()
  short_issue = re.sub(r'^' + re.escape(product) + r'\s+', '', short_issue, flags=re.I) if product else short_issue
  display_product = product or vendor or 'Unspecified product'
  title = f"{display_product} — {short_issue or issue}"[:180]
  body=f"{original_title} {v.get('shortDescription','')} {v.get('requiredAction','')}"
  if not matches_watch(body,cfg): continue
  cve=v.get('cveID','').upper(); cves=[cve] if CVES.fullmatch(cve) else []
  # The KEV requiredAction can contain long federal-policy boilerplate.
  # Keep the verifiable exploitation fact and an actionable AWWG-specific recommendation;
  # do not claim patch availability, affected versions, or internal compromise.
  product = re.sub(r'\s+', ' ', v.get('product') or v.get('vendorProject') or 'this product').strip()[:65]
  action = (f'Check whether {product} is deployed. Review the vendor advisory for '
            'affected versions and available fixes or mitigations; prioritize exposed '
            'systems and investigate exploitation indicators.')
  rows.append(dict(id=news_id(title,cves),title=title[:220],summary=(v.get('shortDescription') or '')[:1800],source='CISA KEV',
      source_url=f'https://www.cisa.gov/known-exploited-vulnerabilities-catalog?field_cve={quote(cve)}', published=when,published_at='',
      category=(classify(display_product) if classify(display_product)!='Other cybersecurity' else classify(body)),cves=json.dumps(cves),vendor_severity='Not supplied by KEV',
      priority=assess_priority({'title':title,'summary':v.get('shortDescription') or '',
          'category':(classify(display_product) if classify(display_product)!='Other cybersecurity' else classify(body)),
          'provenance':'official_cisa_kev'},cfg),status='included' if cfg['auto_include_cisa_kev'] else 'pending',provenance='official_cisa_kev',
      company_impact='CHECK IF IT APPLIES — AWWG exposure has not been verified.',action=str(action)[:550],
      affected='Not verified — consult vendor bulletin',fixed='Not verified — consult vendor bulletin',cvss='Not supplied by CISA KEV',
      verified_exploitation='YES — listed in CISA KEV',original_title=original_title))
 return rows



class _HTMLToText(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True)
  self.parts=[]
 def handle_data(self, data): self.parts.append(data)
 def handle_starttag(self, tag, attrs):
  if tag in ('br','p','li'): self.parts.append(' ')


def clean_content(value: str, *, strip_markup: bool=True)->str:
 """Normalize escaped RSS/Google-News HTML and stray invisible glyphs."""
 raw=str(value or '')
 for _ in range(3):
  decoded=html.unescape(raw)
  if decoded==raw:break
  raw=decoded
 if strip_markup and re.search(r'</?(?:p|span|div|a|br|strong|em|ul|li|b)(?:\s|>|/)',raw,re.I):
  parser=_HTMLToText()
  try:parser.feed(raw);raw=' '.join(parser.parts)
  except (ValueError,TypeError):raw=re.sub(r'<[^>]*>',' ',raw)
 raw=''.join(' ' if c in ('\xa0','\u200b','\ufeff','\u2060') or unicodedata.category(c) in ('Cc','Cf') else c for c in raw)
 return re.sub(r'\s+',' ',raw).strip()


def _publisher_from_google(title:str,item)->tuple[str,str]:
 """Google News RSS often duplicates a publisher suffix in its headline."""
 source_node=item.find('source')
 publisher=clean_content(''.join(source_node.itertext()) if source_node is not None else '',strip_markup=False)
 m=re.search(r'\s[-–—]\s([^–—]{2,90})$',title)
 if m:
  tail=m.group(1).strip()
  if (publisher and tail.casefold()==publisher.casefold()) or re.fullmatch(r'[\w.-]+\.(?:com|net|org|io|hu|co\.uk|es|de|fr)',tail,re.I):
   title=title[:m.start()].rstrip()
   if not publisher:publisher=tail
 return title,publisher or 'Google News'


def concise_action(category:str,title:str)->str:
 context=(str(category)+' '+str(title)).lower()
 if any(x in context for x in ('synology','qnap','nas')):
  return 'Check the NAS vendor advisory, affected models and DSM/QTS versions. Confirm updates, exposure and backup status if applicable.'
 if any(x in context for x in ('wordpress','woocommerce','magento','commerce','prestashop','cms')):
  return 'Check the original CMS/vendor bulletin, deployed versions and extensions. Review any web compromise indicators before patching.'
 if any(x in context for x in ('retail','wholesale','breach','ransomware','e-commerce')):
  return 'Verify the incident with the organization or its providers. Assess supplier/customer-data exposure only if a link to AWWG is established.'
 if any(x in context for x in ('falcon','crowdstrike','duo','ninja','grafana','bitlocker','teamviewer')):
  return 'Check the product security advisory, deployment scope, fixed builds and access/telemetry indicators where relevant.'
 if any(x in context for x in ('linux','ubuntu','windows','php','python','node.js','apache','nginx')):
  return 'Identify affected systems and releases; confirm the vendor advisory and patch or mitigation before taking operational action.'
 return 'Verify the original report and vendor guidance; confirm AWWG relevance, affected versions and mitigation status before escalation.'


# Severity evaluation: preliminary news priority, NOT a verified AWWG exposure claim.
# A title calling something "critical" is insufficient for CRITICAL.
CVSS_SCORE = re.compile(
 r'\b(?:CVSS(?:\s*v(?:3(?:\.[01])?|4(?:\.0)?))?\s*(?:base\s*)?(?:score\s*)?|'
 r'severity\s+(?:score|rating)\s*)'
 r'(?:of\s*|is\s*|at\s*|rated\s*|:|=)?\s*'
 r'(10(?:\.0)?|[0-9](?:\.[0-9])?)\b', re.I)
SUPPLY_CHAIN_RISK = re.compile(
 r'\b(?:supply[ -]chain (?:risk|attack|compromise|breach|incident|security|threat|vulnerabilit(?:y|ies))|'
 r'software supply[ -]chain|dependency confusion|malicious (?:npm|pypi|package|dependency)|'
 r'poisoned (?:package|dependency)|compromised (?:build|update) pipeline)\b',re.I)
PRESS_HIGH = re.compile(
 r'\b(?:actively exploited|exploited in the wild|known exploited|exploitation in the wild|'
 r'zero[ -]?day|0[ -]?day|remote code execution|\bRCE\b|arbitrary code execution|'
 r'unauthenticated (?:remote|attack|access)|pre[ -]?auth(?:entication)?|'
 r'authentication bypass|auth bypass|privilege escalation|'
 r'ransomware|data breach|mass exploitation|wormable|takeover|take over|'
 r'critical (?:vulnerability|flaw|bug|security issue))\b',re.I)
PRESS_MID = re.compile(
 r'\b(?:CVE-\d{4}-\d{4,}|vulnerabilit(?:y|ies)|security (?:flaw|bug|patch|update|advisory)|'
 r'patch(?:ed|ing)?|advisory|SQL injection|SQLi|cross[ -]site scripting|XSS|'
 r'directory traversal|path traversal|information disclosure|exposure|'
 r'misconfiguration|denial of service|\bDoS\b|bypass|exploit|malware)\b',re.I)
NON_TECH_WATCH_TERMS = frozenset({
 'data breach','ransomware','fashion','apparel','supplier','retail','wholesale',
})


def _documented_cvss(text:str)->float|None:
 """Only explicit CVSS/severity scores. Do not mistake dates or versions for scores."""
 # 'CVSS 3.1 score 9.8' refers to the scoring standard, not a score of 3.1.
 text=re.sub(r'\bCVSS\s+(?:3\.[01]|4\.0)(?=\s+(?:base\s+)?score\b)',
             'CVSS',text,flags=re.I)
 found=[]
 for match in CVSS_SCORE.finditer(text):
  try:
   score=float(match.group(1))
   if 0 <= score <= 10:found.append(score)
  except (TypeError,ValueError):pass
 return max(found) if found else None


def _category_is_watched(title:str,summary:str,category:str,cfg:dict)->bool:
 """Requires the relevant product/technology to be in the configured watch list.

 Generic risk topics alone (e.g. ransomware, data breach) do not make a
 non-watched product eligible for CRITICAL.
 """
 if category not in set(cfg.get('enabled_categories',[])):
  return False
 headline=' '.join((title,summary))
 for term in cfg.get('watch_terms',[]):
  key=str(term).strip()
  if not key or key.casefold() in NON_TECH_WATCH_TERMS:continue
  if re.search(r'(?<!\w)'+re.escape(key)+r'(?!\w)',headline,re.I):return True
 return False


def assess_priority(row:dict,cfg:dict)->str:
 """Business-news triage using only source text + configured technology scope.

 Rules, in order:
  * Supply-chain risk: MID, regardless of other flags.
  * CRITICAL: explicit score >=9.0 AND a watched product in an enabled category.
  * HIGH: explicit score >=7.0, known exploitation, serious compromise or RCE.
  * MID: explicit score >=4.0 or credible vulnerability/patch signal.
  * LOW: generic information without evidence of higher severity.
 CISA KEV without qualifying CVSS remains HIGH (known exploited).
 """
 title=str(row.get('title','') or '')
 summary=str(row.get('summary','') or '')
 category=str(row.get('category','') or '')
 text=' '.join(str(row.get(k,'') or '') for k in ('title','summary','original_title','cvss','vendor_severity'))
 if SUPPLY_CHAIN_RISK.search(text):return 'MID'
 score=_documented_cvss(text)
 if score is not None and score >= 9.0 and _category_is_watched(title,summary,category,cfg):
  return 'CRITICAL'
 if row.get('provenance')=='official_cisa_kev':return 'HIGH'
 if (score is not None and score >= 7.0) or PRESS_HIGH.search(text):return 'HIGH'
 cves=row.get('cves',[])
 if isinstance(cves,str):
  try:cves=json.loads(cves)
  except (ValueError,TypeError):cves=[]
 if (score is not None and score >= 4.0) or bool(cves) or PRESS_MID.search(text):return 'MID'
 return 'LOW'


def infer_press_priority(title:str, summary:str, cves:list[str], source:str='',
                         category:str='',cfg:dict|None=None)->str:
 """Compatibility wrapper used when parsing RSS."""
 if cfg is None:cfg=DEFAULT
 return assess_priority(dict(title=title,summary=summary,cves=cves,
   source=source,category=category,provenance='press_unverified'),cfg)


def reassess_priorities(cfg:dict|None=None)->dict:
 """Recalculate *existing* items, keeping analyst-edited priorities unchanged.

 Called by the installer and whenever watched technologies change. Purely local:
 no network requests, no AI and no alterations to selection/status/report files.
 """
 initialize()
 if cfg is None:cfg=get_settings()
 counts={p:0 for p in PRIORITY}; changed=0;skipped=0
 with LOCK,connect() as con:
  protected=set()
  for row in con.execute("SELECT item_id,detail FROM audit WHERE event='edit'"):
   try:
    fields=json.loads(row['detail'])
    if isinstance(fields,dict) and 'priority' in fields:protected.add(row['item_id'])
   except (ValueError,TypeError,AttributeError):pass
  rows=con.execute("SELECT * FROM news WHERE provenance IN ('press_unverified','official_cisa_kev')").fetchall()
  for r in rows:
   item=dict(r)
   if item['id'] in protected:
    skipped+=1
    continue
   new_priority=assess_priority(item,cfg)
   counts[new_priority]+=1
   if new_priority!=item['priority']:
    con.execute('UPDATE news SET priority=? WHERE id=?',(new_priority,item['id']))
    changed+=1
 return {'updated':changed,'protected_manual_priorities':skipped,'classified':counts}


def text_of(elem:Any,tag:str)->str:
 node=elem.find(tag)
 return ''.join(node.itertext()).strip() if node is not None else ''


def date_parsed(s: str)->str | None:
 if not s: return None
 try: return parsedate_to_datetime(s).date().isoformat()
 except (TypeError,ValueError):
  try: return datetime.fromisoformat(s.replace('Z','+00:00')).date().isoformat()
  except (TypeError,ValueError): return None


def published_timestamp(value:str):
 """Convert provider timestamps into UTC; return None for undated entries."""
 if not value:return None
 try:
  dt=parsedate_to_datetime(value)
 except (TypeError,ValueError):
  try:dt=datetime.fromisoformat(value.replace('Z','+00:00'))
  except (TypeError,ValueError):return None
 if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
 return dt.astimezone(timezone.utc)


def rolling_cutoff(start:date,end:date):
 now=datetime.now(ZoneInfo('Europe/Madrid'))
 if start==now.date()-timedelta(days=7) and end==now.date():
  return (now-timedelta(days=7)).astimezone(timezone.utc),now.astimezone(timezone.utc)
 return None


def parse_rss(xml:bytes,source:str,start:date,end:date,cfg:dict)->list[dict]:
 root=ET.fromstring(xml)
 items=root.findall('.//item')
 if not items: items=root.findall('.//{http://www.w3.org/2005/Atom}entry')
 results=[]
 for item in items:
  is_atom=item.tag.endswith('entry')
  raw_title=text_of(item,'{http://www.w3.org/2005/Atom}title') if is_atom else text_of(item,'title')
  raw_summary=text_of(item,'{http://www.w3.org/2005/Atom}summary') if is_atom else text_of(item,'description')
  rawdate=text_of(item,'{http://www.w3.org/2005/Atom}published') if is_atom else text_of(item,'pubDate')
  pub_dt=published_timestamp(rawdate)
  day=pub_dt.astimezone(ZoneInfo('Europe/Madrid')).date().isoformat() if pub_dt else date_parsed(rawdate)
  if not day or not start.isoformat()<=day<=end.isoformat(): continue
  bounds=rolling_cutoff(start,end)
  if pub_dt and bounds and not(bounds[0]<=pub_dt<=bounds[1]):continue
  title=clean_content(raw_title)
  summary=clean_content(raw_summary)
  publisher=''
  if source=='Google News discovery':
   title,publisher=_publisher_from_google(title,item)
   # Google headlines are often copied into the summary, separated by NBSP.
   # Keep factual source text only if it adds substantial independent detail.
   if summary.casefold().startswith(title.casefold()):
    summary=summary[len(title):].strip(' -–—·.,')
   if publisher:
    summary=re.sub(r'^(?:'+re.escape(publisher)+r')(?:\s*[-·|])?\s*','',summary,flags=re.I)
   if len(summary)<75:
    summary='Headline-only discovery; the original article and vendor advisory have not yet been independently reviewed.'
  content=(title+' '+summary).strip()
  if not title or not TERMS.search(content) or NEGATIVE.search(title) or not matches_watch(content,cfg):continue
  link=text_of(item,'link')
  if is_atom:
   el=item.find('{http://www.w3.org/2005/Atom}link')
   link=el.attrib.get('href','') if el is not None else ''
  if urlparse(link).scheme not in ('https','http'): continue
  cves=list(dict.fromkeys(x.upper() for x in CVES.findall(content)))
  source_label=publisher+' (via Google News)' if publisher else source
  category=classify(title+' '+summary)
  priority=infer_press_priority(title,summary,cves,source_label,category,cfg)
  results.append(dict(id=news_id(title,cves),title=title[:220],summary=summary[:1200],source=source_label,source_url=link,
    published=day,published_at=pub_dt.isoformat() if pub_dt else '',category=category,cves=json.dumps(cves),vendor_severity='Needs vendor verification',
    priority=priority,status='pending',provenance='press_unverified',
    company_impact='UNASSESSED — do not claim AWWG impact without evidence.',
    action=concise_action(category,title),
    affected='Not verified',fixed='Not verified',cvss='Not verified',verified_exploitation='Not verified',original_title=clean_content(raw_title)[:360]))
 return results


def ingest_google(start:date,end:date,cfg:dict,category:str)->list[dict]:
 terms=CATEGORIES[category]
 # Do not send company inventory, supplier relationships, or internal names to search providers.
 q='('+' OR '.join('"'+t+'"' for t in terms)+') (CVE OR vulnerability OR data breach OR ransomware OR security patch)'
 q+=f' after:{start.isoformat()} before:{(end+timedelta(days=1)).isoformat()}'
 url='https://news.google.com/rss/search?q='+quote(q)+'&hl=en-US&gl=US&ceid=US:en'
 return parse_rss(fetch(url).content,'Google News discovery',start,end,cfg)


def _save_items(items:list[dict])->int:
 now=datetime.now(timezone.utc).isoformat()
 count=0
 # The official CISA entry wins over syndicated reporting when both reference the same CVE.
 items=sorted(items,key=lambda row:row.get('provenance')=='official_cisa_kev',reverse=True)
 with LOCK,connect() as con:
  for r in items:
   r['discovered']=now
   existing=con.execute('SELECT provenance,status,published_at FROM news WHERE id=?',(r['id'],)).fetchone()
   if existing and existing['provenance']=='press_unverified' and r['provenance']=='press_unverified':
    protected=set()
    for a in con.execute('SELECT detail FROM audit WHERE item_id=? AND event=?',(r['id'],'edit')):
     try: protected.update(json.loads(a['detail']).keys())
     except (ValueError,TypeError,AttributeError):pass
    fields=('title','summary','source','source_url','category','action','original_title','priority')
    changes={k:r[k] for k in fields if k not in protected}
    if changes:
     con.execute('UPDATE news SET '+', '.join(k+'=?' for k in changes)+' WHERE id=?',
                 [*changes.values(),r['id']])
    continue
   if existing and existing['provenance']=='official_cisa_kev' and r['provenance']=='official_cisa_kev':
    # Refresh previously auto-generated titles/actions (fixes reports made by older code).
    # Respect analyst-edited fields recorded in the immutable audit log.
    protected=set()
    for audit_row in con.execute('SELECT detail FROM audit WHERE item_id=? AND event=?',(r['id'],'edit')):
     try:protected.update(json.loads(audit_row['detail']).keys())
     except (ValueError,TypeError,AttributeError):pass
    changes={key:r[key] for key in ('title','original_title','category','action') if key not in protected}
    if changes:
     con.execute('UPDATE news SET '+', '.join(key+'=?' for key in changes)+' WHERE id=?',
                 [*changes.values(),r['id']])
    continue
   if existing and not existing['published_at'] and r.get('published_at'):
    con.execute('UPDATE news SET published_at=? WHERE id=?',(r['published_at'],r['id']))
   if existing and existing['status']=='pending' and existing['provenance']=='press_unverified' and r['provenance']=='official_cisa_kev':
    # Upgrade unreviewed coverage to authoritative evidence, never overwrite an analyst decision.
    keys=[key for key in r if key not in ('id','discovered')]
    con.execute('UPDATE news SET '+', '.join(k+'=?' for k in keys)+' WHERE id=?',
                [*[r[k] for k in keys],r['id']])
    continue
   # Existing editorial decisions and details must not be reset by repeated imports.
   cols=list(r)
   con.execute('INSERT OR IGNORE INTO news ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',[r[c] for c in cols])
   count+=con.execute('SELECT changes()').fetchone()[0]
 return count


def research(start:date,end:date)->dict:
 initialize();cfg=get_settings()
 jobs=[('cisa',None),('rss',NEWS_FEEDS[0]),('rss',NEWS_FEEDS[1])]
 jobs.extend(('google',c) for c in cfg['enabled_categories'])
 gathered=[];errors=[]
 def run(job):
  typ,arg=job
  if typ=='cisa':return ingest_kev(start,end,cfg)
  if typ=='rss':return parse_rss(fetch(arg[1]).content,arg[0],start,end,cfg)
  return ingest_google(start,end,cfg,arg)
 with ThreadPoolExecutor(max_workers=4) as pool:
  futures={pool.submit(run,job):job for job in jobs}
  for f in as_completed(futures):
   try:gathered.extend(f.result())
   except Exception as ex: errors.append(f'{futures[f][0]} / {futures[f][1]}: {str(ex)[:180]}')
 return {'new_items':_save_items(gathered),'candidate_items':len(gathered),'source_errors':errors,'week_start':start.isoformat(),'week_end':end.isoformat()}


def list_items(start:date,end:date,all_statuses:bool=True)->list[dict]:
 initialize()
 with connect() as con:
  rows=con.execute('SELECT * FROM news WHERE published BETWEEN ? AND ? ORDER BY published DESC, priority ASC',(start.isoformat(),end.isoformat())).fetchall()
 bounds=rolling_cutoff(start,end)
 def valid(row):
  if not (all_statuses or row['status']=='included'):return False
  if bounds and row['published_at']:
   try:
    when=datetime.fromisoformat(row['published_at'])
    if when.tzinfo is not None and not(bounds[0]<=when<=bounds[1]):return False
   except ValueError:pass
  return True
 return [dict(x)|{'cves':json.loads(x['cves'])} for x in rows if valid(x)]


def update_item(item_id:str, changes:dict)->dict:
 allowed={'status','priority','company_impact','action','affected','fixed','cvss','verified_exploitation','vendor_severity','summary','category'}
 if any(k not in allowed for k in changes) or not changes: raise ValueError('Invalid editable field')
 for k,v in changes.items():
  if not isinstance(v,str) or len(v)>1800: raise ValueError('Invalid field content')
  if k=='status' and v not in ('included','pending','excluded'): raise ValueError('Invalid status')
  if k=='priority' and v not in PRIORITY: raise ValueError('Invalid priority')
 with LOCK,connect() as con:
  found=con.execute('SELECT * FROM news WHERE id=?',(item_id,)).fetchone()
  if not found: raise KeyError(item_id)
  updates=dict(changes)
  if 'status' in updates:
   updates['manual_include']=int(updates['status']=='included')
  query='UPDATE news SET '+', '.join(k+'=?' for k in updates)+' WHERE id=?'
  con.execute(query,[*updates.values(),item_id])
  con.execute('INSERT INTO audit(at,item_id,event,detail) VALUES(?,?,?,?)',
   (datetime.now(timezone.utc).isoformat(),item_id,'edit',json.dumps(changes,ensure_ascii=False)))
  return dict(con.execute('SELECT * FROM news WHERE id=?',(item_id,)).fetchone())

def add_manual_item(values:dict)->dict:
 """Explicitly add a linked analyst-submitted story without server-side fetching.

 If a story already exists, include that record rather than duplicating it.
 """
 initialize()
 title=clean_content(values.get('title',''))
 summary=clean_content(values.get('summary',''))
 source_url=str(values.get('source_url','')).strip()
 parsed=urlparse(source_url)
 if not title or len(title)>200 or not summary or len(summary)>1800:
  raise ValueError('Provide a title (max 200) and short summary (max 1800).')
 if parsed.scheme!='https' or not parsed.hostname or len(source_url)>2048 or parsed.username or parsed.password:
  raise ValueError('The source must be a public HTTPS link without credentials.')
 published=str(values.get('published','')).strip()
 try: day=date.fromisoformat(published)
 except (TypeError,ValueError):raise ValueError('Publication date must use YYYY-MM-DD.')
 now=datetime.now(ZoneInfo('Europe/Madrid')).date()
 if day>now or day<now-timedelta(days=7):
  raise ValueError('Manually added items must be published within the last seven days.')
 category=str(values.get('category','')).strip()
 if category not in CATEGORIES:raise ValueError('Choose a valid category.')
 priority=str(values.get('priority','LOW')).upper().strip()
 if priority not in PRIORITY:raise ValueError('Invalid priority.')
 source=clean_content(values.get('source',''))[:100] or (parsed.hostname or 'Manual source')
 cves=list(dict.fromkeys(x.upper() for x in CVES.findall(title+' '+summary)))
 rid=news_id(title,cves)
 with LOCK,connect() as con:
  existing=con.execute('SELECT id FROM news WHERE id=?',(rid,)).fetchone()
  if existing:
   con.execute('UPDATE news SET status=?, manual_include=? WHERE id=?',('included',1,rid))
  else:
   row=dict(id=rid,title=title,summary=summary,source=source,source_url=source_url,
     published=published,discovered=datetime.now(timezone.utc).isoformat(),category=category,
     cves=json.dumps(cves),vendor_severity='Manual review',priority=priority,status='included',
     provenance='manual_user',company_impact='UNASSESSED — no verified direct AWWG impact.',
     action=concise_action(category,title),affected='Not verified',fixed='Not verified',
     cvss='Not verified',verified_exploitation='Not verified',original_title=title,
     published_at='',manual_include=1)
   keys=list(row)
   con.execute('INSERT INTO news ('+','.join(keys)+') VALUES ('+','.join('?' for _ in keys)+')',[row[k] for k in keys])
  con.execute('INSERT INTO audit(at,item_id,event,detail) VALUES (?,?,?,?)',
    (datetime.now(timezone.utc).isoformat(),rid,'edit',json.dumps({'status':'included','manual_submission':True},ensure_ascii=False)))
  return dict(con.execute('SELECT * FROM news WHERE id=?',(rid,)).fetchone())


def _content_quality(row:dict)->int:
 """Selection quality is evidence-based, never a claim about AWWG exposure."""
 quality=0
 origin=row.get('provenance','')
 if origin=='official_cisa_kev':quality+=115
 elif row.get('source','') in ('BleepingComputer','The Hacker News'):quality+=70
 elif 'via Google News' in row.get('source',''):quality+=16
 else:quality+=38
 length=len(row.get('summary',''))
 if length>=140:quality+=20
 elif length>=80:quality+=6
 elif length<65:quality-=15
 if 'Headline-only' in row.get('summary',''):quality-=25
 if row.get('cves'):quality+=12
 if row.get('category')!='Other cybersecurity':quality+=12
 if row.get('status')=='included':quality+=18
 try:
  age=(datetime.now(ZoneInfo('Europe/Madrid')).date()-date.fromisoformat(row['published'])).days
  quality+=max(0,10-age)
 except (KeyError,ValueError):pass
 return quality


def select_for_report(rows:list[dict],cfg:dict,reviewed_only:bool=False,mode:str|None=None)->tuple[list[dict],str]:
 """Select by explicit report mode, preserving analyst exclusions.

 automatic: settings-driven eligible sources only, no preferential manual picks.
 manual: only explicit analyst inclusions.
 mixed: analyst inclusions first; remaining slots filled automatically.
 A hard max_news cap applies to every mode.
 """
 mode = 'manual' if reviewed_only else (mode or cfg.get('report_mode','automatic'))
 if mode not in ('automatic','manual','mixed'):
  raise ValueError('Invalid report mode')
 unique={}
 for row in rows:
  unique.setdefault(row['id'],dict(row))
 available=[row for row in unique.values() if row.get('status')!='excluded']
 cap=max(1,min(30,int(cfg.get('max_news',12))))
 manual=[]
 if mode in ('manual','mixed'):
  manual=[row for row in available if row.get('status')=='included' and bool(row.get('manual_include'))]
  manual.sort(key=lambda row:(PRIORITY.index(row.get('priority','LOW')),-date.fromisoformat(row['published']).toordinal()))
  manual=manual[:cap]
  for row in manual:row['_selection']='manual'
 if mode=='manual':return manual,'manual'
 cfg_categories=set(cfg.get('enabled_categories',[]))
 max_priority=PRIORITY.index(cfg.get('min_business_priority','LOW'))
 verified_only=bool(cfg.get('include_only_verified',True))
 auto_cisa=bool(cfg.get('auto_include_cisa_kev',True))
 manual_ids={row['id'] for row in manual}
 candidates=[]
 for row in available:
  if row['id'] in manual_ids:continue
  if PRIORITY.index(row.get('priority','LOW'))>max_priority:continue
  if row.get('category') not in cfg_categories:continue
  if not matches_watch(' '.join(str(row.get(x,'')) for x in ('title','summary','original_title')),cfg):continue
  is_cisa=row.get('provenance')=='official_cisa_kev'
  if is_cisa and not auto_cisa:continue
  if verified_only and not is_cisa:continue
  candidates.append(row)
 candidates.sort(key=lambda row:(_content_quality(row),row.get('published','')),reverse=True)
 remaining=max(0,cap-len(manual))
 auto=[];cat_count={}
 for per_category_cap in (3,max(3,remaining)):
  for row in candidates:
   if len(auto)>=remaining:break
   if row['id'] in {x['id'] for x in auto}:continue
   category=row.get('category','Other cybersecurity')
   if cat_count.get(category,0)>=per_category_cap:continue
   row['_selection']='automatic_verified' if row.get('provenance')=='official_cisa_kev' else 'auto_draft'
   auto.append(row)
   cat_count[category]=cat_count.get(category,0)+1
  if len(auto)>=remaining:break
 combined=manual+auto
 combined.sort(key=lambda row:(PRIORITY.index(row.get('priority','LOW')),-date.fromisoformat(row['published']).toordinal(),row.get('_selection')!='manual'))
 return combined,mode


def counts(items:list[dict])->dict:
 return {x:sum(1 for item in items if item['priority']==x) for x in PRIORITY}


def trend_for(start:date)->dict|None:
 initialize()
 with connect() as con:
  con.execute('''CREATE TABLE IF NOT EXISTS sector_trends (week_start TEXT PRIMARY KEY, data TEXT NOT NULL)''')
  row=con.execute('SELECT data FROM sector_trends WHERE week_start=?',(start.isoformat(),)).fetchone()
  return json.loads(row['data']) if row else None


def set_trend(start:date, data:dict)->dict:
 allowed={'attacks','previous_attacks','rank','previous_rank','global_attacks','previous_global_attacks','data_tb','previous_data_tb','source'}
 if any(k not in allowed for k in data): raise ValueError('Unknown trend metric')
 if any(len(str(v))>250 for v in data.values()):raise ValueError('Invalid trend value')
 if 'source' not in data or not str(data['source']).startswith('https://'):
  raise ValueError('A verifiable https source is required for sector data')
 with LOCK,connect() as con:
  con.execute('CREATE TABLE IF NOT EXISTS sector_trends (week_start TEXT PRIMARY KEY, data TEXT NOT NULL)')
  con.execute('INSERT OR REPLACE INTO sector_trends VALUES(?,?)',(start.isoformat(),json.dumps(data)))
 return data
