from __future__ import annotations

import asyncio
import contextlib
import threading
import time
from io import BytesIO
from collections import deque, OrderedDict

import requests
from PIL import Image, ImageOps, UnidentifiedImageError
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlparse
from typing import Literal

from fastapi import FastAPI, HTTPException, Response
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, HttpUrl
from starlette.requests import Request

from .db import ARTICLE_LIGHT_COLUMNS, PROFILE_PRESETS, add_feed, delete_feed, feedback_summary, fetch_articles_batch, fetch_articles_for_dashboard, get_article, get_settings, init_db, is_brands_priority_feed, list_articles, list_feeds, list_sector_articles, rescore_articles, runtime_profile_config, seed_default_feeds, stats, toggle_feed, update_article_status, update_settings, upsert_articles
from .exporter import export_articles_to_docx
from .rss import HEADERS, duplicate_resolution_priority, parse_datetime_to_dt, parse_feed, source_profile
from .incident_map import build_incident_map_data, export_incident_map_pdf, filter_articles_for_sector_display
from weekly_awwg import router as awwg_weekly_router

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES = Jinja2Templates(directory=str(BASE_DIR / 'templates'))


API_CACHE_TTL_SECONDS = 45.0
ARTICLES_API_CACHE: dict[tuple[object, ...], dict[str, object]] = OrderedDict()
ARTICLE_VIEW_CACHE: dict[tuple[object, ...], dict[str, object]] = OrderedDict()
MAP_API_CACHE: dict[tuple[object, ...], dict[str, object]] = OrderedDict()
MAP_FULL_API_CACHE: dict[tuple[object, ...], dict[str, object]] = OrderedDict()
COUNTRY_API_CACHE: dict[tuple[object, ...], dict[str, object]] = OrderedDict()
ARTICLE_UNIVERSE_CACHE: dict[tuple[object, ...], dict[str, object]] = OrderedDict()
STATE_API_CACHE_TTL_SECONDS = 6.0
STATE_API_CACHE: dict[str, dict[str, object]] = {'full': {'ts': 0.0, 'signature': None, 'data': None}, 'lite': {'ts': 0.0, 'signature': None, 'data': None}}
IMAGE_PROXY_CACHE_TTL_SECONDS = 900.0
IMAGE_PROXY_CACHE: dict[str, dict[str, object]] = OrderedDict()
IMAGE_PROXY_CACHE_BYTES = 32 * 1024 * 1024
IMAGE_PROXY_CACHE_LOCK = threading.RLock()
IMAGE_PROFILE_OPTIONS = {
    'low_resource': {'max_width': 360, 'quality': 42, 'format': 'JPEG'},
    'balanced': {'max_width': 720, 'quality': 68, 'format': 'JPEG'},
    'full': {'max_width': 1440, 'quality': 84, 'format': 'JPEG'},
}
DB_WRITE_LOCK = asyncio.Lock()
REFRESH_LOCK = asyncio.Lock()
WEEKLY_RENDER_LOCK = asyncio.Lock()


async def run_db_write(func, *args, **kwargs):
    async with DB_WRITE_LOCK:
        return await asyncio.to_thread(func, *args, **kwargs)


def _page_args(limit: int = 50, page: int = 1) -> tuple[int, int]:
    page_size = max(1, min(100, int(limit or 50)))
    current_page = max(1, int(page or 1))
    return current_page, page_size


def _dedupe_article_dicts(items: list[dict[str, object]], hide_duplicates: bool) -> list[dict[str, object]]:
    if not hide_duplicates:
        return items
    seen: set[str] = set()
    output: list[dict[str, object]] = []
    for item in items:
        key = str(item.get('duplicate_group') or item.get('cluster_key') or item.get('title') or item.get('id') or '')
        if key in seen:
            continue
        seen.add(key)
        output.append(item)
    return output


def _display_sort_key(item: dict[str, object]) -> tuple[float, float]:
    try:
        published_ts = parse_datetime_to_dt(item.get('published_at')).timestamp()
    except Exception:
        published_ts = 0.0
    return (duplicate_resolution_priority(item), published_ts)


def _source_bucket(article: dict[str, object]) -> str:
    profile = source_profile(article.get('feed_name') or '', article.get('feed_url') or '', article.get('article_url') or '')
    if profile.get('is_feedly'):
        return 'feedly'
    if profile.get('is_google_aggregator'):
        return 'google'
    if profile.get('specialist_signal'):
        return 'specialist'
    return 'other'


def _balanced_source_mix(items: list[dict[str, object]], sector: str = 'general') -> list[dict[str, object]]:
    if not items:
        return []
    buckets: dict[str, deque[dict[str, object]]] = {'feedly': deque(), 'specialist': deque(), 'other': deque(), 'google': deque()}
    for item in items:
        buckets[_source_bucket(item)].append(item)
    for bucket_name, values in buckets.items():
        buckets[bucket_name] = deque(sorted(values, key=_display_sort_key, reverse=True))
    if sector == 'general':
        cycle = ['feedly', 'specialist', 'feedly', 'other', 'specialist', 'google']
    else:
        cycle = ['feedly', 'specialist', 'other', 'google']
    mixed: list[dict[str, object]] = []
    while any(buckets.values()):
        progress = False
        for bucket_name in cycle:
            if buckets[bucket_name]:
                mixed.append(buckets[bucket_name].popleft())
                progress = True
        if not progress:
            break
    return mixed


def build_article_page_payload(status: str = 'all', sector: str = 'general', page: int = 1, page_size: int = 50) -> dict[str, object]:
    current_page, safe_page_size = _page_args(page_size, page)
    settings = get_settings()
    hide_duplicates = bool(settings.get('hide_duplicates', True))
    universe = _article_universe('all')
    view_key = (sector, status, hide_duplicates)
    visible = _cache_get(ARTICLE_VIEW_CACHE, view_key)
    if visible is None:
        # Costly filtering / sorting is performed once per cache window, not once per page.
        filtered = filter_articles_for_sector_display(universe, sector, purpose='display')
        if status != 'all':
            filtered = [item for item in filtered if str(item.get('status') or 'pending') == status]
        visible = sorted(_dedupe_article_dicts(filtered, hide_duplicates), key=_display_sort_key, reverse=True)
        visible = _balanced_source_mix(visible, sector=sector)
        _cache_set(ARTICLE_VIEW_CACHE, view_key, visible)
    start = (current_page - 1) * safe_page_size
    end = start + safe_page_size
    page_rows = visible[start:end]
    has_more = len(visible) > end
    return {
        'articles': page_rows,
        'page': current_page,
        'page_size': safe_page_size,
        'has_more': has_more,
        'scanned': len(universe),
        'total_visible': len(visible),
    }


def _article_universe(status: str = 'all') -> list[dict[str, object]]:
    cache_key = (status,)
    cached = _cache_get(ARTICLE_UNIVERSE_CACHE, cache_key)
    if cached is not None:
        return cached
    articles = fetch_articles_for_dashboard(status=status)
    return _cache_set(ARTICLE_UNIVERSE_CACHE, cache_key, articles)


def build_map_payload(sector: str = 'general', status: str = 'all', year: str | None = None):
    cache_key = (sector, status, year or 'latest')
    cached = _cache_get(MAP_FULL_API_CACHE, cache_key)
    if cached is not None:
        return cached
    articles = _article_universe('all')
    data = build_incident_map_data(articles, sector=sector, status=status, selected_year=year)
    return _cache_set(MAP_FULL_API_CACHE, cache_key, data)


def build_public_map_payload(sector: str = 'general', status: str = 'all', year: str | None = None):
    cache_key = (sector, status, year or 'latest')
    cached = _cache_get(MAP_API_CACHE, cache_key)
    if cached is not None:
        return cached
    full = build_map_payload(sector, status, year)
    payload = dict(full)
    payload['incidents_count'] = len(full.get('incidents') or [])
    payload.pop('incidents', None)
    return _cache_set(MAP_API_CACHE, cache_key, payload)


def build_country_payload(sector: str = 'general', status: str = 'all', year: str | None = None, country: str = '', page: int = 1, page_size: int = 20) -> dict[str, object]:
    canonical = (country or '').strip()
    safe_page = max(1, int(page or 1))
    safe_page_size = max(1, min(100, int(page_size or 20)))
    cache_key = (sector, status, year or 'latest', canonical, safe_page, safe_page_size)
    cached = _cache_get(COUNTRY_API_CACHE, cache_key)
    if cached is not None:
        return cached
    data = build_map_payload(sector, status, year)
    if not canonical:
        payload = {'country': '', 'total': 0, 'page': 1, 'page_size': safe_page_size, 'pages': 1, 'incidents': []}
        return _cache_set(COUNTRY_API_CACHE, cache_key, payload)
    incidents = [item for item in (data.get('incidents') or []) if str(item.get('country') or '') == canonical]
    total = len(incidents)
    start = (safe_page - 1) * safe_page_size
    end = start + safe_page_size
    payload = {
        'country': canonical,
        'total': total,
        'page': safe_page,
        'page_size': safe_page_size,
        'pages': max(1, (total + safe_page_size - 1) // safe_page_size) if total else 1,
        'incidents': incidents[start:end],
    }
    return _cache_set(COUNTRY_API_CACHE, cache_key, payload)


def _state_signature(app: FastAPI) -> tuple[object, ...]:
    current_stats = stats()
    current_settings = get_settings()
    startup = getattr(app.state, 'startup_refresh_result', {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []})
    jobs = get_job_state(app)
    return (
        int(current_stats.get('total_articles', 0)),
        int(current_stats.get('included_count', 0)),
        int(current_stats.get('pending_count', 0)),
        int(current_stats.get('excluded_count', 0)),
        int(current_stats.get('feed_count', 0)),
        bool(current_settings.get('hide_duplicates', True)),
        str(getattr(app.state, 'startup_refresh_finished_at', None) or ''),
        bool(getattr(app.state, 'startup_refresh_in_progress', False)),
        bool(jobs.get('rescore_in_progress', False)),
        bool(jobs.get('rescore_pending', False)),
        str(jobs.get('rescore_last_finished_at') or ''),
        int(startup.get('inserted', 0) or 0),
    )


def _cache_signature() -> tuple[object, ...]:
    current_stats = stats()
    current_settings = get_settings()
    return (
        int(current_stats.get('total_articles', 0)),
        int(current_stats.get('included_count', 0)),
        int(current_stats.get('pending_count', 0)),
        int(current_stats.get('excluded_count', 0)),
        bool(current_settings.get('hide_duplicates', True)),
        str(current_settings.get('date_window', 'all')),
        str(current_settings.get('relevance_mode', 'balanced')),
    )


CACHE_TTL = {}  # Large derived views live longer; refresh and edits invalidate immediately.
CACHE_LIMITS = {
    id(ARTICLE_UNIVERSE_CACHE): 1, id(ARTICLE_VIEW_CACHE): 4,
    id(MAP_FULL_API_CACHE): 2, id(MAP_API_CACHE): 4,
    id(COUNTRY_API_CACHE): 16, id(ARTICLES_API_CACHE): 16,
}


CACHE_TTL.update({id(ARTICLE_UNIVERSE_CACHE): 300.0, id(ARTICLE_VIEW_CACHE): 300.0, id(MAP_FULL_API_CACHE): 300.0, id(MAP_API_CACHE): 300.0})


def _cache_get(store: dict[tuple[object, ...], dict[str, object]], key: tuple[object, ...]):
    entry = store.get(key)
    if not entry:
        return None
    if (entry.get('signature') != _cache_signature()
        or time.monotonic() - float(entry.get('ts', 0.0)) > CACHE_TTL.get(id(store), API_CACHE_TTL_SECONDS)):
        store.pop(key, None)
        return None
    if isinstance(store, OrderedDict):
        store.move_to_end(key)
    return entry.get('data')


def _cache_set(store: dict[tuple[object, ...], dict[str, object]], key: tuple[object, ...], data):
    store[key] = {'signature': _cache_signature(), 'ts': time.monotonic(), 'data': data}
    if isinstance(store, OrderedDict):
        store.move_to_end(key)
        while len(store) > CACHE_LIMITS.get(id(store), 8):
            store.popitem(last=False)
    return data


def _invalidate_response_caches():
    for store in (ARTICLES_API_CACHE, ARTICLE_VIEW_CACHE, ARTICLE_UNIVERSE_CACHE,
                  MAP_API_CACHE, MAP_FULL_API_CACHE, COUNTRY_API_CACHE):
        store.clear()
    for entry in STATE_API_CACHE.values():
        entry['ts'] = 0.0




def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class FeedCreate(BaseModel):
    name: str | None = Field(default=None, min_length=0, max_length=120)
    url: HttpUrl


class FeedToggle(BaseModel):
    is_enabled: bool


class SettingsUpdate(BaseModel):
    prompt: str | None = None
    runtime_profile: Literal['low_resource', 'balanced', 'full'] | None = None
    poll_interval_seconds: int | None = Field(default=None, ge=30, le=86400)
    max_articles_per_feed: int | None = Field(default=None, ge=0, le=1000)
    auto_refresh_enabled: bool | None = None
    date_window: Literal['all', 'today', 'yesterday', '3', '7', '15', '30', '90', '120'] | None = None
    relevance_mode: Literal['flexible', 'balanced', 'strict'] | None = None
    hide_duplicates: bool | None = None
    semantic_reranking: bool | None = None
    feedback_learning: bool | None = None


class ArticleStatusUpdate(BaseModel):
    status: Literal['included', 'pending', 'excluded']


async def _fetch_single_feed(feed: dict[str, object], settings: dict[str, object], *, max_articles: int, retries: int = 2) -> tuple[int, int, dict[str, object] | None]:
    last_error: Exception | None = None
    for attempt in range(retries + 1):
        try:
            articles = await asyncio.to_thread(
                parse_feed,
                feed,
                settings['prompt'],
                max_articles,
                settings['date_window'],
                settings['relevance_mode'],
            )
            inserted = await run_db_write(upsert_articles, articles)
            return len(articles), inserted, None
        except Exception as exc:
            last_error = exc
            await asyncio.sleep(min(1.2 * (attempt + 1), 3.0))
    return 0, 0, {'id': feed.get('id'), 'name': feed.get('name'), 'error': str(last_error) if last_error else 'unknown'}


async def _refresh_feed_group(feeds: list[dict[str, object]], settings: dict[str, object], *, max_articles: int, concurrency: int = 12) -> dict[str, object]:
    semaphore = asyncio.Semaphore(max(1, concurrency))

    async def _wrapped(feed: dict[str, object]):
        async with semaphore:
            return await _fetch_single_feed(feed, settings, max_articles=max_articles)

    scanned = 0
    inserted = 0
    failed_feeds: list[dict[str, object]] = []
    results = await asyncio.gather(*[_wrapped(feed) for feed in feeds]) if feeds else []
    for feed_scanned, feed_inserted, failure in results:
        scanned += feed_scanned
        inserted += feed_inserted
        if failure:
            failed_feeds.append(failure)
    return {'feeds': len(feeds), 'scanned': scanned, 'inserted': inserted, 'failed_feeds': failed_feeds}


async def refresh_all_feeds(*, brands_first: bool = False, bootstrap_only: bool = False) -> dict[str, object]:
    if REFRESH_LOCK.locked():
        return {'busy': True, 'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}
    async with REFRESH_LOCK:
        return await _refresh_all_feeds_locked(brands_first=brands_first, bootstrap_only=bootstrap_only)


async def _refresh_all_feeds_locked(*, brands_first: bool = False, bootstrap_only: bool = False) -> dict[str, object]:
    settings = get_settings()
    profile = runtime_profile_config(settings.get('runtime_profile'))
    feeds = [feed for feed in list_feeds() if feed['is_enabled']]
    # La edición AWWG no da prioridad a un antiguo apartado de Marcas.
    # Todas las fuentes se consultan en la misma pasada; ninguna se elimina.
    priority = [feed for feed in feeds if is_brands_priority_feed(feed)] if brands_first else []
    secondary = [feed for feed in feeds if not is_brands_priority_feed(feed)] if brands_first else feeds

    max_default = max(1, int(settings.get('max_articles_per_feed', profile.get('max_articles_per_feed', 25)) or 25))
    max_priority = max_default
    secondary_concurrency = max(1, int(profile.get('fetch_concurrency', 4) or 4))
    priority_concurrency = max(1, int(profile.get('priority_concurrency', max(1, secondary_concurrency - 1)) or max(1, secondary_concurrency - 1)))

    aggregate = {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': [], 'profile': profile.get('name'), 'active_feed_count': len(feeds)}

    async def _merge(payload: dict[str, object]):
        aggregate['feeds'] += int(payload.get('feeds', 0))
        aggregate['scanned'] += int(payload.get('scanned', 0))
        aggregate['inserted'] += int(payload.get('inserted', 0))
        aggregate['failed_feeds'].extend(payload.get('failed_feeds', []))

    if brands_first and priority:
        print(f"[CyberRad] bootstrap brands feeds={len(priority)} max_articles={max_priority}")
        await _merge(await _refresh_feed_group(priority, settings, max_articles=max_priority, concurrency=priority_concurrency))
        await run_db_write(rescore_articles, settings['prompt'], settings['date_window'], settings['relevance_mode'])
        if bootstrap_only:
            return aggregate

    if secondary:
        print(f"[CyberRad] refresh secondary feeds={len(secondary)} max_articles={max_default}")
        await _merge(await _refresh_feed_group(secondary, settings, max_articles=max_default, concurrency=secondary_concurrency))

    # No full-corpus rescore for unchanged feeds on every poll. However date-window
    # relevance must be recomputed daily, including with no new articles.
    today_utc = datetime.now(timezone.utc).date().isoformat()
    last_rescore_day = getattr(app.state, 'last_rescore_day', None) if (app := globals().get('app')) is not None else None
    if aggregate['inserted'] or (settings.get('date_window') != 'all' and last_rescore_day != today_utc):
        await run_db_write(rescore_articles, settings['prompt'], settings['date_window'], settings['relevance_mode'])
        if app is not None:
            app.state.last_rescore_day = today_utc
    _invalidate_response_caches()
    return aggregate


async def refresh_loop(stop_event: asyncio.Event) -> None:
    while not stop_event.is_set():
        settings = get_settings()
        wait_seconds = max(30, int(settings['poll_interval_seconds']))
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=wait_seconds)
            break
        except asyncio.TimeoutError:
            pass
        if stop_event.is_set():
            break
        try:
            settings = get_settings()
            if settings['auto_refresh_enabled']:
                await refresh_all_feeds()
        except Exception as exc:
            print(f'[CyberRad V4.5] refresh error: {exc}')


async def _startup_refresh_task(app: FastAPI) -> None:
    app.state.startup_refresh_started_at = utc_now_iso()
    app.state.startup_refresh_finished_at = None
    app.state.startup_refresh_error = None
    app.state.startup_refresh_in_progress = True
    app.state.startup_refresh_result = {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}
    try:
        existing_total = stats().get('total_articles', 0)
        if existing_total:
            print(f'[CyberRad] startup warm cache detected: {existing_total} articles already in DB')
        result = await refresh_all_feeds(brands_first=False, bootstrap_only=False)
        app.state.startup_refresh_result = result
    except Exception as exc:
        app.state.startup_refresh_error = str(exc)
        print(f'[CyberRad] startup refresh error: {exc}')
    finally:
        app.state.startup_refresh_in_progress = False
        app.state.startup_refresh_finished_at = utc_now_iso()


def get_job_state(app: FastAPI) -> dict[str, object]:
    return {
        'rescore_in_progress': bool(getattr(app.state, 'rescore_in_progress', False)),
        'rescore_pending': bool(getattr(app.state, 'rescore_pending', False)),
        'rescore_last_started_at': getattr(app.state, 'rescore_last_started_at', None),
        'rescore_last_finished_at': getattr(app.state, 'rescore_last_finished_at', None),
        'rescore_last_error': getattr(app.state, 'rescore_last_error', None),
    }


async def _rescore_worker(app: FastAPI) -> None:
    while True:
        prompt, date_window, relevance_mode = getattr(app.state, 'rescore_params', ('', 'all', 'balanced'))
        app.state.rescore_in_progress = True
        app.state.rescore_last_started_at = utc_now_iso()
        app.state.rescore_last_error = None
        app.state.rescore_pending = False
        try:
            await run_db_write(rescore_articles, prompt, date_window, relevance_mode)
            app.state.last_rescore_day = datetime.now(timezone.utc).date().isoformat()
            _invalidate_response_caches()
        except Exception as exc:
            app.state.rescore_last_error = str(exc)
            print(f'[CyberRad V4.5] rescore error: {exc}')
        finally:
            app.state.rescore_in_progress = False
            app.state.rescore_last_finished_at = utc_now_iso()
        if not getattr(app.state, 'rescore_pending', False):
            break
    app.state.rescore_task = None


def schedule_rescore(app: FastAPI, prompt: str, date_window: str = 'all', relevance_mode: str = 'balanced') -> dict[str, object]:
    app.state.rescore_params = (prompt, date_window, relevance_mode)
    running_task = getattr(app.state, 'rescore_task', None)
    if running_task and not running_task.done():
        app.state.rescore_pending = True
        return get_job_state(app)
    app.state.rescore_task = asyncio.create_task(_rescore_worker(app))
    return get_job_state(app)


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    seed_default_feeds()
    stop_event = asyncio.Event()
    app.state.stop_event = stop_event
    app.state.rescore_task = None
    app.state.last_rescore_day = None
    app.state.startup_refresh_started_at = None
    app.state.startup_refresh_finished_at = None
    app.state.startup_refresh_error = None
    app.state.startup_refresh_in_progress = False
    app.state.startup_refresh_result = {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}
    app.state.startup_refresh_task = asyncio.create_task(_startup_refresh_task(app))
    app.state.refresh_task = asyncio.create_task(refresh_loop(stop_event))
    try:
        yield
    finally:
        stop_event.set()
        for task_name in ('startup_refresh_task', 'refresh_task', 'rescore_task'):
            task = getattr(app.state, task_name, None)
            if task:
                task.cancel()
                with contextlib.suppress(BaseException):
                    await task


app = FastAPI(title='CyberRad AWWG — v5.1.16 · VM 4vCPU/10GB optimizada', lifespan=lifespan)
app.include_router(awwg_weekly_router)
app.mount('/static', StaticFiles(directory=str(BASE_DIR / 'static')), name='static')

@app.get('/healthz', include_in_schema=False)
def healthz():
    # Cheap liveness probe; avoids querying all counters every 30 seconds.
    return {'status': 'ok'}



@app.get('/favicon.ico', include_in_schema=False)
async def favicon():
    return FileResponse(BASE_DIR / 'static' / 'cyberrad-logo.png')


@app.get('/', response_class=HTMLResponse)
async def index(request: Request):
    return TEMPLATES.TemplateResponse(request=request, name='index.html', context={'request': request, 'settings': get_settings(), 'stats': stats(), 'feedback': feedback_summary()})


def _state_payload(app: FastAPI, lite: bool = False) -> dict[str, object]:
    settings = get_settings()
    payload = {
        'settings': {
            'prompt': settings.get('prompt', ''),
            'runtime_profile': settings.get('runtime_profile', 'low_resource'),
            'poll_interval_seconds': settings.get('poll_interval_seconds', 300),
            'max_articles_per_feed': settings.get('max_articles_per_feed', 0),
            'auto_refresh_enabled': settings.get('auto_refresh_enabled', True),
            'date_window': settings.get('date_window', 'all'),
            'relevance_mode': settings.get('relevance_mode', 'balanced'),
            'hide_duplicates': settings.get('hide_duplicates', True),
        },
        'stats': stats(),
        'feedback': feedback_summary(),
        'runtime_profiles': {name: {'label': cfg.get('label'), 'description': cfg.get('description'), 'enabled_feed_count': len(runtime_profile_config(name).get('enabled_feed_urls') or []), 'max_articles_per_feed': int(cfg.get('max_articles_per_feed', 0) or 0), 'image_quality_profile': str(cfg.get('image_quality_profile', name))} for name, cfg in PROFILE_PRESETS.items()},
        'jobs': get_job_state(app),
        'startup': {
            'started_at': getattr(app.state, 'startup_refresh_started_at', None),
            'finished_at': getattr(app.state, 'startup_refresh_finished_at', None),
            'error': getattr(app.state, 'startup_refresh_error', None),
            'in_progress': bool(getattr(app.state, 'startup_refresh_in_progress', False)),
            'result': getattr(app.state, 'startup_refresh_result', {'feeds': 0, 'scanned': 0, 'inserted': 0, 'failed_feeds': []}),
        },
    }
    if not lite:
        payload['feeds'] = list_feeds()
    return payload


@app.get('/api/state')
async def api_state(request: Request, lite: int = 0):
    cache_name = 'lite' if lite else 'full'
    signature = _state_signature(request.app)
    now = time.monotonic()
    cache_entry = STATE_API_CACHE[cache_name]
    if cache_entry.get('data') is not None and cache_entry.get('signature') == signature and (now - float(cache_entry.get('ts', 0.0))) <= STATE_API_CACHE_TTL_SECONDS:
        return cache_entry['data']
    payload = _state_payload(request.app, lite=bool(lite))
    STATE_API_CACHE[cache_name] = {'ts': now, 'signature': signature, 'data': payload}
    return payload


def _resolve_image_profile(profile: str | None) -> tuple[str, dict[str, int | str]]:
    name = str(profile or '').strip().lower() or 'balanced'
    if name not in IMAGE_PROFILE_OPTIONS:
        name = 'balanced'
    return name, IMAGE_PROFILE_OPTIONS[name]


def _optimize_image_payload(body: bytes, content_type: str, profile: str) -> tuple[bytes, str]:
    profile_name, options = _resolve_image_profile(profile)
    Image.MAX_IMAGE_PIXELS = 16_000_000
    if profile_name == 'full' or content_type in {'image/gif', 'image/svg+xml'}:
        return body, content_type
    try:
        with Image.open(BytesIO(body)) as image:
            image = ImageOps.exif_transpose(image)
            if image.mode not in {'RGB', 'L'}:
                image = image.convert('RGB')
            max_width = int(options['max_width'])
            if image.width > max_width:
                ratio = max_width / float(image.width)
                image = image.resize((max_width, max(1, int(image.height * ratio))), Image.Resampling.LANCZOS)
            out = BytesIO()
            image.save(out, format=str(options['format']), quality=int(options['quality']), optimize=True, progressive=True)
            return out.getvalue(), 'image/jpeg'
    except (UnidentifiedImageError, OSError, ValueError):
        return body, content_type


def _fetch_image_proxy_payload(url: str, profile: str = 'balanced') -> tuple[bytes, str]:
    parsed = urlparse(url)
    if parsed.scheme not in {'http', 'https'}:
        raise HTTPException(status_code=400, detail='URL de imagen no válida')
    profile_name, _ = _resolve_image_profile(profile)
    cache_key = f"{profile_name}|{url}"
    with IMAGE_PROXY_CACHE_LOCK:
        cached = IMAGE_PROXY_CACHE.get(cache_key)
        if cached and (time.monotonic() - float(cached.get('ts', 0.0))) <= IMAGE_PROXY_CACHE_TTL_SECONDS:
            IMAGE_PROXY_CACHE.move_to_end(cache_key)
            return cached['body'], cached['content_type']
    # Streaming response: reject oversized images *before* buffering full remote bodies.
    with requests.get(url, headers={**HEADERS, 'Referer': url}, timeout=(3, 7), stream=True) as response:
        response.raise_for_status()
        content_type = (response.headers.get('content-type') or '').split(';', 1)[0].strip().lower()
        if not content_type.startswith('image/'):
            raise HTTPException(status_code=415, detail='El recurso no es una imagen')
        max_bytes = 6 * 1024 * 1024
        if int(response.headers.get('content-length') or 0) > max_bytes:
            raise HTTPException(status_code=413, detail='Imagen demasiado grande')
        data = bytearray()
        for chunk in response.iter_content(chunk_size=65536):
            data.extend(chunk)
            if len(data) > max_bytes:
                raise HTTPException(status_code=413, detail='Imagen demasiado grande')
        body = bytes(data)
    body, content_type = _optimize_image_payload(body, content_type, profile_name)
    if len(body) <= IMAGE_PROXY_CACHE_BYTES:
        with IMAGE_PROXY_CACHE_LOCK:
            IMAGE_PROXY_CACHE[cache_key] = {'ts': time.monotonic(), 'body': body, 'content_type': content_type}
            IMAGE_PROXY_CACHE.move_to_end(cache_key)
            total_bytes = sum(len(v['body']) for v in IMAGE_PROXY_CACHE.values())
            while total_bytes > IMAGE_PROXY_CACHE_BYTES or len(IMAGE_PROXY_CACHE) > 96:
                _key, victim = IMAGE_PROXY_CACHE.popitem(last=False)
                total_bytes -= len(victim['body'])
    return body, content_type


@app.get('/api/image-proxy')
async def api_image_proxy(url: str, profile: str = 'balanced'):
    remote_url = unquote((url or '').strip())
    if not remote_url:
        raise HTTPException(status_code=400, detail='Falta la URL de imagen')
    body, content_type = await asyncio.to_thread(_fetch_image_proxy_payload, remote_url, profile)
    return Response(content=body, media_type=content_type, headers={'Cache-Control': 'public, max-age=900'})


@app.get('/api/articles')
async def api_articles(limit: int = 50, page: int = 1, status: str = 'all', sector: str = 'general'):
    current_page, page_size = _page_args(limit, page)
    cache_key = (page_size, current_page, status, sector)
    cached = _cache_get(ARTICLES_API_CACHE, cache_key)
    if cached is not None:
        return cached
    payload = await asyncio.to_thread(build_article_page_payload, status, 'general', current_page, page_size)
    return _cache_set(ARTICLES_API_CACHE, cache_key, payload)


@app.get('/api/articles/{article_id}')
async def api_article(article_id: int):
    article = get_article(article_id)
    if not article:
        raise HTTPException(status_code=404, detail='Noticia no encontrada')
    return article


@app.post('/api/feeds')
async def api_create_feed(payload: FeedCreate):
    feed = await run_db_write(add_feed, payload.name, str(payload.url))
    _invalidate_response_caches()
    await refresh_all_feeds()
    return feed


@app.patch('/api/feeds/{feed_id}')
async def api_toggle_feed(feed_id: int, payload: FeedToggle):
    feed = await run_db_write(toggle_feed, feed_id, payload.is_enabled)
    _invalidate_response_caches()
    if not feed:
        raise HTTPException(status_code=404, detail='Feed no encontrado')
    return feed


@app.delete('/api/feeds/{feed_id}')
async def api_delete_feed(feed_id: int):
    await run_db_write(delete_feed, feed_id)
    _invalidate_response_caches()
    return {'ok': True}


@app.patch('/api/settings')
async def api_update_settings(payload: SettingsUpdate, request: Request):
    changes = payload.model_dump(exclude_none=True)
    updated = await run_db_write(update_settings, changes)
    _invalidate_response_caches()
    jobs = get_job_state(request.app)
    heavy_keys = {'prompt', 'date_window', 'relevance_mode', 'hide_duplicates', 'semantic_reranking', 'feedback_learning'}
    if heavy_keys & changes.keys():
        jobs = schedule_rescore(request.app, updated['prompt'], updated['date_window'], updated['relevance_mode'])
    return {'settings': updated, 'jobs': jobs}


@app.post('/api/refresh')
async def api_refresh():
    return await refresh_all_feeds()


@app.patch('/api/articles/{article_id}/status')
async def api_article_status(article_id: int, payload: ArticleStatusUpdate, request: Request):
    article = await run_db_write(update_article_status, article_id, payload.status)
    _invalidate_response_caches()
    if not article:
        raise HTTPException(status_code=404, detail='Noticia no encontrada')
    settings = get_settings()
    jobs = schedule_rescore(request.app, settings['prompt'], settings['date_window'], settings['relevance_mode'])
    return {'article': get_article(article_id), 'jobs': jobs}


@app.get('/export/docx')
async def export_docx(status: str = 'included'):
    articles = list_articles(limit=500, status=status)
    if not articles:
        raise HTTPException(status_code=400, detail='No hay noticias para exportar con ese estado.')
    path = await asyncio.to_thread(export_articles_to_docx, articles)
    return FileResponse(path, filename=path.name, media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')




@app.get('/api/incidents-map')
async def api_incidents_map(sector: str = 'general', status: str = 'all', year: str | None = None):
    return await asyncio.to_thread(build_public_map_payload, 'general', status, year)
@app.get('/export/incidents-map.pdf')
async def export_incidents_map_pdf(sector: str = 'general', status: str = 'all', year: str | None = None):
    sector_key = 'general'
    map_data = await asyncio.to_thread(build_map_payload, sector_key, status, year)
    if not map_data['totals']['incidents']:
        label = 'General'
        raise HTTPException(status_code=400, detail=f'No hay noticias de {label} para generar el mapa PDF en ese año.')
    safe_sector = 'general'
    output = BASE_DIR.parent / 'data' / f"cyberrad_{safe_sector}_map_{map_data['year']}.pdf"
    path = await asyncio.to_thread(export_incident_map_pdf, str(output), map_data)
    return FileResponse(path, filename=Path(path).name, media_type='application/pdf')


@app.get('/api/incidents-map/country')
async def api_incidents_country(sector: str = 'general', status: str = 'all', year: str | None = None, country: str = '', page: int = 1, page_size: int = 20):
    return await asyncio.to_thread(build_country_payload, 'general', status, year, country, page, page_size)
