# CyberRad AWWG — Ajuste real para VM 4 vCPU / 10 GB (v5.1.16 + Weekly)

Se parte del código del CyberRad v5.1.16 proporcionado por el usuario y de la integración de informes AWWG. **No es el producto comercial genérico.** El apartado Marcas se ha retirado de la UI, pero sus noticias y fuentes siguen entrando en General.

Esta versión incluye optimizaciones del backend, caché, SQLite, RSS, Docker y exportación simultánea controlada. No añade límites a las noticias ni desactiva fuentes para ahorrar recursos. En Settings permanecen los perfiles, frecuencia, rango de fechas y `max_articles_per_feed` que ya ofrecía CyberRad; si se quieren todas las entradas publicadas por una fuente, ajustar ese parámetro, teniendo en cuenta las limitaciones que pueda imponer cada proveedor RSS.

Ver **VM_4VCPU_10GB_DEPLOY_ES.md** antes de desplegar. No está autorizada para exposición pública sin autenticación corporativa, TLS, revisión SSRF del proxy y pruebas de carga propias.


## Kali con Sauron en la misma VM

Utilizar `INSTALACION_KALI_SAURON_SISTEMA.md` y `instalar_kali_sistema.sh`. Codigo en `/opt/cyberrad-awwg`, datos en `/var/lib/cyberrad-awwg`, configuracion en `/etc/cyberrad-awwg`. El usuario de servicio `cyberrad` no tiene shell. No ejecutar despliegue con la configuración antigua en `~/...`.
