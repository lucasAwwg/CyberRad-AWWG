"""AWWG weekly research pipeline. Does not alter CyberRad's existing tables."""
from __future__ import annotations
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from email.utils import parsedate_to_datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
from threading import RLock
from functools import lru_cache
from collections import OrderedDict
import time
from typing import Any
from urllib.parse import quote, urlparse
import requests
from defusedxml import ElementTree as ET

BASE = Path(os.environ.get('CYBERRAD_AWWG_DATA', str(Path.home() / '.cyberrad_awwg'))).expanduser()
DB = BASE / 'weekly.sqlite3'
SETTINGS = BASE / 'settings.json'
REPORTS = BASE / 'reports'
LOCK = RLock()
INITIALIZE_LOCK = RLock()
_INITIALIZED_DB = None
_FETCH_CACHE = OrderedDict()
_FETCH_CACHE_LOCK = RLock()
_FETCH_TTL_SECONDS = 600
_FETCH_CACHE_MAX = 24
CISA_JSON = 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json'
NEWS_FEEDS = (
    ('BleepingComputer', 'https://www.bleepingcomputer.com/feed/'),
    ('The Hacker News', 'https://thehackernews.com/feeds/posts/default'),
)
WATCH_DEFAULT = [
    'WordPress', 'WooCommerce', 'Magento', 'Adobe Commerce', 'PrestaShop',
    'Apache', 'nginx', 'PHP', 'Python', 'Node.js', 'Linux', 'Ubuntu',
    'Synology', 'QNAP', 'TeamViewer', 'AnyDesk', 'Fortinet', 'Citrix',
    'NetScaler', 'Docker', 'Kubernetes', 'Microsoft', 'Windows Server',
    'Dell', 'Broadcom', 'VPN', 'e-commerce', 'retail', 'wholesale',
    'fashion', 'apparel', 'supplier', 'data breach', 'ransomware',
    # Endpoint protection, disk encryption, corporate MFA, RMM and observability.
    'CrowdStrike', 'CrowdStrike Falcon', 'Falcon Sensor',
    'BitLocker', 'Windows', 'Microsoft Windows',
    'Cisco Duo', 'Duo Security', 'Duo MFA',
    'NinjaOne', 'NinjaRMM', 'Grafana', 'Grafana Loki',
]
CATEGORIES = {
 'Web servers': ['Apache', 'nginx', 'IIS'],
 'CMS and e-commerce': ['WordPress', 'WooCommerce', 'Magento', 'Adobe Commerce', 'PrestaShop'],
 'Languages and runtimes': ['PHP', 'Python', 'Node.js'],
 'Operating systems': ['Linux kernel', 'Ubuntu', 'Windows Server', 'Windows', 'BitLocker'],
 'NAS and remote access': ['Synology', 'QNAP', 'TeamViewer', 'AnyDesk'],
 'Network and identity': ['Fortinet', 'Citrix', 'NetScaler', 'VPN', 'SAML', 'Cisco Duo', 'Duo Security', 'Duo MFA'],
 'Endpoint security and RMM': ['CrowdStrike', 'CrowdStrike Falcon', 'Falcon Sensor', 'NinjaOne', 'NinjaRMM'],
 'Monitoring and observability': ['Grafana', 'Grafana Loki'],
 'Cloud and supply chain': ['Docker', 'Kubernetes', 'MSP', 'supplier', 'data breach'],
 'Retail and wholesale': ['retail', 'wholesale', 'e-commerce', 'ransomware'],
}
NEW_WATCH_V62 = (
 'CrowdStrike', 'CrowdStrike Falcon', 'Falcon Sensor',
 'BitLocker', 'Windows', 'Microsoft Windows',
 'Cisco Duo', 'Duo Security', 'Duo MFA',
 'NinjaOne', 'NinjaRMM', 'Grafana', 'Grafana Loki',
)
NEW_CATEGORIES_V62 = ('Endpoint security and RMM', 'Monitoring and observability')
TERMS = re.compile(r'\b(cve-\d{4}-\d{4,}|vulnerabilit(?:y|ies)|exploit(?:ed|ation|s)?|zero.day|breach|ransomware|cyberattacks?|security (?:update|flaw|bug|patch|advisory)|remote code execution|unauthori[sz]ed access|credential theft|malware|patch(?:ed|ing)?)\b',re.I)
CVES = re.compile(r'CVE-\d{4}-\d{4,}', re.I)
NEGATIVE = re.compile(r'\b(movie|fitness routine|video game review|fashion week|sports results)\b', re.I)

DEFAULT = {
 'watch_schema_version': 2,
 'company': 'AWWG',
 'report_title': 'Cyber News Weekly Report',
 'language': 'en',
 'sector': 'Wholesale / Retail / Fashion / E-commerce',
 'watch_terms': WATCH_DEFAULT,
 'enabled_categories': list(CATEGORIES),
 'max_news': 12,
 'min_business_priority': 'LOW',
 'auto_include_cisa_kev': True,
 'always_show_sector_trends': True,
 'include_only_verified': True,
 'notes': 'Internal AWWG weekly cybersecurity review. No confirmed exposure without internal evidence.',
}
PRIORITY = ('CRITICAL', 'HIGH', 'MID', 'LOW')


def initialize() -> None:
 global _INITIALIZED_DB
 if _INITIALIZED_DB == str(DB) and DB.exists() and SETTINGS.exists(): return
 with INITIALIZE_LOCK:
  if _INITIALIZED_DB == str(DB) and DB.exists() and SETTINGS.exists(): return
  _initialize_once()
  _INITIALIZED_DB = str(DB)

def _initialize_once() -> None:
 BASE.mkdir(parents=True, exist_ok=True)
 REPORTS.mkdir(parents=True, exist_ok=True)
 if not SETTINGS.exists():
  SETTINGS.write_text(json.dumps(DEFAULT, ensure_ascii=False, indent=2), encoding='utf-8')
 with connect() as con:
  con.execute('PRAGMA journal_mode=WAL')
  con.execute('''CREATE TABLE IF NOT EXISTS news (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, summary TEXT NOT NULL,
    source TEXT NOT NULL, source_url TEXT NOT NULL, published TEXT NOT NULL,
    discovered TEXT NOT NULL, category TEXT NOT NULL,
    cves TEXT NOT NULL, vendor_severity TEXT NOT NULL,
    priority TEXT NOT NULL, status TEXT NOT NULL, provenance TEXT NOT NULL,
    company_impact TEXT NOT NULL, action TEXT NOT NULL,
    affected TEXT NOT NULL, fixed TEXT NOT NULL, cvss TEXT NOT NULL,
    verified_exploitation TEXT NOT NULL, original_title TEXT NOT NULL,
    published_at TEXT NOT NULL DEFAULT ''
  )''')
  if 'published_at' not in {row[1] for row in con.execute('PRAGMA table_info(news)')}:
   con.execute("ALTER TABLE news ADD COLUMN published_at TEXT NOT NULL DEFAULT ''")
  con.execute('''CREATE TABLE IF NOT EXISTS audit (
    at TEXT NOT NULL, item_id TEXT NOT NULL, event TEXT NOT NULL, detail TEXT NOT NULL
  )''')
  con.execute('CREATE INDEX IF NOT EXISTS news_date_idx ON news(published)')
  con.execute('CREATE INDEX IF NOT EXISTS news_week_status_idx ON news(published,status,priority)')


@contextmanager
def connect():
 DB.parent.mkdir(parents=True, exist_ok=True)
 con=sqlite3.connect(DB, timeout=15)
 try:
  con.row_factory=sqlite3.Row
  con.execute('PRAGMA busy_timeout=10000')
  yield con
  con.commit()
 except Exception:
  con.rollback()
  raise
 finally:
  con.close()


def get_settings() -> dict:
 initialize()
 try:
  saved = json.loads(SETTINGS.read_text(encoding='utf-8'))
  # Add new corporate scope to pre-existing v6.1 installations, without dropping
  # analyst-defined terms, historical news, or prior category selections.
  if saved.get('watch_schema_version', 1) < 2:
   before_terms = saved.get('watch_terms', WATCH_DEFAULT)
   if not isinstance(before_terms, list): before_terms = WATCH_DEFAULT
   new_terms = [x for x in WATCH_DEFAULT if x in NEW_WATCH_V62]
   saved['watch_terms'] = list(dict.fromkeys([*before_terms, *new_terms]))
   before_cats = saved.get('enabled_categories', list(CATEGORIES))
   if not isinstance(before_cats, list): before_cats = list(CATEGORIES)
   saved['enabled_categories'] = list(dict.fromkeys([*before_cats, *NEW_CATEGORIES_V62]))
   saved['watch_schema_version'] = 2
   with LOCK:
    # Preserve the exact existing custom settings; only extend the new watch scope.
    tmp = SETTINGS.with_suffix('.migrate.tmp')
    tmp.write_text(json.dumps(saved,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(SETTINGS)
  return {**DEFAULT, **saved}
 except (OSError, ValueError):
  return DEFAULT.copy()


def save_settings(changes: dict) -> dict:
 allowed = {'watch_terms','enabled_categories','max_news','min_business_priority','auto_include_cisa_kev','always_show_sector_trends','include_only_verified','notes'}
 if any(k not in allowed for k in changes):
  raise ValueError('Settings can only change AWWG intelligence parameters, not the company identity or report branding.')
 cfg = get_settings()
 for k,v in changes.items():
  if k in ('watch_terms','enabled_categories'):
   if not isinstance(v,list) or len(v)>100 or any(not isinstance(s,str) or len(s)>90 for s in v): raise ValueError('Invalid list')
   if k == 'enabled_categories' and any(s not in CATEGORIES for s in v): raise ValueError('Unknown category')
   v = list(dict.fromkeys(s.strip() for s in v if s.strip()))
  if k == 'max_news':
   if type(v) is not int or not (1<=v<=30): raise ValueError('max_news must be from 1 to 30')
  if k == 'min_business_priority' and v not in PRIORITY: raise ValueError('Invalid priority')
  if k in ('auto_include_cisa_kev','always_show_sector_trends','include_only_verified') and type(v) is not bool: raise ValueError('Invalid toggle')
  if k=='notes' and (not isinstance(v,str) or len(v)>1000): raise ValueError('Invalid notes')
  cfg[k]=v
 with LOCK:
  temp=SETTINGS.with_suffix('.tmp')
  temp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
  temp.replace(SETTINGS)
 return cfg


def date_range(week_start: str | None = None) -> tuple[date,date]:
 """Moving seven-day period (calendar date bounds) in Europe/Madrid.

 Includes the boundary dates touched by the last 168 hours. For RSS/Atom,
 an exact 168-hour filter is applied when timestamps are available.
 Date-only advisories (such as CISA KEV) are necessarily day-granular.
 """
 today = datetime.now(ZoneInfo('Europe/Madrid')).date()
 if week_start:
  start = date.fromisoformat(week_start)
  if start > today:
   raise ValueError('The report period cannot start in the future')
 else:
  start = today - timedelta(days=7)
 return start, start + timedelta(days=7)


@lru_cache(maxsize=24)
def _compiled_watch(terms:tuple[str,...]):
 if not terms:return re.compile(r'(?!)')
 return re.compile(r'(?<!\w)(?:' + '|'.join(re.escape(t) for t in terms) + r')(?!\w)',re.I)

def matches_watch(text: str, settings: dict)->bool:
 return bool(_compiled_watch(tuple(settings['watch_terms'])).search(text))


def classify(text: str)->str:
 for k,terms in CATEGORIES.items():
  if any(re.search(re.escape(t),text,re.I) for t in terms): return k
 return 'Other cybersecurity'


def news_id(title: str, cves: list[str]) -> str:
 # A CVE remains one story across multiple syndicated articles; otherwise use a normalized title.
 key=','.join(sorted(cves)) if cves else re.sub(r'[^a-z0-9]+',' ', title.lower()).strip()
 return hashlib.sha256(key.encode()).hexdigest()[:24]


def fetch(url: str)->requests.Response:
 # Cache identical feed requests for 10 minutes; no reduction in fetched items.
 now=time.monotonic()
 with _FETCH_CACHE_LOCK:
  stored=_FETCH_CACHE.get(url)
  if stored and now-stored[0]<_FETCH_TTL_SECONDS:
   _FETCH_CACHE.move_to_end(url)
   return stored[1]
 response=requests.get(url,timeout=(5,12),headers={'User-Agent':'CyberRad-AWWG-Weekly/0.2 security intelligence'})
 response.raise_for_status()
 if len(response.content)>8_000_000:raise ValueError('Source too large')
 with _FETCH_CACHE_LOCK:
  _FETCH_CACHE[url]=(time.monotonic(),response)
  _FETCH_CACHE.move_to_end(url)
  while len(_FETCH_CACHE)>_FETCH_CACHE_MAX:_FETCH_CACHE.popitem(last=False)
 return response


def ingest_kev(start:date,end:date,cfg:dict)->list[dict]:
 data=fetch(CISA_JSON).json()
 rows=[]
 for v in data.get('vulnerabilities',[]):
  when=v.get('dateAdded','')
  if not (start.isoformat()<=when<=end.isoformat()): continue
  vendor = re.sub(r'\s+', ' ', str(v.get('vendorProject') or '')).strip()
  product = re.sub(r'\s+', ' ', str(v.get('product') or '')).strip()
  issue = re.sub(r'\s+', ' ', str(v.get('vulnerabilityName') or '')).strip()
  original_title = f"{vendor} {product} — {issue}".strip()
  # 'PHP Group PHP — PHP ... Vulnerability' -> 'PHP — ...'; original kept below.
  short_issue = re.sub(r'\s+Vulnerability$', '', issue, flags=re.I).strip()
  short_issue = re.sub(r'^' + re.escape(product) + r'\s+', '', short_issue, flags=re.I) if product else short_issue
  display_product = product or vendor or 'Unspecified product'
  title = f"{display_product} — {short_issue or issue}"[:180]
  body=f"{original_title} {v.get('shortDescription','')} {v.get('requiredAction','')}"
  if not matches_watch(body,cfg): continue
  cve=v.get('cveID','').upper(); cves=[cve] if CVES.fullmatch(cve) else []
  # The KEV requiredAction can contain long federal-policy boilerplate.
  # Keep the verifiable exploitation fact and an actionable AWWG-specific recommendation;
  # do not claim patch availability, affected versions, or internal compromise.
  product = re.sub(r'\s+', ' ', v.get('product') or v.get('vendorProject') or 'this product').strip()[:65]
  action = (f'Check whether {product} is deployed. Review the vendor advisory for '
            'affected versions and available fixes or mitigations; prioritize exposed '
            'systems and investigate exploitation indicators.')
  rows.append(dict(id=news_id(title,cves),title=title[:220],summary=(v.get('shortDescription') or '')[:1800],source='CISA KEV',
      source_url=f'https://www.cisa.gov/known-exploited-vulnerabilities-catalog?field_cve={quote(cve)}', published=when,published_at='',
      category=(classify(display_product) if classify(display_product)!='Other cybersecurity' else classify(body)),cves=json.dumps(cves),vendor_severity='Not supplied by KEV',
      priority='HIGH',status='included' if cfg['auto_include_cisa_kev'] else 'pending',provenance='official_cisa_kev',
      company_impact='CHECK IF IT APPLIES — AWWG exposure has not been verified.',action=str(action)[:550],
      affected='Not verified — consult vendor bulletin',fixed='Not verified — consult vendor bulletin',cvss='Not supplied by CISA KEV',
      verified_exploitation='YES — listed in CISA KEV',original_title=original_title))
 return rows


def text_of(elem:Any,tag:str)->str:
 node=elem.find(tag)
 return ''.join(node.itertext()).strip() if node is not None else ''


def date_parsed(s: str)->str | None:
 if not s: return None
 try: return parsedate_to_datetime(s).date().isoformat()
 except (TypeError,ValueError):
  try: return datetime.fromisoformat(s.replace('Z','+00:00')).date().isoformat()
  except (TypeError,ValueError): return None


def published_timestamp(value:str):
 """Convert provider timestamps into UTC; return None for undated entries."""
 if not value:return None
 try:
  dt=parsedate_to_datetime(value)
 except (TypeError,ValueError):
  try:dt=datetime.fromisoformat(value.replace('Z','+00:00'))
  except (TypeError,ValueError):return None
 if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
 return dt.astimezone(timezone.utc)


def rolling_cutoff(start:date,end:date):
 now=datetime.now(ZoneInfo('Europe/Madrid'))
 if start==now.date()-timedelta(days=7) and end==now.date():
  return (now-timedelta(days=7)).astimezone(timezone.utc),now.astimezone(timezone.utc)
 return None


def parse_rss(xml:bytes,source:str,start:date,end:date,cfg:dict)->list[dict]:
 root=ET.fromstring(xml)
 items=root.findall('.//item')
 if not items: items=root.findall('.//{http://www.w3.org/2005/Atom}entry')
 results=[]
 for item in items:
  is_atom=item.tag.endswith('entry')
  title=text_of(item,'{http://www.w3.org/2005/Atom}title') if is_atom else text_of(item,'title')
  summary=text_of(item,'{http://www.w3.org/2005/Atom}summary') if is_atom else text_of(item,'description')
  rawdate=text_of(item,'{http://www.w3.org/2005/Atom}published') if is_atom else text_of(item,'pubDate')
  pub_dt=published_timestamp(rawdate)
  day=pub_dt.astimezone(ZoneInfo('Europe/Madrid')).date().isoformat() if pub_dt else date_parsed(rawdate)
  if not day or not start.isoformat()<=day<=end.isoformat(): continue
  bounds=rolling_cutoff(start,end)
  if pub_dt and bounds and not(bounds[0]<=pub_dt<=bounds[1]):continue
  content=(title+' '+re.sub('<[^>]+>',' ',summary)).strip()
  if not title or not TERMS.search(content) or NEGATIVE.search(title) or not matches_watch(content,cfg):continue
  link=text_of(item,'link')
  if is_atom:
   el=item.find('{http://www.w3.org/2005/Atom}link')
   link=el.attrib.get('href','') if el is not None else ''
  if urlparse(link).scheme not in ('https','http'): continue
  cves=list(dict.fromkeys(x.upper() for x in CVES.findall(content)))
  summary=re.sub(r'<[^>]+>',' ',summary)
  summary=re.sub(r'\s+',' ',summary).strip()[:1200]
  results.append(dict(id=news_id(title,cves),title=title[:220],summary=summary,source=source,source_url=link,
    published=day,published_at=pub_dt.isoformat() if pub_dt else '',category=classify(content),cves=json.dumps(cves),vendor_severity='Needs vendor verification',
    priority='LOW',status='pending',provenance='press_unverified',
    company_impact='UNASSESSED — do not claim AWWG impact without evidence.',
    action='Check original advisory, affected versions, exploitation evidence and AWWG applicability before approval.',
    affected='Not verified',fixed='Not verified',cvss='Not verified',verified_exploitation='Not verified',original_title=title))
 return results


def ingest_google(start:date,end:date,cfg:dict,category:str)->list[dict]:
 terms=CATEGORIES[category]
 # Do not send company inventory, supplier relationships, or internal names to search providers.
 q='('+' OR '.join('"'+t+'"' for t in terms)+') (CVE OR vulnerability OR data breach OR ransomware OR security patch)'
 q+=f' after:{start.isoformat()} before:{(end+timedelta(days=1)).isoformat()}'
 url='https://news.google.com/rss/search?q='+quote(q)+'&hl=en-US&gl=US&ceid=US:en'
 return parse_rss(fetch(url).content,'Google News discovery',start,end,cfg)


def _save_items(items:list[dict])->int:
 now=datetime.now(timezone.utc).isoformat()
 count=0
 # The official CISA entry wins over syndicated reporting when both reference the same CVE.
 items=sorted(items,key=lambda row:row.get('provenance')=='official_cisa_kev',reverse=True)
 with LOCK,connect() as con:
  for r in items:
   r['discovered']=now
   existing=con.execute('SELECT provenance,status,published_at FROM news WHERE id=?',(r['id'],)).fetchone()
   if existing and existing['provenance']=='official_cisa_kev' and r['provenance']=='official_cisa_kev':
    # Refresh previously auto-generated titles/actions (fixes reports made by older code).
    # Respect analyst-edited fields recorded in the immutable audit log.
    protected=set()
    for audit_row in con.execute('SELECT detail FROM audit WHERE item_id=? AND event=?',(r['id'],'edit')):
     try:protected.update(json.loads(audit_row['detail']).keys())
     except (ValueError,TypeError,AttributeError):pass
    changes={key:r[key] for key in ('title','original_title','category','action') if key not in protected}
    if changes:
     con.execute('UPDATE news SET '+', '.join(key+'=?' for key in changes)+' WHERE id=?',
                 [*changes.values(),r['id']])
    continue
   if existing and not existing['published_at'] and r.get('published_at'):
    con.execute('UPDATE news SET published_at=? WHERE id=?',(r['published_at'],r['id']))
   if existing and existing['status']=='pending' and existing['provenance']=='press_unverified' and r['provenance']=='official_cisa_kev':
    # Upgrade unreviewed coverage to authoritative evidence, never overwrite an analyst decision.
    keys=[key for key in r if key not in ('id','discovered')]
    con.execute('UPDATE news SET '+', '.join(k+'=?' for k in keys)+' WHERE id=?',
                [*[r[k] for k in keys],r['id']])
    continue
   # Existing editorial decisions and details must not be reset by repeated imports.
   cols=list(r)
   con.execute('INSERT OR IGNORE INTO news ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',[r[c] for c in cols])
   count+=con.execute('SELECT changes()').fetchone()[0]
 return count


def research(start:date,end:date)->dict:
 initialize();cfg=get_settings()
 jobs=[('cisa',None),('rss',NEWS_FEEDS[0]),('rss',NEWS_FEEDS[1])]
 jobs.extend(('google',c) for c in cfg['enabled_categories'])
 gathered=[];errors=[]
 def run(job):
  typ,arg=job
  if typ=='cisa':return ingest_kev(start,end,cfg)
  if typ=='rss':return parse_rss(fetch(arg[1]).content,arg[0],start,end,cfg)
  return ingest_google(start,end,cfg,arg)
 with ThreadPoolExecutor(max_workers=4) as pool:
  futures={pool.submit(run,job):job for job in jobs}
  for f in as_completed(futures):
   try:gathered.extend(f.result())
   except Exception as ex: errors.append(f'{futures[f][0]} / {futures[f][1]}: {str(ex)[:180]}')
 return {'new_items':_save_items(gathered),'candidate_items':len(gathered),'source_errors':errors,'week_start':start.isoformat(),'week_end':end.isoformat()}


def list_items(start:date,end:date,all_statuses:bool=True)->list[dict]:
 initialize()
 with connect() as con:
  rows=con.execute('SELECT * FROM news WHERE published BETWEEN ? AND ? ORDER BY published DESC, priority ASC',(start.isoformat(),end.isoformat())).fetchall()
 bounds=rolling_cutoff(start,end)
 def valid(row):
  if not (all_statuses or row['status']=='included'):return False
  if bounds and row['published_at']:
   try:
    when=datetime.fromisoformat(row['published_at'])
    if when.tzinfo is not None and not(bounds[0]<=when<=bounds[1]):return False
   except ValueError:pass
  return True
 return [dict(x)|{'cves':json.loads(x['cves'])} for x in rows if valid(x)]


def update_item(item_id:str, changes:dict)->dict:
 allowed={'status','priority','company_impact','action','affected','fixed','cvss','verified_exploitation','vendor_severity','summary','category'}
 if any(k not in allowed for k in changes) or not changes: raise ValueError('Invalid editable field')
 for k,v in changes.items():
  if not isinstance(v,str) or len(v)>1800: raise ValueError('Invalid field content')
  if k=='status' and v not in ('included','pending','excluded'): raise ValueError('Invalid status')
  if k=='priority' and v not in PRIORITY: raise ValueError('Invalid priority')
 with LOCK,connect() as con:
  found=con.execute('SELECT * FROM news WHERE id=?',(item_id,)).fetchone()
  if not found: raise KeyError(item_id)
  query='UPDATE news SET '+', '.join(k+'=?' for k in changes)+' WHERE id=?'
  con.execute(query,[*changes.values(),item_id])
  con.execute('INSERT INTO audit(at,item_id,event,detail) VALUES(?,?,?,?)',
   (datetime.now(timezone.utc).isoformat(),item_id,'edit',json.dumps(changes,ensure_ascii=False)))
  return dict(con.execute('SELECT * FROM news WHERE id=?',(item_id,)).fetchone())


def counts(items:list[dict])->dict:
 return {x:sum(1 for item in items if item['priority']==x) for x in PRIORITY}


def trend_for(start:date)->dict|None:
 initialize()
 with connect() as con:
  con.execute('''CREATE TABLE IF NOT EXISTS sector_trends (week_start TEXT PRIMARY KEY, data TEXT NOT NULL)''')
  row=con.execute('SELECT data FROM sector_trends WHERE week_start=?',(start.isoformat(),)).fetchone()
  return json.loads(row['data']) if row else None


def set_trend(start:date, data:dict)->dict:
 allowed={'attacks','previous_attacks','rank','previous_rank','global_attacks','previous_global_attacks','data_tb','previous_data_tb','source'}
 if any(k not in allowed for k in data): raise ValueError('Unknown trend metric')
 if any(len(str(v))>250 for v in data.values()):raise ValueError('Invalid trend value')
 if 'source' not in data or not str(data['source']).startswith('https://'):
  raise ValueError('A verifiable https source is required for sector data')
 with LOCK,connect() as con:
  con.execute('CREATE TABLE IF NOT EXISTS sector_trends (week_start TEXT PRIMARY KEY, data TEXT NOT NULL)')
  con.execute('INSERT OR REPLACE INTO sector_trends VALUES(?,?)',(start.isoformat(),json.dumps(data)))
 return data
