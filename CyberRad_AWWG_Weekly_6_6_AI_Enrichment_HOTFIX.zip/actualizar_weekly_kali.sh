#!/usr/bin/env bash
# CyberRad AWWG Weekly v6.6: atomic-enough module update with rollback.
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
ENV_FILE=/etc/cyberrad-awwg/cyberrad.env
FILES=(engine.py router.py pptx_report.py weekly.html enrichment.py)
for file in "${FILES[@]}"; do
 if [[ ! -f "$SOURCE/$file" ]]; then echo "Falta $file en origen. Sin cambios." >&2; exit 2; fi
done
for file in engine.py router.py pptx_report.py weekly.html; do
 if [[ ! -f "$TARGET/weekly_awwg/$file" ]]; then echo "Falta $file en instalación. Sin cambios." >&2; exit 2; fi
done
for path in "$TARGET/docker-compose.kali.yml" "$ENV_FILE"; do
 if [[ ! -f "$path" ]]; then echo "Archivo ausente: $path. Sin cambios." >&2; exit 2; fi
done
if ! docker inspect cyberrad-awwg >/dev/null 2>&1; then echo 'Contenedor CyberRad no encontrado.' >&2; exit 3; fi
if ! docker compose version >/dev/null 2>&1; then echo 'Se necesita docker compose v2.' >&2; exit 4; fi
PYTHONDONTWRITEBYTECODE=1 python3 - "$SOURCE" <<'PYCODE'
import pathlib,sys
base=pathlib.Path(sys.argv[1])
for fn in ('engine.py','router.py','pptx_report.py','enrichment.py'):
 compile((base/fn).read_text(encoding='utf-8'),str(base/fn),'exec')
assert 'enrichment.enrich_selected' in (base/'router.py').read_text()
assert 'WHAT HAPPENED' in (base/'pptx_report.py').read_text()
assert 'report-mode' in (base/'weekly.html').read_text()
print('Sintaxis y archivos v6.6 validados.')
PYCODE
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" config -q
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.6-${STAMP}.tar.gz"
EXISTING=(weekly_awwg/engine.py weekly_awwg/router.py weekly_awwg/pptx_report.py weekly_awwg/weekly.html)
WAS_NEW=0
if [[ -f "$TARGET/weekly_awwg/enrichment.py" ]]; then
 EXISTING+=(weekly_awwg/enrichment.py)
else
 WAS_NEW=1
fi
tar -C "$TARGET" -czf "$BACKUP" "${EXISTING[@]}"
rollback() {
 echo 'ERROR: restaurando módulo semanal anterior...' >&2
 if (( WAS_NEW == 1 )); then rm -f -- "$TARGET/weekly_awwg/enrichment.py"; fi
 tar -C "$TARGET" -xzf "$BACKUP" || true
 docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" up -d --build --no-deps cyberrad || true
 echo "Copia de seguridad conservada: $BACKUP" >&2
}
trap rollback ERR
for file in "${FILES[@]}"; do
 install -m 644 -- "$SOURCE/$file" "$TARGET/weekly_awwg/$file"
done
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" up -d --build --no-deps cyberrad
if [[ "$(docker inspect -f '{{.State.Running}}' cyberrad-awwg)" != true ]]; then
 echo 'El contenedor no está ejecutándose.' >&2; false
fi
# Tests the real container can import the new enrichment module.
docker exec cyberrad-awwg python3 -c 'from weekly_awwg import enrichment; print("Enrichment v6.6 cargado correctamente")'
trap - ERR
printf 'CyberRad Weekly 6.6 instalado. Backup: %s\n' "$BACKUP"
echo 'BD, historiales, settings.json, secretos, Sauron y otros contenedores intactos.'
echo 'Para conectar IA opcional: sudo python3 configurar_ia_weekly.py (desde carpeta del ZIP).'
