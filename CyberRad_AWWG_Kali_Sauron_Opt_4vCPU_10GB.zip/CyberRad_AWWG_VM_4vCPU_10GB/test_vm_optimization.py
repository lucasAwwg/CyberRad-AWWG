"""Offline regression and sample workload for 4 vCPU / 10 GiB VM build."""
from __future__ import annotations
import os, tempfile, time, json, asyncio
from pathlib import Path
from unittest.mock import patch

os.environ['CYBERRAD_AWWG_DATA'] = tempfile.mkdtemp(prefix='awwg_weekly_test_')
from app import db, main, rss
from weekly_awwg import engine

orig_path = db.DB_PATH
with tempfile.TemporaryDirectory(prefix='cyberrad_staging_') as td:
    db.DB_PATH = Path(td) / 'test.db'
    db._invalidate_runtime_caches()
    db.init_db()
    feed = db.add_feed('Sample vendor', 'https://example.org/feed.xml')
    sample_feed_id = feed['id']
    start=time.perf_counter()
    print('initializing 8105...',flush=True)
    test_rows = [{
        'unique_key': f'perf-test-{i}', 'feed_id': sample_feed_id, 'feed_name':'Sample vendor',
        'feed_url':'https://example.org/feed.xml',
        'title':f'CVE-2026-{100000+i} security update for platform {i}',
        'article_url':f'https://example.org/article/{i}',
        'summary':'Test release on a web service', 'content':'Vendor security notice',
        'published_at':'2026-10-29T10:00:00+00:00',
        'image_url':None, 'video_url':None,
        'status':'included' if i%4 else 'pending',
        'status_origin':'auto', 'relevance_score':12,
        'cluster_key':f'key-{i}',
    } for i in range(8105)]
    inserted=db.upsert_articles(test_rows)
    assert inserted==8105, inserted
    insert_s=time.perf_counter()-start
    print('insert',insert_s,flush=True)
    start=time.perf_counter()
    inserted_again=db.upsert_articles(test_rows)
    repeat_s=time.perf_counter()-start
    print('repeat',repeat_s,flush=True)
    assert inserted_again==0
    assert db.stats()['total_articles']==8105
    main._invalidate_response_caches()
    start=time.perf_counter()
    pg1=main.build_article_page_payload(page=1,page_size=50)
    first_page_s=time.perf_counter()-start
    print('firstpage',first_page_s,flush=True)
    start=time.perf_counter()
    pg2=main.build_article_page_payload(page=2,page_size=50)
    next_page_s=time.perf_counter()-start
    assert pg1['scanned']==8105, pg1
    assert pg1['total_visible']>=0
    assert pg1['page']==1 and pg2['page']==2
    assert len(main.ARTICLE_VIEW_CACHE)==1, list(main.ARTICLE_VIEW_CACHE)
    assert len(main.ARTICLE_UNIVERSE_CACHE)==1
    assert all(item['id'] not in {x['id'] for x in pg1['articles']} for item in pg2['articles'])
    # Standard report classifications are not lost even if old feed doesn't provide media.
    a = db.get_article(1)
    assert a is not None
    print(json.dumps({'sample_articles':8105, 'new_records':inserted,
        'second_inserted':inserted_again, 'insert_seconds':round(insert_s,3),
        'repeat_seconds':round(repeat_s,3),
        'first_page_seconds':round(first_page_s,3),
        'next_page_seconds':round(next_page_s,3),
        'available_in_general':pg1['total_visible'],
        'cached_views':len(main.ARTICLE_VIEW_CACHE)},indent=2))
    # Conditional RSS request skipping unchanged feeds does not touch stored articles.
    from requests import Response
    class StubSession:
        def __init__(self): self.seen=[]
        def get(self,url,**kwargs):
            self.seen.append(kwargs.get('headers',{}))
            r=Response();r.status_code=304;r.url=url;r._content=b''
            return r
    fake=StubSession()
    with patch.object(rss,'_http_session',return_value=fake):
        assert rss.parse_feed({'url':'https://example.org/feed'},'',20)==[]
    assert db.stats()['total_articles']==8105
    # Ensure screen uses correct corporate terms.
    for x in ('CrowdStrike Falcon','Windows','BitLocker','Cisco Duo','NinjaOne','Grafana'):
        assert x in engine.WATCH_DEFAULT
    db.DB_PATH=orig_path

print('VM optimization regression tests: OK')
