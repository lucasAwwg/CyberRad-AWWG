#!/usr/bin/env bash
set -Eeuo pipefail
if (( EUID != 0 )); then echo 'Ejecuta con sudo.' >&2; exit 1; fi
SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/weekly_awwg"
TARGET="${1:-/opt/cyberrad-awwg}"
ENV_FILE=/etc/cyberrad-awwg/cyberrad.env
for path in "$TARGET/weekly_awwg/pptx_report.py" "$TARGET/weekly_awwg/router.py" "$TARGET/weekly_awwg/weekly.html" "$TARGET/docker-compose.kali.yml" "$ENV_FILE"; do
 if [[ ! -f "$path" ]]; then echo "Archivo ausente: $path. No se instala." >&2; exit 2; fi
done
if ! docker inspect cyberrad-awwg >/dev/null 2>&1; then echo 'No está el contenedor cyberrad-awwg.' >&2; exit 3; fi
if ! docker compose version >/dev/null 2>&1; then echo 'Necesitas docker compose v2.' >&2; exit 4; fi
mkdir -p /var/backups/cyberrad-awwg
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP="/var/backups/cyberrad-awwg/weekly-6.3.1-${STAMP}.tar.gz"
tar -C "$TARGET" -czf "$BACKUP" weekly_awwg/pptx_report.py weekly_awwg/router.py weekly_awwg/weekly.html
# Compile BEFORE modifying installed source.
PYTHONPYCACHEPREFIX="$(mktemp -d)" python3 -m py_compile "$SOURCE/pptx_report.py" "$SOURCE/router.py"
for f in pptx_report.py router.py weekly.html; do
  install -m 644 -- "$SOURCE/$f" "$TARGET/weekly_awwg/$f"
done
# Rebuild only CyberRad; do not modify the persistent data, secrets or Sauron.
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" config -q
docker compose --project-directory "$TARGET" --env-file "$ENV_FILE" -f "$TARGET/docker-compose.kali.yml" up -d --build --no-deps cyberrad
echo "Hotfix 6.3.1 aplicado. Backup de fuentes: $BACKUP"
echo 'No se han modificado la base de datos, los tokens ni los puertos.'
