"""Compact AWWG-styled PDF; adapted from the layout patterns in the four supplied reports."""
from __future__ import annotations
from datetime import date
from html import escape
from pathlib import Path
import json
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER,TA_LEFT
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Table, TableStyle, PageBreak, KeepTogether, HRFlowable)
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.graphics.shapes import Drawing, Rect, String
from .engine import get_settings, counts, PRIORITY
from . import engine

TEAL=colors.HexColor('#005270')
DARK=colors.HexColor('#00465d')
BLUE=colors.HexColor('#e6f2f8')
MID=colors.HexColor('#d9e6ed')
BORDER=colors.HexColor('#dbe2e5')
CREAM=colors.HexColor('#faf9f7')
COLOR={'CRITICAL':'#bd3537','HIGH':'#d9564d','MID':'#d07c38','LOW':'#738e9b'}
FONT='Helvetica'
FONT_BOLD='Helvetica-Bold'
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
fontbold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
if Path(font).exists() and Path(fontbold).exists():
 pdfmetrics.registerFont(TTFont('DV',font))
 pdfmetrics.registerFont(TTFont('DV-Bold',fontbold))
 FONT='DV';FONT_BOLD='DV-Bold'

styles={
 'title':ParagraphStyle('a_title',fontName=FONT_BOLD,fontSize=21,leading=26,textColor=TEAL,spaceAfter=13),
 'h':ParagraphStyle('a_h',fontName=FONT_BOLD,fontSize=15,leading=20,textColor=TEAL,spaceAfter=11),
 'h2':ParagraphStyle('a_h2',fontName=FONT_BOLD,fontSize=10.5,leading=15,textColor=TEAL,spaceBefore=10,spaceAfter=5),
 'body':ParagraphStyle('a_body',fontName=FONT,fontSize=8.3,leading=12.7,textColor=colors.HexColor('#202a30'),spaceAfter=7),
 'small':ParagraphStyle('a_small',fontName=FONT,fontSize=7.0,leading=10.3,textColor=colors.HexColor('#35444c')),
 'bold':ParagraphStyle('a_bold',fontName=FONT_BOLD,fontSize=8.5,leading=12.7,textColor=TEAL),
 'white':ParagraphStyle('a_white',fontName=FONT_BOLD,fontSize=9,leading=12,textColor=colors.white),
 'cap':ParagraphStyle('a_cap',fontName=FONT,fontSize=6.9,leading=10,textColor=colors.HexColor('#65757d')),
}


def p(text,kind='body'):
 return Paragraph(escape(str(text or 'Not verified')).replace('\n','<br/>'),styles[kind])


def _page(canvas,doc):
 canvas.saveState()
 w,h=doc.pagesize
 if getattr(doc,'preview',False):
  canvas.setFont(FONT_BOLD, 16)
  canvas.setFillColor(colors.HexColor('#b23439'))
  canvas.drawCentredString(w/2, h-13*mm, 'LAYOUT PREVIEW — NOT A CURRENT REPORT')
 canvas.setStrokeColor(BORDER);canvas.setLineWidth(.6)
 canvas.line(21*mm,18*mm,w-21*mm,18*mm)
 canvas.setFillColor(colors.HexColor('#677780'));canvas.setFont(FONT,7)
 canvas.drawString(21*mm,13*mm,'Cyber News Weekly Report · Internal AWWG draft')
 canvas.drawRightString(w-21*mm,13*mm,str(doc.page))
 canvas.restoreState()


class OurDoc(BaseDocTemplate):
 def __init__(self,path):
  super().__init__(str(path),pagesize=(210*mm,297*mm),leftMargin=21*mm,rightMargin=21*mm,
                   topMargin=22*mm,bottomMargin=23*mm,title='AWWG Cyber News Weekly Report')
  frame=Frame(self.leftMargin,self.bottomMargin,self.width,self.height,leftPadding=0,bottomPadding=0,rightPadding=0,topPadding=0)
  self.addPageTemplates([PageTemplate(id='all',frames=[frame],onPage=_page)])


def table(rows,widths,header=False):
 rows=[[cell if isinstance(cell,Paragraph) else p(cell,'small') for cell in r] for r in rows]
 t=Table(rows,colWidths=widths,repeatRows=1 if header else 0,hAlign='LEFT')
 st=[('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('ROWBACKGROUNDS',(0,1 if header else 0),(-1,-1),[colors.HexColor('#eff4f6'),colors.HexColor('#dfe7ed')]),('LINEBELOW',(0,-1),(-1,-1),.3,BORDER)]
 if header:
  st += [('BACKGROUND',(0,0),(-1,0),TEAL),('TEXTCOLOR',(0,0),(-1,0),colors.white)]
  rows[0]=[Paragraph(escape(x.text if isinstance(x,Paragraph) else str(x)),styles['white']) for x in rows[0]]
  t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle(st))
 return t


def intro_block(txt):
 t=Table([[p(txt,'bold')]],colWidths=[168*mm]);t.setStyle(TableStyle([
  ('BACKGROUND',(0,0),(-1,-1),BLUE),('BOX',(0,0),(-1,-1),.5,BORDER),
  ('TOPPADDING',(0,0),(-1,-1),12),('BOTTOMPADDING',(0,0),(-1,-1),12),
  ('LEFTPADDING',(0,0),(-1,-1),11),('RIGHTPADDING',(0,0),(-1,-1),11)]))
 return t


def badge(priority):
 return p(priority,'bold')


def sector_chart(sector):
 try:
  current=float(str(sector.get('attacks','')).replace(',','.'))
  prev=float(str(sector.get('previous_attacks','')).replace(',','.'))
  if min(current,prev)<0:return None
 except (ValueError,TypeError):return None
 maxval=max(current,prev,1)
 drawing=Drawing(430,165)
 for i,(label,n) in enumerate([('Previous week',prev),('Current week',current)]):
  x=86+i*190;height=104*n/maxval
  drawing.add(Rect(x,27,94,height,fillColor=colors.HexColor('#3296a3'),strokeColor=None))
  drawing.add(String(x+47,31+height,('%g'%n),textAnchor='middle',fontName=FONT_BOLD,fontSize=11,fillColor=TEAL))
  drawing.add(String(x+47,10,label,textAnchor='middle',fontName=FONT,fontSize=9,fillColor=TEAL))
 return drawing


def make_pdf(start:date,end:date,items:list[dict],sector:dict|None=None, preview:bool=False)->Path:
 """Never invents CVSS, fixed versions, AWWG exposure, or sector statistics."""
 cfg=get_settings()
 engine.initialize()
 dest=engine.REPORTS/('AWWG_LAYOUT_PREVIEW.pdf' if preview else f'AWWG_Weekly_Report_{start.isoformat()}.pdf')
 doc=OurDoc(dest)
 doc.preview=preview
 parts=[]
 # Cover: brand text instead of extracting/reusing an undocumented logo file.
 header=Table([[Paragraph('<font size="27">AWWG</font>',styles['white'])]],colWidths=[168*mm],rowHeights=[33*mm])
 header.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),TEAL),('LEFTPADDING',(0,0),(-1,-1),15),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
 parts += [header,Spacer(1,13*mm),p('Cyber News\nWeekly Report','title'),p(f'Week of {start:%d %B %Y} – {end:%d %B %Y} · {len(items)} items reviewed'),Spacer(1,5*mm)]
 tally=counts(items)
 kpis=Table([[p(str(len(items)),'bold'),*[p(str(tally[x]),'bold') for x in PRIORITY]],
             [p('NEWS','cap'),*[p(x,'cap') for x in PRIORITY]]],colWidths=[168*mm/5]*5)
 kpis.setStyle(TableStyle([('BOX',(0,0),(-1,-1),.5,BORDER),('INNERGRID',(0,0),(-1,-1),.5,BORDER),('ALIGN',(0,0),(-1,-1),'CENTER'),('BACKGROUND',(0,0),(-1,-1),CREAM),('TOPPADDING',(0,0),(-1,0),9),('BOTTOMPADDING',(0,-1),(-1,-1),9)]))
 parts += [kpis,Spacer(1,10*mm),p('What we need to do this week','h')]
 if items:
  rows=[['ITEM','LEVEL','ACTION']]
  for item in items[:18]: rows.append([item['title'],item['priority'],item['action'][:260]])
  parts.append(table(rows,[67*mm,22*mm,79*mm],header=True))
  parts += [Spacer(1,10*mm),intro_block('Key point: Prioritize verified exposure and practical mitigation. All AWWG-specific applicability statements require internal evidence.')]
 else:
  parts.append(intro_block('No approved or independently verifiable items are available for this period. This is not evidence that the company has no exposures. Review candidate news and data-source errors.'))
 parts.append(Spacer(1,9*mm))
 parts.append(p('Evidence standard: CISA KEV confirms known exploitation, not exposure of any specific AWWG asset. Media-only findings require editorial approval.','cap'))
 parts.append(PageBreak())
 parts += [p('The week in 2 minutes','title'),p('What happened, what can be verified, and what we should check.','small'),Spacer(1,5*mm)]
 if not items: parts.append(p('No approved items for this reporting week.','body'))
 for it in items:
  entry=[p(f"[{it['priority']}] {it['title']}",'bold'),
    p('Source: '+it['source']+' · '+it['published'],'cap'),p(it['summary'][:600]),
    p('Our action → '+it['action'][:400],'bold'),HRFlowable(width='100%',thickness=.6,color=BORDER),Spacer(1,3*mm)]
  parts.append(KeepTogether(entry))
 parts.append(Spacer(1,5*mm))
 parts.append(p('Risk classification framework','h'))
 parts.append(table([['CRITICAL','HIGH','MID','LOW'],['Confirmed urgent company action.','Action after exposure review.','Tactical or indirect threat.','Informative or routine monitoring.']],[42*mm]*4,header=True))
 for it in items:
  parts += [PageBreak(),p(f"{it['priority']} · {it['title']}",'title'),
    p(it['summary'] or 'No source summary available.'),Spacer(1,3*mm)]
  data=[['FIELD','VERIFIED / CURRENT STATE'],['Product / category',it['category']],['CVE(s)',', '.join(it['cves']) if it['cves'] else 'No CVE confirmed'],
    ['Vendor severity',it['vendor_severity']],['CVSS',it['cvss']],['Affected versions',it['affected']],
    ['Patch / fixed version',it['fixed']],['Exploitation',it['verified_exploitation']],
    ['AWWG assessment',it['company_impact']]]
  parts += [table(data,[50*mm,118*mm],header=True),Spacer(1,7*mm),p('Recommended action','h2'),intro_block(it['action'][:900]),
    Spacer(1,6*mm),p('Evidence and traceability','h2'),p(it['source']+' · '+it['published'],'small')]
  url=it['source_url']
  if url.startswith(('https://','http://')):
   parts.append(Paragraph('<link href="'+escape(url,quote=True)+'" color="blue">'+escape(url[:120])+'</link>',styles['small']))
  parts.append(Spacer(1,6*mm))
  parts.append(p('AWWG impact is not confirmed unless an analyst has documented specific internal evidence. Technical severity and business priority are different assessments.','cap'))
 if cfg.get('always_show_sector_trends'):
  parts += [PageBreak(),p('Wholesale / Retail — weekly monitoring','title')]
  if sector:
   rows=[['METRIC','THIS WEEK','PREVIOUS WEEK']]
   for key,title in [('attacks','Retail attacks'),('rank','Retail ranking'),('global_attacks','Global attacks'),('data_tb','Claimed data (TB)')]:
    rows.append([title,str(sector.get(key,'Not reported')),str(sector.get('previous_'+key,'Not reported'))])
   parts += [table(rows,[64*mm,52*mm,52*mm],header=True),Spacer(1,8*mm)]
   chart=sector_chart(sector)
   if chart is not None:parts += [chart,Spacer(1,4*mm)]
   parts += [p('Source and methodology: '+sector.get('source','Unverified; user-entered data')),
     p('These sector figures do not establish an AWWG-specific breach.','bold')]
  else:
   parts += [intro_block('No verified weekly Hackmanac/sector statistics have been entered for this period; chart and percentage changes are intentionally omitted.'),Spacer(1,6*mm),p('Add the current and previous period values in Weekly Reports → Sector trends to generate a defensible comparison.','small')]
 doc.build(parts)
 return dest
