# CyberRad AWWG · Weekly Reports v6.5 HOTFIX

Basado en el ZIP **CyberRad_AWWG_Weekly_6_4_HOTFIX** proporcionado por el usuario. Actualización del módulo semanal, no reinstalación de CyberRad.

## Cambios

- Selector visible en «Informe semanal»: **Automático**, **Manual**, **Mixto**.
- Automático por defecto: investigación con las categorías, palabras clave, prioridades, fuentes verificadas y máximo de noticias guardados en Configuración. No depende de aprobar noticias previamente.
- Manual: exclusivamente noticias marcadas expresamente por el analista con «Incluir» o añadidas mediante el formulario; **no lanza búsquedas** al generar.
- Mixto: se priorizan las noticias manuales; se completan las plazas restantes con selección automática, sin duplicar noticias.
- Máximo de noticias global (1–30), también en Manual y Mixto. Si las noticias manuales superan el límite, se muestran las de mayor prioridad/recencia. Los registros sobrantes se conservan.
- Las exclusiones manuales prevalecen en todos los modos. Las noticias automáticas de fuentes no verificadas siguen marcadas explícitamente como borrador en el informe.
- El modo predeterminado se guarda en settings.json bajo `report_mode`, sin alterar los ajustes anteriores. El modo elegido al generar se envía al backend.
- `/api/weekly/run` investiga solo en modo Automático o Mixto; `/api/weekly/generate` vuelve a renderizar las noticias ya guardadas usando el modo elegido.
- Ambos formatos de informe salen de la misma selección. Se mantiene `pptx_report.py` de la v6.4 sin modificar su maquetación.

## Instalación (Kali, desde GitHub)

1. Subir **CyberRad_AWWG_Weekly_6_5_HOTFIX.zip** a la rama `main` de `https://github.com/lucasAwwg/CyberRad-AWWG`. **No estará disponible allí hasta que lo subas.**
2. Ejecutar:

```bash
cd /tmp
curl -fL --retry 3 'https://raw.githubusercontent.com/lucasAwwg/CyberRad-AWWG/main/CyberRad_AWWG_Weekly_6_5_HOTFIX.zip' -o CyberRad_AWWG_Weekly_6_5_HOTFIX.zip
unzip -t CyberRad_AWWG_Weekly_6_5_HOTFIX.zip
mkdir -p /tmp/cyberrad-weekly-6.5
unzip -qo CyberRad_AWWG_Weekly_6_5_HOTFIX.zip -d /tmp/cyberrad-weekly-6.5
sudo bash /tmp/cyberrad-weekly-6.5/actualizar_weekly_kali.sh /opt/cyberrad-awwg
sudo docker logs --tail=80 cyberrad-awwg
```

3. Abre `/weekly` y recarga con `Ctrl+Shift+R`. Comprueba las tres opciones. Prueba generación en cada modo y confirma que PDF/PPTX contienen la misma selección.
4. Después de verificar que funciona, limpia solo temporales:

```bash
rm -rf -- /tmp/cyberrad-weekly-6.5
rm -f -- /tmp/CyberRad_AWWG_Weekly_6_5_HOTFIX.zip
```

**No borra ni modifica** los datos de `/var/lib/cyberrad-awwg`, los tokens en `/etc/cyberrad-awwg`, el proyecto Sauron, los backups ni otros contenedores. El instalador crea `/var/backups/cyberrad-awwg/weekly-6.5-*.tar.gz` con los archivos previos y, si falla el despliegue, intenta restaurarlos.

## Reversión manual

Con el nombre real del backup que imprime el instalador:

```bash
sudo tar -C /opt/cyberrad-awwg -xzf /var/backups/cyberrad-awwg/weekly-6.5-FECHA_REAL.tar.gz
sudo docker compose --project-directory /opt/cyberrad-awwg --env-file /etc/cyberrad-awwg/cyberrad.env -f /opt/cyberrad-awwg/docker-compose.kali.yml up -d --build --no-deps cyberrad
```

## Limitación de verificación

Se han validado la sintaxis Python y JavaScript, y el comportamiento de selección con casos sintéticos. No se ha ejecutado el contenedor Kali real ni probado una exportación completa de informes en el entorno corporativo. Si el endpoint devuelve 500, consultar el traceback con `sudo docker logs --tail=150 cyberrad-awwg`.
