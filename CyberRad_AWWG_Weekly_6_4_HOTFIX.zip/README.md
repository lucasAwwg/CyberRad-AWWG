# CyberRad AWWG · Weekly Reports v6.4

## Objetivo

- **Un clic:** buscar todas las fuentes de las categorías y palabras activadas en Settings para los últimos 7 días y seleccionar noticias automáticamente, sin necesidad de aprobarlas una a una.
- **Automática + manual:** conservar las noticias que el analista marcó *Incluir* y añadirles las seleccionadas automáticamente. Cada noticia aparece una vez. *Excluir* prevalece siempre.
- **Añadir noticia manual:** formulario en *Revisión de noticias* con título, fecha, enlace HTTPS, categoría, resumen y prioridad; no se descarga el enlace en el servidor. La incorporación se guarda como decisión manual.
- **Configurable:** respeta categorías, palabras vigiladas, prioridad mínima, máximo de noticias, inclusión automática de CISA KEV y **Solo fuentes verificadas**. Esta última opción se aplica a la selección automática; las noticias incluidas manualmente siguen entrando como excepciones explícitas del analista.
- **Máximo de noticias:** las inclusiones manuales se conservan incluso si superan el límite configurado; el resto de plazas las rellenan las automáticas. No se eliminan noticias recopiladas.
- **Fidelidad de formato:** evita títulos superpuestos, limpia entidades HTML como `&nbsp;`, muestra una única fuente enlazada en la barra izquierda de cada ficha técnica (sin duplicar la URL al pie) y mantiene notas originales en PPTX.
- **Seguridad:** el token del backend se mantiene; no se introducen popups repetidos.
- **PDF/PPTX:** utiliza las mejoras anteriores de v6.3.1 para copiar PDF entre volúmenes.

## Instalación desde GitHub en Kali

1. **Subir** `CyberRad_AWWG_Weekly_6_4_HOTFIX.zip` a la rama `main` de https://github.com/lucasAwwg/CyberRad-AWWG.
2. Descargar en Kali:

```bash
cd /tmp
curl -fL --retry 3 'https://raw.githubusercontent.com/lucasAwwg/CyberRad-AWWG/main/CyberRad_AWWG_Weekly_6_4_HOTFIX.zip' -o CyberRad_AWWG_Weekly_6_4_HOTFIX.zip
unzip -t CyberRad_AWWG_Weekly_6_4_HOTFIX.zip
unzip -q -o CyberRad_AWWG_Weekly_6_4_HOTFIX.zip -d /tmp/cyberrad-hotfix-6.4
sudo bash /tmp/cyberrad-hotfix-6.4/actualizar_weekly_kali.sh /opt/cyberrad-awwg
```

3. Comprobar `sudo docker logs --tail=80 cyberrad-awwg`, abrir `/weekly` y pulsar `Ctrl+Shift+R`. Generar informe y verificar que las noticias manuales aparecen junto a las automáticas. No necesita reinstalación ni cambiar puertos.
4. **Limpiar después de probar:** `rm -rf /tmp/cyberrad-hotfix-6.4 && rm -f /tmp/CyberRad_AWWG_Weekly_6_4_HOTFIX.zip`. Son solo copias temporales; NO eliminar `/opt/cyberrad-awwg`, `/etc/cyberrad-awwg`, `/var/lib/cyberrad-awwg`, `/var/backups/cyberrad-awwg` ni ningún recurso de Sauron.

## Comportamiento y verificación

- `Generar informe semanal`: investiga y genera automáticamente con incluidas manualmente + auto.
- `Solo noticias revisadas`: genera únicamente lo que una persona marcó *Incluir*. El predeterminado "incluido" de CISA no cuenta como aprobación humana si no existe registro de auditoría.
- `Añadir noticia manualmente`: exige un enlace HTTPS y una fecha publicada en los últimos siete días; si coincide con un registro existente, lo marca como incluido en lugar de duplicarlo.
- Noticias descubiertas por Google News que no se han verificado NO se presentan como ataques confirmados a AWWG.
- La migración aditiva del campo `manual_include` recupera las aprobaciones anteriores consultando el historial de auditoría. No borra ni transforma noticias existentes.
- Se conservarán las 51 fuentes del programa principal y las configuraciones de `/etc`.

## Reversión

Descomprimir el backup `weekly-6.4-*.tar.gz` en `/opt/cyberrad-awwg`, reconstruir solamente el servicio CyberRad. Mantener el backup de datos antes de cualquier operación manual sobre la base; esta actualización no borra ningún dato.
