# CyberRad AWWG — despliegue VM 4 vCPU, 10 GB RAM

## Recursos asignados
- VM: 4 vCPU, 10.240 MB RAM. CPU física i5-10210U **probable**, pendiente de confirmar.
- Contenedor: `cpus: 3.0`, `mem_limit: 5g`, `mem_reservation: 1536m`. Quedan 1 vCPU de cuota y unos 5 GB físicos para SO, hipervisor y otros servicios. No hay promesa de que CyberRad consuma menos de 2 GB de manera constante.
- Un worker Uvicorn: los trabajos programados viven en el proceso web, así que más workers duplicarían refrescos y colisionarían con SQLite.
- SQLite WAL; conexiones read-only; caché por conexión 8 MiB; índices; reuso de consultas y caché de páginas/país/mapa; memoria de imágenes proxy <=32 MiB.
- RSS con 2/4/6 solicitudes según el perfil previo (Low/Balanced/Full); no se han reducido feeds ni límites originales. La carga está limitada por concurrencia, no por eliminación de contenido.
- RSS HTTP keep-alive por hilo + ETag/Last-Modified cuando la fuente los admite; caché temporal de imágenes 12h para evitar 6 segundos por noticia repetida; no elimina noticias, aunque la imagen puede permanecer en caché por ese periodo.
- Actualizaciones idénticas no generan escrituras SQLite innecesarias. Re-clasificación global tras nuevos artículos o al cambiar de fecha dentro del rango configurado; además al cambiar ajustes. Todas las noticias nuevas siguen clasificándose al ingerirse.
- Un informe PPTX/PDF simultáneo; se usa LibreOffice para el PDF, con `/tmp` limitado a 512 MiB.

## Instalación en Ubuntu/Debian Linux

1. Crear una carpeta **nueva de prueba** y descomprimir allí el ZIP. No sobrescribir la instalación productiva anterior sin copia. Instalar Docker Engine y plugin de Compose si faltan.
2. Respaldar `data/` (incluyendo cualquier archivo WAL/SHM después de detener correctamente el servicio existente): `cp -a data data.backup.$(date +%F)`.
3. En la nueva instalación, usar **los datos reales de la instalación actual** en `data/` si se desean conservar las noticias/fechas/decisiones. El ZIP incluye solo la pequeña DB original del ZIP del usuario; no representa un histórico activo.
4. `cp .env.example .env`; editar `CYBERRAD_UID` y `CYBERRAD_GID` para el propietario real de `data/` (`id -u`, `id -g`); cambiar el token de ejemplo. No publicar el puerto: por defecto se vincula a `127.0.0.1:3001`.
5. `docker compose config` para verificar recursos y variables, `docker compose up -d --build` para iniciar, `docker compose ps`, `docker compose logs -f --tail=100` para revisar.
6. `curl -fsS http://127.0.0.1:3001/healthz` devuelve `{"status":"ok"}`. Revisar después `/` y `/weekly` desde el host o mediante proxy corporativo.
7. Para acceder a Weekly Reports desde navegador, el token no se guarda permanentemente: la página lo solicita cuando se necesita. **El backend original no dispone de autenticación**: es imprescindible un proxy/SSO corporativo que proteja todas las rutas si hay acceso por red. El token del módulo semanal NO protege el resto de endpoints.
8. Comparar recuentos de noticias, feeds, estados y mapa antes/después. Observar `docker stats cyberrad-awwg`, latencia de `/api/articles`, tiempo de refresco, generación PDF/PPTX y picos de RAM. Si se mata por OOM, disminuir trabajos simultáneos o aumentar límite después de medir, sin recortar noticias.

## Riesgos conocidos / límites
- **No probado con Docker en este entorno**: aquí no hay Docker Engine ni una VM equivalente. Se han ejecutado pruebas sin red. Validar en staging antes de usar con usuarios reales.
- Redis, PostgreSQL y workers adicionales no se añaden de oficio: en 4 vCPU pueden empeorar rendimiento y aumentar mantenimiento. SQLite + WAL es una base razonable hasta obtener perfiles de carga.
- Los límites originales `max_articles_per_feed` permanecen por compatibilidad. No son una optimización nueva; aumentar ese parámetro si se necesita cobertura más amplia de cada publicación. Algunos RSS solo publican los últimos N artículos y no ofrecen backfill histórico.
- El proxy de imágenes sigue permitiendo orígenes de Internet arbitrarios: aunque ahora limita streaming a 6 MiB y caché a 32 MiB, **eso no corrige SSRF/rebinding**. No exponerlo sin controles de salida, proxy seguro, segmentación o una allowlist/pinning de DNS.
- El módulo semanal reutiliza diseño PPTX editable del PDF de referencia; la exactitud final depende de fuentes disponibles, revisión de contenidos y versión de LibreOffice. No hace afirmaciones automáticas sobre afectación de AWWG sin evidencia.
- Los trabajos semanales y de fuentes necesitan acceso HTTPS a Internet y almacenamiento persistente para DB/PDF/PPTX.

## Reversión
1. `docker compose down` en la instalación nueva, o detener servicio antiguo.
2. Restaurar el ZIP/código anterior y su `data/` respaldada.
3. Levantar con la configuración anterior y comprobar recuentos y dashboard.

## Validación local (no representa la VM)
- Tests heredados `smoke_test_hotfix23.py` y `smoke_test_hotfix24.py`: correctos.
- Test `test_vm_optimization.py`: 8.105 registros sintéticos guardados y accesibles, 0 registros nuevos en segunda ingesta, feed General con 8.105 visibles. Primera carga del listado alrededor de 4 s en el entorno de pruebas, segunda página con caché prácticamente instantánea. No extrapolar a hardware i5-10210U.
- Exportación con un boletín de prueba: `.pptx` editable y `.pdf` convertido por LibreOffice verificados; PDF A4 válido.
