# CyberRad AWWG — Hotfix Weekly Reports v6.3.1

## Causa confirmada en los registros del servidor

`OSError: [Errno 18] Invalid cross-device link` al mover un PDF con `os.replace()` desde `/tmp` a `/app/data/weekly_awwg/reports`. En Docker `/tmp` y `/app/data` pueden ser sistemas de archivos diferentes.

## Correcciones

- El PDF se copia a un archivo temporal creado dentro del volumen de informes, se sincroniza y se reemplaza **en el mismo sistema de archivos**.
- Si falla otra conversión PDF, se conserva el PPTX y el servidor no devuelve un 500 por ese error.
- El calendario por defecto usa **Europe/Madrid**, independientemente de la zona horaria del navegador (inicio de siete días atrás).
- No modifica la clasificación, fuentes, noticias, ajustes, token, datos persistentes, Sauron o puertos.

## Actualizar desde el ZIP subido a GitHub

Subir `CyberRad_AWWG_Weekly_6_3_1_HOTFIX.zip` a `lucasAwwg/CyberRad-AWWG` en `main` y ejecutar en Kali:

```bash
cd /tmp
curl -fL --retry 3 'https://raw.githubusercontent.com/lucasAwwg/CyberRad-AWWG/main/CyberRad_AWWG_Weekly_6_3_1_HOTFIX.zip' -o CyberRad_AWWG_Weekly_6_3_1_HOTFIX.zip
unzip -t CyberRad_AWWG_Weekly_6_3_1_HOTFIX.zip
unzip -q -o CyberRad_AWWG_Weekly_6_3_1_HOTFIX.zip -d /tmp/cyberrad-hotfix-6.3.1
sudo bash /tmp/cyberrad-hotfix-6.3.1/actualizar_weekly_kali.sh /opt/cyberrad-awwg
```

## Corregir la zona horaria de Kali

```bash
sudo timedatectl set-timezone Europe/Madrid
timedatectl
```

Reabrir el navegador y entrar en `/weekly`; ejecutar **Generar informe semanal**. Verificar que el nuevo PDF y PPTX aparezcan en Historial de informes.

## Verificación y diagnóstico

```bash
sudo docker ps --format 'table {{.Names}}	{{.Status}}	{{.Ports}}'
sudo docker logs --tail=80 cyberrad-awwg
```

Para revertir los archivos, descomprimir el backup en `/opt/cyberrad-awwg`, reconstruir solo CyberRad y conservar datos.
