# CyberRad AWWG v6.12 FULL — Instalación completa, un único ZIP

**Nombre del archivo**: `cyberrad-awwg-v.6.12.zip`

Este paquete contiene CyberRad AWWG completo (base Kali/Sauron v6.3) con todos los cambios de Weekly Reports integrados hasta v6.12. No contiene ni necesita descargar ZIPs de versiones anteriores. **No es un hotfix**. Contiene el código de la aplicación, los recursos gráficos, la base de datos de ejemplo con las fuentes iniciales, el configurador de IA y los instaladores para Kali.

## Instalación nueva (Kali)

Requisitos: Python 3, `openssl`, `sha256sum`, Docker Engine operativo y Docker Compose v2. La instalación del código no requiere bajar otras versiones de CyberRad, pero la construcción de la imagen Docker puede requerir acceso a repositorios de paquetes o una caché preexistente. No incluye imágenes Docker ni bibliotecas de terceros ya compiladas.

Copia el ZIP a Kali (o súbelo primero a GitHub `main` y descárgalo desde allí). Después:

```bash
cd /tmp
unzip -t cyberrad-awwg-v.6.12.zip
unzip -q cyberrad-awwg-v.6.12.zip -d /tmp/cyberrad-full-612
sudo bash /tmp/cyberrad-full-612/cyberrad-awwg-v.6.12/instalar_cyberrad_full.sh nuevo
```

- El código queda en `/opt/cyberrad-awwg`.
- Los datos y reportes quedan en `/var/lib/cyberrad-awwg`.
- El token/entorno queda en `/etc/cyberrad-awwg/cyberrad.env` (permisos 600).
- La web se enlaza de forma predeterminada **solo** a `127.0.0.1:3001` (ruta `/weekly`). No se expone a Internet.
- Arranca únicamente el servicio Docker `cyberrad`. No instala, elimina ni reinicia Sauron.
- Una base de datos nueva no contiene artículos ya recogidos ni informes anteriores; la aplicación debe investigar las fuentes al comenzar.

## Actualizar CyberRad AWWG existente

```bash
cd /tmp
unzip -t cyberrad-awwg-v.6.12.zip
unzip -q cyberrad-awwg-v.6.12.zip -d /tmp/cyberrad-full-612
sudo bash /tmp/cyberrad-full-612/cyberrad-awwg-v.6.12/instalar_cyberrad_full.sh actualizar
```

El modo `actualizar` sustituye únicamente los módulos de **Weekly Reports** (incluye motor 6.12 e interfaz de burbujas), conserva la aplicación base instalada, la configuración y el resto de datos y no altera la carpeta de Sauron. Antes guarda una copia del código Weekly y, cuando existe, una copia coherente de la base SQLite de noticias en `/var/backups/cyberrad-awwg`. Tras reconstruir solo CyberRad, **recalcula las prioridades de noticias existentes** manteniendo las prioridades que un analista haya editado manualmente. Muestra el número de noticias reclasificadas y el reparto por severidades.

**No utilizar `nuevo` para actualizar una instalación existente**: el instalador lo rechazará.

## Comprobar instalación

```bash
sudo bash /tmp/cyberrad-full-612/cyberrad-awwg-v.6.12/instalar_cyberrad_full.sh verificar
sudo docker logs --tail=80 cyberrad-awwg
curl -fsS http://127.0.0.1:3001/healthz
```

En el navegador: `/weekly` → Revisión de noticias → filtros de burbujas y severidad → Ctrl+Shift+R si se conserva una página antigua. Comprueba los modos de informe Automático/Manual/Mixto y la exportación PDF/PPTX con noticias de prueba. La conectividad externa depende de la red corporativa.

## Contenido por versiones

| Versión | Integración |
|---|---|
| 6.3 | CyberRad completo, 51 fuentes de arranque, Kali/Docker, optimización para 4 vCPU y 10 GB |
| 6.3.1 | Exportación PDF y correcciones de informes |
| 6.4 | Búsqueda y revisión de noticias, deduplicación, selección manual |
| 6.5 | Selección Automática, Manual y Mixta |
| 6.6 | Lectura de artículos y análisis IA opcional |
| 6.7 | Maquetación adaptable PDF/PPTX |
| 6.8 | Comparación de Hackmanac integrada, sin pestaña Wholesale/Retail independiente |
| 6.10 | Navegador visual por burbujas de categorías/subcategorías y severidad |
| 6.11 | Correcciones de filtros de burbujas y severidad preliminar |
| 6.12 | Prioridad CRITICAL solo CVSS explícito ≥ 9,0 y tecnología vigilada; Supply Chain Risk siempre MID; reclasificación del histórico automática al actualizar, respetando ediciones manuales |

## IA opcional

```bash
sudo python3 /tmp/cyberrad-full-612/cyberrad-awwg-v.6.12/configurar_ia_weekly.py
```

La configuración de IA no debe almacenarse en GitHub. Sin modelo IA, la aplicación intenta leer el artículo original cuando la red permite acceder a la fuente y no inventa datos ausentes.

## Seguridad y límites

- Nunca uses `docker system prune`, `docker volume prune` ni comandos para borrar bases de datos o informes existentes.
- No incluye ningún token privado, histórico de noticias real, informes corporativos anteriores ni secretos.
- El ZIP contiene el **código completo**, pero no es una máquina virtual ni una imagen Docker offline; para reconstruir dependencias puede requerirse Internet o repositorios internos.
- El modo `verificar` revisa integridad y, cuando está instalada, salud de CyberRad.
- La instalación nueva y la migración requieren comprobarse en la VM Kali de destino. Las pruebas de empaquetado/sintaxis no equivalen a una instalación Docker comprobada en producción.
